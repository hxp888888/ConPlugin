﻿namespace APITest
{
    partial class CryptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTips = new System.Windows.Forms.Label();
            this.btnToken = new System.Windows.Forms.Button();
            this.grpToken = new System.Windows.Forms.GroupBox();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.txtCrypt = new System.Windows.Forms.TextBox();
            this.lblCrypt = new System.Windows.Forms.Label();
            this.grpBox_ParamsIn = new System.Windows.Forms.GroupBox();
            this.txtParamsIn = new System.Windows.Forms.TextBox();
            this.grpBox_ParamsOut = new System.Windows.Forms.GroupBox();
            this.txtResponse = new System.Windows.Forms.TextBox();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.grbUrl = new System.Windows.Forms.GroupBox();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.grpAuthCode = new System.Windows.Forms.GroupBox();
            this.txtAuthCode = new System.Windows.Forms.TextBox();
            this.grpToken.SuspendLayout();
            this.grpBox_ParamsIn.SuspendLayout();
            this.grpBox_ParamsOut.SuspendLayout();
            this.grbUrl.SuspendLayout();
            this.grpAuthCode.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTips
            // 
            this.lblTips.AutoSize = true;
            this.lblTips.Font = new System.Drawing.Font("宋体", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblTips.ForeColor = System.Drawing.Color.Red;
            this.lblTips.Location = new System.Drawing.Point(12, 9);
            this.lblTips.Name = "lblTips";
            this.lblTips.Size = new System.Drawing.Size(255, 16);
            this.lblTips.TabIndex = 6;
            this.lblTips.Text = "*此测试以采购订单为例（加密）";
            // 
            // btnToken
            // 
            this.btnToken.Location = new System.Drawing.Point(15, 33);
            this.btnToken.Name = "btnToken";
            this.btnToken.Size = new System.Drawing.Size(75, 29);
            this.btnToken.TabIndex = 7;
            this.btnToken.Text = "获取Token";
            this.btnToken.UseVisualStyleBackColor = true;
            this.btnToken.Click += new System.EventHandler(this.btnToken_Click);
            // 
            // grpToken
            // 
            this.grpToken.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpToken.Controls.Add(this.txtToken);
            this.grpToken.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpToken.Location = new System.Drawing.Point(6, 184);
            this.grpToken.Name = "grpToken";
            this.grpToken.Size = new System.Drawing.Size(629, 51);
            this.grpToken.TabIndex = 9;
            this.grpToken.TabStop = false;
            this.grpToken.Text = "Token";
            // 
            // txtToken
            // 
            this.txtToken.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtToken.Font = new System.Drawing.Font("宋体", 9F);
            this.txtToken.Location = new System.Drawing.Point(3, 17);
            this.txtToken.Multiline = true;
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(623, 31);
            this.txtToken.TabIndex = 0;
            // 
            // txtCrypt
            // 
            this.txtCrypt.Location = new System.Drawing.Point(468, 37);
            this.txtCrypt.Name = "txtCrypt";
            this.txtCrypt.Size = new System.Drawing.Size(100, 21);
            this.txtCrypt.TabIndex = 10;
            this.txtCrypt.Text = "12345678";
            // 
            // lblCrypt
            // 
            this.lblCrypt.AutoSize = true;
            this.lblCrypt.Location = new System.Drawing.Point(421, 40);
            this.lblCrypt.Name = "lblCrypt";
            this.lblCrypt.Size = new System.Drawing.Size(41, 12);
            this.lblCrypt.TabIndex = 11;
            this.lblCrypt.Text = "秘钥：";
            // 
            // grpBox_ParamsIn
            // 
            this.grpBox_ParamsIn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBox_ParamsIn.Controls.Add(this.txtParamsIn);
            this.grpBox_ParamsIn.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpBox_ParamsIn.Location = new System.Drawing.Point(3, 241);
            this.grpBox_ParamsIn.Name = "grpBox_ParamsIn";
            this.grpBox_ParamsIn.Size = new System.Drawing.Size(632, 194);
            this.grpBox_ParamsIn.TabIndex = 13;
            this.grpBox_ParamsIn.TabStop = false;
            this.grpBox_ParamsIn.Text = "请求参数";
            // 
            // txtParamsIn
            // 
            this.txtParamsIn.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtParamsIn.Font = new System.Drawing.Font("宋体", 9F);
            this.txtParamsIn.Location = new System.Drawing.Point(3, 17);
            this.txtParamsIn.Multiline = true;
            this.txtParamsIn.Name = "txtParamsIn";
            this.txtParamsIn.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtParamsIn.Size = new System.Drawing.Size(626, 168);
            this.txtParamsIn.TabIndex = 0;
            // 
            // grpBox_ParamsOut
            // 
            this.grpBox_ParamsOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBox_ParamsOut.AutoSize = true;
            this.grpBox_ParamsOut.Controls.Add(this.txtResponse);
            this.grpBox_ParamsOut.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpBox_ParamsOut.Location = new System.Drawing.Point(3, 434);
            this.grpBox_ParamsOut.Name = "grpBox_ParamsOut";
            this.grpBox_ParamsOut.Size = new System.Drawing.Size(632, 191);
            this.grpBox_ParamsOut.TabIndex = 12;
            this.grpBox_ParamsOut.TabStop = false;
            this.grpBox_ParamsOut.Text = "返回参数";
            // 
            // txtResponse
            // 
            this.txtResponse.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtResponse.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtResponse.Location = new System.Drawing.Point(3, 17);
            this.txtResponse.Multiline = true;
            this.txtResponse.Name = "txtResponse";
            this.txtResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResponse.Size = new System.Drawing.Size(626, 168);
            this.txtResponse.TabIndex = 1;
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(249, 628);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(101, 29);
            this.btnDecrypt.TabIndex = 8;
            this.btnDecrypt.Text = "解密返回结果";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // grbUrl
            // 
            this.grbUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbUrl.Controls.Add(this.txtUrl);
            this.grbUrl.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grbUrl.Location = new System.Drawing.Point(5, 70);
            this.grbUrl.Name = "grbUrl";
            this.grbUrl.Size = new System.Drawing.Size(629, 51);
            this.grbUrl.TabIndex = 16;
            this.grbUrl.TabStop = false;
            this.grbUrl.Text = "API URL";
            // 
            // txtUrl
            // 
            this.txtUrl.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtUrl.Font = new System.Drawing.Font("宋体", 9F);
            this.txtUrl.Location = new System.Drawing.Point(3, 17);
            this.txtUrl.Multiline = true;
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(623, 28);
            this.txtUrl.TabIndex = 0;
            this.txtUrl.Text = "http://127.0.0.1/K3API";
            // 
            // grpAuthCode
            // 
            this.grpAuthCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpAuthCode.Controls.Add(this.txtAuthCode);
            this.grpAuthCode.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpAuthCode.Location = new System.Drawing.Point(5, 128);
            this.grpAuthCode.Name = "grpAuthCode";
            this.grpAuthCode.Size = new System.Drawing.Size(629, 51);
            this.grpAuthCode.TabIndex = 15;
            this.grpAuthCode.TabStop = false;
            this.grpAuthCode.Text = "授权码";
            // 
            // txtAuthCode
            // 
            this.txtAuthCode.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtAuthCode.Font = new System.Drawing.Font("宋体", 9F);
            this.txtAuthCode.Location = new System.Drawing.Point(3, 17);
            this.txtAuthCode.Multiline = true;
            this.txtAuthCode.Name = "txtAuthCode";
            this.txtAuthCode.Size = new System.Drawing.Size(623, 31);
            this.txtAuthCode.TabIndex = 0;
            this.txtAuthCode.Text = "d947613eec0ad8f583e3e7946cac0db0a9735393b7e6e76f";
            // 
            // CryptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 669);
            this.Controls.Add(this.grbUrl);
            this.Controls.Add(this.grpAuthCode);
            this.Controls.Add(this.btnDecrypt);
            this.Controls.Add(this.grpBox_ParamsIn);
            this.Controls.Add(this.grpBox_ParamsOut);
            this.Controls.Add(this.lblCrypt);
            this.Controls.Add(this.txtCrypt);
            this.Controls.Add(this.grpToken);
            this.Controls.Add(this.btnToken);
            this.Controls.Add(this.lblTips);
            this.Name = "CryptForm";
            this.Text = "CryptForm";
            this.grpToken.ResumeLayout(false);
            this.grpToken.PerformLayout();
            this.grpBox_ParamsIn.ResumeLayout(false);
            this.grpBox_ParamsIn.PerformLayout();
            this.grpBox_ParamsOut.ResumeLayout(false);
            this.grpBox_ParamsOut.PerformLayout();
            this.grbUrl.ResumeLayout(false);
            this.grbUrl.PerformLayout();
            this.grpAuthCode.ResumeLayout(false);
            this.grpAuthCode.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTips;
        private System.Windows.Forms.Button btnToken;
        private System.Windows.Forms.GroupBox grpToken;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.TextBox txtCrypt;
        private System.Windows.Forms.Label lblCrypt;
        private System.Windows.Forms.GroupBox grpBox_ParamsIn;
        private System.Windows.Forms.TextBox txtParamsIn;
        private System.Windows.Forms.GroupBox grpBox_ParamsOut;
        private System.Windows.Forms.TextBox txtResponse;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.GroupBox grbUrl;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.GroupBox grpAuthCode;
        private System.Windows.Forms.TextBox txtAuthCode;
    }
}