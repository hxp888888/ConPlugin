﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kingdee.K3.API.SDK;

namespace APITest
{
    public partial class CryptForm : Form
    {
        public CryptForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 获取Token
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnToken_Click(object sender, EventArgs e)
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string authCode = this.txtAuthCode.Text.Trim();
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 6000);
            this.txtResponse.Text = httpResponse;
        }

        /// <summary>
        /// 解密返回结果
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCrypt.Text.Trim().Length != 8)
                {
                    MessageBox.Show("秘钥必须为8位");
                }
                ResultModel model = JsonConverter.DeserializeObject<ResultModel>(this.txtResponse.Text);
                if (model != null)
                {
                    model.Data = K3Crypt.Decrypt(this.txtCrypt.Text, model.Data.ToString());
                    this.txtResponse.Text = JsonConverter.SerializeObject(model);
                }
                else
                {
                    MessageBox.Show("返回参数格式不正确");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
