﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using Newtonsoft.Json.Converters;

namespace APITest
{
    public static class JsonConverter
    {
        public static T DeserializeObject<T>(string jsonString)
        {
            return JsonConvert.DeserializeObject<T>(jsonString);
        }

        public static object DeserializeObject(string jsonString, Type type)
        {
            return JsonConvert.DeserializeObject(jsonString, type);
        }

        /// <summary>
        /// 对象序列化String
        /// 时间默认格式默认：yyyy-MM-dd HH:mm:ss
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string SerializeObject(object obj)
        {
            IsoDateTimeConverter timeCoverter = new IsoDateTimeConverter();
            timeCoverter.DateTimeFormat = "yyyy-MM-dd HH:mm:ss";
            return JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented, timeCoverter);
        }

        /// <summary>
        /// 日期格式
        /// timeFormat：yyyy-MM-dd HH:mm:ss
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="timeFormat"></param>
        /// <returns></returns>
        public static string SerializeObject(object obj, string timeFormat)
        {
            IsoDateTimeConverter timeCoverter = new IsoDateTimeConverter();
            timeCoverter.DateTimeFormat = timeFormat;
            return JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented, timeCoverter);
        }
    }
}

