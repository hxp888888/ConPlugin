﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace APITest
{
    public class K3Crypt
    {
        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string Encrypt(string key, string data)
        {
            string retVal = string.Empty;
            byte[] rgbKey = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] rgbIV = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] source = System.Text.Encoding.UTF8.GetBytes(data);
            byte[] dealCrypt = null;
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            provider.Padding = PaddingMode.PKCS7;
            provider.Mode = CipherMode.ECB;
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, provider.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write))
                {
                    cs.Write(source, 0, source.Length);
                    cs.FlushFinalBlock();
                }
                dealCrypt = ms.ToArray();
            }
            retVal = Convert.ToBase64String(dealCrypt);
            return retVal;
        }

        /// <summary>
        /// 解密
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string Decrypt(string key, string data)
        {
            string retVal = string.Empty;
            byte[] rgbKey = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] rgbIV = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] encryptSource = Convert.FromBase64String(data);
            byte[] source = null;
            //解压
            source = encryptSource;
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            provider.Padding = PaddingMode.PKCS7;
            provider.Mode = CipherMode.ECB;
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, provider.CreateDecryptor(rgbKey, rgbIV), CryptoStreamMode.Write))
                {
                    cs.Write(source, 0, source.Length);
                    cs.FlushFinalBlock();
                }
                retVal = Encoding.UTF8.GetString(ms.ToArray());
            }
            return retVal;
        }
    }
}
