﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    public class ResultModel
    {
        private int _StatusCode;

        public int StatusCode
        {
            get { return _StatusCode; }
            set { _StatusCode = value; }
        }

        private string _Message;

        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }

        private object _Data;

        public object Data
        {
            get { return _Data; }
            set { _Data = value; }
        }
    }
}
