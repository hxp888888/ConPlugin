﻿namespace APITest
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnToken = new System.Windows.Forms.Button();
            this.grpBox_ParamsOut = new System.Windows.Forms.GroupBox();
            this.txtResponse = new System.Windows.Forms.TextBox();
            this.btnGetTemplate = new System.Windows.Forms.Button();
            this.lblTips = new System.Windows.Forms.Label();
            this.grpBox_ParamsIn = new System.Windows.Forms.GroupBox();
            this.txtParamsIn = new System.Windows.Forms.TextBox();
            this.btnGetList = new System.Windows.Forms.Button();
            this.grpToken = new System.Windows.Forms.GroupBox();
            this.txtAuthCode = new System.Windows.Forms.TextBox();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.txtToken = new System.Windows.Forms.TextBox();
            this.btnCheckBill = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnGetDetail = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grbUrl = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonImportSO = new System.Windows.Forms.Button();
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.buttonSelectFile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.textBoxIndenNum = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.grpBox_ParamsOut.SuspendLayout();
            this.grpBox_ParamsIn.SuspendLayout();
            this.grpToken.SuspendLayout();
            this.grbUrl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnToken
            // 
            this.btnToken.Location = new System.Drawing.Point(722, 17);
            this.btnToken.Name = "btnToken";
            this.btnToken.Size = new System.Drawing.Size(75, 29);
            this.btnToken.TabIndex = 0;
            this.btnToken.Text = "获取Token";
            this.btnToken.UseVisualStyleBackColor = true;
            this.btnToken.Visible = false;
            this.btnToken.Click += new System.EventHandler(this.btnToken_Click);
            // 
            // grpBox_ParamsOut
            // 
            this.grpBox_ParamsOut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBox_ParamsOut.AutoSize = true;
            this.grpBox_ParamsOut.Controls.Add(this.txtResponse);
            this.grpBox_ParamsOut.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpBox_ParamsOut.Location = new System.Drawing.Point(4, 441);
            this.grpBox_ParamsOut.Name = "grpBox_ParamsOut";
            this.grpBox_ParamsOut.Size = new System.Drawing.Size(897, 218);
            this.grpBox_ParamsOut.TabIndex = 3;
            this.grpBox_ParamsOut.TabStop = false;
            this.grpBox_ParamsOut.Text = "返回参数";
            // 
            // txtResponse
            // 
            this.txtResponse.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtResponse.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtResponse.Location = new System.Drawing.Point(3, 17);
            this.txtResponse.Multiline = true;
            this.txtResponse.Name = "txtResponse";
            this.txtResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResponse.Size = new System.Drawing.Size(891, 198);
            this.txtResponse.TabIndex = 0;
            // 
            // btnGetTemplate
            // 
            this.btnGetTemplate.Location = new System.Drawing.Point(750, 14);
            this.btnGetTemplate.Name = "btnGetTemplate";
            this.btnGetTemplate.Size = new System.Drawing.Size(83, 29);
            this.btnGetTemplate.TabIndex = 4;
            this.btnGetTemplate.Text = "获取模板";
            this.btnGetTemplate.UseVisualStyleBackColor = true;
            this.btnGetTemplate.Visible = false;
            this.btnGetTemplate.Click += new System.EventHandler(this.btnGetTemplate_Click);
            // 
            // lblTips
            // 
            this.lblTips.AutoSize = true;
            this.lblTips.Font = new System.Drawing.Font("宋体", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblTips.ForeColor = System.Drawing.Color.Red;
            this.lblTips.Location = new System.Drawing.Point(18, 11);
            this.lblTips.Name = "lblTips";
            this.lblTips.Size = new System.Drawing.Size(0, 16);
            this.lblTips.TabIndex = 5;
            // 
            // grpBox_ParamsIn
            // 
            this.grpBox_ParamsIn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpBox_ParamsIn.Controls.Add(this.txtParamsIn);
            this.grpBox_ParamsIn.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpBox_ParamsIn.Location = new System.Drawing.Point(4, 365);
            this.grpBox_ParamsIn.Name = "grpBox_ParamsIn";
            this.grpBox_ParamsIn.Size = new System.Drawing.Size(897, 70);
            this.grpBox_ParamsIn.TabIndex = 6;
            this.grpBox_ParamsIn.TabStop = false;
            this.grpBox_ParamsIn.Text = "请求参数";
            // 
            // txtParamsIn
            // 
            this.txtParamsIn.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtParamsIn.Font = new System.Drawing.Font("宋体", 9F);
            this.txtParamsIn.Location = new System.Drawing.Point(3, 17);
            this.txtParamsIn.Multiline = true;
            this.txtParamsIn.Name = "txtParamsIn";
            this.txtParamsIn.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtParamsIn.Size = new System.Drawing.Size(891, 167);
            this.txtParamsIn.TabIndex = 0;
            // 
            // btnGetList
            // 
            this.btnGetList.Location = new System.Drawing.Point(722, 12);
            this.btnGetList.Name = "btnGetList";
            this.btnGetList.Size = new System.Drawing.Size(75, 29);
            this.btnGetList.TabIndex = 7;
            this.btnGetList.Text = "获取列表";
            this.btnGetList.UseVisualStyleBackColor = true;
            this.btnGetList.Visible = false;
            this.btnGetList.Click += new System.EventHandler(this.btnGetList_Click);
            // 
            // grpToken
            // 
            this.grpToken.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpToken.Controls.Add(this.txtAuthCode);
            this.grpToken.Controls.Add(this.txtUrl);
            this.grpToken.Controls.Add(this.txtToken);
            this.grpToken.Controls.Add(this.btnCheckBill);
            this.grpToken.Controls.Add(this.btnUpdate);
            this.grpToken.Controls.Add(this.btnGetDetail);
            this.grpToken.Controls.Add(this.btnGetList);
            this.grpToken.Controls.Add(this.btnSave);
            this.grpToken.Controls.Add(this.btnGetTemplate);
            this.grpToken.Controls.Add(this.btnToken);
            this.grpToken.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpToken.Location = new System.Drawing.Point(7, 344);
            this.grpToken.Name = "grpToken";
            this.grpToken.Size = new System.Drawing.Size(894, 15);
            this.grpToken.TabIndex = 8;
            this.grpToken.TabStop = false;
            this.grpToken.Text = "Token";
            this.grpToken.Visible = false;
            // 
            // txtAuthCode
            // 
            this.txtAuthCode.Font = new System.Drawing.Font("宋体", 9F);
            this.txtAuthCode.Location = new System.Drawing.Point(456, 14);
            this.txtAuthCode.Multiline = true;
            this.txtAuthCode.Name = "txtAuthCode";
            this.txtAuthCode.Size = new System.Drawing.Size(222, 31);
            this.txtAuthCode.TabIndex = 0;
            this.txtAuthCode.Text = "cc7c2a733c0a29ececb2e987389f67f2cec57e9b948dab79";
            // 
            // txtUrl
            // 
            this.txtUrl.Font = new System.Drawing.Font("宋体", 9F);
            this.txtUrl.Location = new System.Drawing.Point(160, 17);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(247, 21);
            this.txtUrl.TabIndex = 0;
            this.txtUrl.Text = "http://127.0.0.1/K3API";
            // 
            // txtToken
            // 
            this.txtToken.Font = new System.Drawing.Font("宋体", 9F);
            this.txtToken.Location = new System.Drawing.Point(3, 17);
            this.txtToken.Multiline = true;
            this.txtToken.Name = "txtToken";
            this.txtToken.Size = new System.Drawing.Size(131, 31);
            this.txtToken.TabIndex = 0;
            this.txtToken.Text = "45AF046AF5B55ECB828C27AEC24FBDED8A4D789CFB239B84A68F5BBCE226C1D76F006D0DC03A2F82";
            // 
            // btnCheckBill
            // 
            this.btnCheckBill.Location = new System.Drawing.Point(396, 12);
            this.btnCheckBill.Name = "btnCheckBill";
            this.btnCheckBill.Size = new System.Drawing.Size(109, 29);
            this.btnCheckBill.TabIndex = 12;
            this.btnCheckBill.Text = "新增工艺路线";
            this.btnCheckBill.UseVisualStyleBackColor = true;
            this.btnCheckBill.Visible = false;
            this.btnCheckBill.Click += new System.EventHandler(this.btnCheckBill_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(658, 16);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 29);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.Text = "新增BOM";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnGetDetail
            // 
            this.btnGetDetail.Location = new System.Drawing.Point(722, 12);
            this.btnGetDetail.Name = "btnGetDetail";
            this.btnGetDetail.Size = new System.Drawing.Size(75, 29);
            this.btnGetDetail.TabIndex = 9;
            this.btnGetDetail.Text = "获取明细";
            this.btnGetDetail.UseVisualStyleBackColor = true;
            this.btnGetDetail.Visible = false;
            this.btnGetDetail.Click += new System.EventHandler(this.btnGetDetail_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(739, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 29);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "新增物料";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // grbUrl
            // 
            this.grbUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grbUrl.Controls.Add(this.dataGridView1);
            this.grbUrl.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grbUrl.Location = new System.Drawing.Point(5, 35);
            this.grbUrl.Name = "grbUrl";
            this.grbUrl.Size = new System.Drawing.Size(894, 303);
            this.grbUrl.TabIndex = 14;
            this.grbUrl.TabStop = false;
            this.grbUrl.Text = "ExcelData";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(3, 17);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(888, 280);
            this.dataGridView1.TabIndex = 0;
            // 
            // buttonImportSO
            // 
            this.buttonImportSO.Enabled = false;
            this.buttonImportSO.Location = new System.Drawing.Point(809, 3);
            this.buttonImportSO.Name = "buttonImportSO";
            this.buttonImportSO.Size = new System.Drawing.Size(92, 29);
            this.buttonImportSO.TabIndex = 15;
            this.buttonImportSO.Text = "导入采购订单";
            this.buttonImportSO.UseVisualStyleBackColor = true;
            this.buttonImportSO.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(12, 6);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.ReadOnly = true;
            this.textBoxFileName.Size = new System.Drawing.Size(511, 21);
            this.textBoxFileName.TabIndex = 16;
            // 
            // buttonSelectFile
            // 
            this.buttonSelectFile.Location = new System.Drawing.Point(529, 9);
            this.buttonSelectFile.Name = "buttonSelectFile";
            this.buttonSelectFile.Size = new System.Drawing.Size(37, 23);
            this.buttonSelectFile.TabIndex = 17;
            this.buttonSelectFile.Text = "预览";
            this.buttonSelectFile.UseVisualStyleBackColor = true;
            this.buttonSelectFile.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // textBoxIndenNum
            // 
            this.textBoxIndenNum.Location = new System.Drawing.Point(699, 6);
            this.textBoxIndenNum.Name = "textBoxIndenNum";
            this.textBoxIndenNum.ReadOnly = true;
            this.textBoxIndenNum.Size = new System.Drawing.Size(60, 21);
            this.textBoxIndenNum.TabIndex = 18;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(766, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(610, 6);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 20;
            this.btnTest.Text = "test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 667);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxIndenNum);
            this.Controls.Add(this.buttonSelectFile);
            this.Controls.Add(this.textBoxFileName);
            this.Controls.Add(this.buttonImportSO);
            this.Controls.Add(this.grbUrl);
            this.Controls.Add(this.grpToken);
            this.Controls.Add(this.grpBox_ParamsIn);
            this.Controls.Add(this.lblTips);
            this.Controls.Add(this.grpBox_ParamsOut);
            this.Name = "MainForm";
            this.Text = "采购订单导入程序";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.grpBox_ParamsOut.ResumeLayout(false);
            this.grpBox_ParamsOut.PerformLayout();
            this.grpBox_ParamsIn.ResumeLayout(false);
            this.grpBox_ParamsIn.PerformLayout();
            this.grpToken.ResumeLayout(false);
            this.grpToken.PerformLayout();
            this.grbUrl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnToken;
        private System.Windows.Forms.GroupBox grpBox_ParamsOut;
        private System.Windows.Forms.TextBox txtResponse;
        private System.Windows.Forms.Button btnGetTemplate;
        private System.Windows.Forms.Label lblTips;
        private System.Windows.Forms.GroupBox grpBox_ParamsIn;
        private System.Windows.Forms.TextBox txtParamsIn;
        private System.Windows.Forms.Button btnGetList;
        private System.Windows.Forms.GroupBox grpToken;
        private System.Windows.Forms.TextBox txtToken;
        private System.Windows.Forms.Button btnGetDetail;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCheckBill;
        private System.Windows.Forms.TextBox txtAuthCode;
        private System.Windows.Forms.GroupBox grbUrl;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Button buttonImportSO;
        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.Button buttonSelectFile;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox textBoxIndenNum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnTest;
    }
}

