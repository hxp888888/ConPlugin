﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kingdee.K3.API.SDK;
using Microsoft.ApplicationBlocks.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Text.RegularExpressions;



namespace APITest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        string OldFileName;

        /// <summary>
        /// 获取Token
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnToken_Click(object sender, EventArgs e)
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string authCode = this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;
            cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

            if (to.StatusCode == 200)
            {
                txtToken.Text = to.Data.Token;
            }
        }

        /// <summary>
        /// 采购订单(PO) 获取模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGetTemplate_Click(object sender, EventArgs e)
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();
            string httpResponse = string.Empty;
            string url = apiUrl + "/Bill1000000/GetTemplate?token=" + token;  //Bill1000000/GetTemplate?token=    "/PO/GetTemplate?Token="
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);

            this.txtResponse.Text = httpResponse;
        }

        /// <summary>
        /// 采购订单(PO) 获取列表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGetList_Click(object sender, EventArgs e)
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();
            string httpResponse = string.Empty;
            string postJson = @"{
                                ""Data"": {
                                    ""Top"": ""100"", 
                                    ""PageSize"": ""10"", 
                                    ""PageIndex"": ""1"", 
                                    ""Filter"": ""[FBillNo] like '%001%' "", 
                                    ""OrderBy"": ""[FBillNo] asc"", 
                                    ""SelectPage"": ""2"", 
                                    ""Fields"": """"
                                }
                            }";
            string url = apiUrl + "/PO/GetList?Token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }


        private bool KYL(int fid)
        {
            string findtetify = System.DateTime.Now.ToString();

            SqlHelper.ExecuteScalar(Comstr, "pr_kl_AllYLPackingList", fid, findtetify);

            bool result = false;

            SqlDataReader dr = SqlHelper.ExecuteReader(Comstr, "pr_kl_GetYLItem", fid, findtetify);
            while (dr.Read())
            {
                result = true;
                genPackingList(fid, int.Parse(dr[0].ToString()), dr[1].ToString(), dr[2].ToString(), findtetify);
            }

            return result;


        }

        private void genPackingList(int fid, int PPBOMID, string fdeptnumber, string fdeptname, string findtetify)
        {




            cPakingList.PakingList PakingList = new cPakingList.PakingList();
            cPakingList.Data d = new cPakingList.Data();


            cPakingList.Page1Item Page1Item = new cPakingList.Page1Item();



            Page1Item.Fdate = DateTime.Now.ToString();

            Page1Item.FBackFlushed = "false";

            Page1Item.FClassTypeID = 24;

            cPakingList.FPurposeID FPurposeID = new cPakingList.FPurposeID();
            FPurposeID.FNumber = "YBLL";
            FPurposeID.FName = "一般领料";
            Page1Item.FPurposeID = FPurposeID;

            cPakingList.FDeptID FDeptID = new cPakingList.FDeptID();
            FDeptID.FNumber = fdeptnumber;
            FDeptID.FName = fdeptname;
            Page1Item.FDeptID = FDeptID;

            cPakingList.FSManagerID FSManagerID = new cPakingList.FSManagerID();
            FSManagerID.FNumber = "003";
            FSManagerID.FName = "王刚";
            Page1Item.FSManagerID = FSManagerID;

            cPakingList.FFManagerID FFManagerID = new cPakingList.FFManagerID();
            FFManagerID.FNumber = "003";
            FFManagerID.FName = "王刚";
            Page1Item.FFManagerID = FFManagerID;



            //  Page1Item.FNote = "开发导入";

            cPakingList.FBillerID FBillerID = new cPakingList.FBillerID();
            FBillerID.FNumber = "Administrator";
            FBillerID.FName = "Administrator";
            Page1Item.FBillerID = FBillerID;

            //cICSaleCommon.FDeptID FDeptID = new cICSaleCommon.FDeptID();
            //FDeptID.FNumber = "001";
            //FDeptID.FName = "销售二部";
            //Page1Item.FDeptID = FDeptID;

            //cICSaleCommon.FEmpID FEmpID = new cICSaleCommon.FEmpID();
            //FEmpID.FNumber = "005";
            //FEmpID.FName = "赵虎";
            //Page1Item.FEmpID = FEmpID;

            //Page1Item.FSysStatus = "2";




            // Page1Item.FPercentItemName = "调压阀";




            d.Page1.Add(Page1Item);

            SqlDataReader drEntry = SqlHelper.ExecuteReader(Comstr, "pr_kl_GetOnePackingListData", fid, findtetify, PPBOMID);
            while (drEntry.Read())
            {



                cPakingList.Page2Item Page2Item = new cPakingList.Page2Item();

                Page2Item.FBaseUnit = drEntry["FBaseUnit"].ToString();

                // Page2Item.fdate_2 = "2019-10-16 00:00:00";
                Page2Item.FQtyMust = double.Parse(drEntry["FNeedQty"].ToString());
                Page2Item.FQty = double.Parse(drEntry["FQty"].ToString());
                Page2Item.FCostOBJNumber = drEntry["CostObjNum"].ToString();
                Page2Item.FCostOBJModel = drEntry["CostObjModel"].ToString();
                Page2Item.FAuxQtyMust = double.Parse(drEntry["FNeedQty"].ToString());
                Page2Item.Fauxqty = double.Parse(drEntry["FQty"].ToString());
                Page2Item.FItemName = drEntry["FItemName"].ToString();

                Page2Item.FSourceBillNo = drEntry["FICMONumber"].ToString();

                Page2Item.FSourceTranType = 85;
                Page2Item.FSourceInterId = int.Parse(drEntry["FICMOInterID"].ToString());

                Page2Item.FICMOBillNo = drEntry["FICMONumber"].ToString();

                Page2Item.FICMOInterID = int.Parse(drEntry["FICMOInterID"].ToString());

                Page2Item.FPPBomEntryID = int.Parse(drEntry["FPPBomEntryID"].ToString());
                Page2Item.FSourceEntryID = int.Parse(drEntry["FPPBomEntryID"].ToString());

                Page2Item.FInterID2 = int.Parse(drEntry["FInterID2"].ToString());

                Page2Item.FEntryID2 = 1;//行号
                Page2Item.FDetailID2 = int.Parse(drEntry["FDetailID"].ToString());
                Page2Item.Fnote = "开发导入";


                cPakingList.FReProduceType FReProduceType = new cPakingList.FReProduceType();
                FReProduceType.FNumber = "N";
                FReProduceType.FName = "否";
                Page2Item.FReProduceType = FReProduceType;

                cPakingList.FUnitID FUnitID = new cPakingList.FUnitID();
                FUnitID.FNumber = drEntry["FBaseUnitID"].ToString();
                FUnitID.FName = drEntry["FBaseUnit"].ToString();
                Page2Item.FUnitID = FUnitID;

                cPakingList.FCostOBJID FCostOBJID = new cPakingList.FCostOBJID();
                FCostOBJID.FNumber = drEntry["CostObjNum"].ToString();
                FCostOBJID.FName = drEntry["CostObjNum"].ToString();
                Page2Item.FCostOBJID = FCostOBJID;

                cPakingList.FSCStockID1 FSCStockID1 = new cPakingList.FSCStockID1();
                FSCStockID1.FNumber = drEntry["StockNum"].ToString();
                FSCStockID1.FName = drEntry["StockName"].ToString();
                Page2Item.FSCStockID1 = FSCStockID1;


                cPakingList.FItemID FItemID = new cPakingList.FItemID();
                FItemID.FNumber = drEntry["ItemNumber"].ToString();
                FItemID.FName = drEntry["FItemName"].ToString();
                Page2Item.FItemID = FItemID;

                cPakingList.FPlanMode FPlanMode = new cPakingList.FPlanMode();
                FPlanMode.FNumber = drEntry["MTONumber"].ToString();
                FPlanMode.FName = drEntry["MTOName"].ToString();
                Page2Item.FPlanMode = FPlanMode;
                // Page2Item.FKFDate = System.DateTime.Now;




                d.Page2.Add(Page2Item);
            }






            PakingList.Data = d;

            this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(PakingList);
            //"FBeginDay":"1900-01-01 00:00:00",
            //    "FEndDay":"2100-01-01 00:00:00",

        }

        private void genPackingList()
        {
            cPakingList.PakingList PakingList = new cPakingList.PakingList();
            cPakingList.Data d = new cPakingList.Data();
            cPakingList.Page1Item Page1Item = new cPakingList.Page1Item();



            Page1Item.Fdate = DateTime.Now.ToString();

            Page1Item.FBackFlushed = "false";

            Page1Item.FClassTypeID = 24;

            cPakingList.FPurposeID FPurposeID = new cPakingList.FPurposeID();
            FPurposeID.FNumber = "YBLL";
            FPurposeID.FName = "一般领料";
            Page1Item.FPurposeID = FPurposeID;

            cPakingList.FDeptID FDeptID = new cPakingList.FDeptID();
            FDeptID.FNumber = "002";
            FDeptID.FName = "机加车间";
            Page1Item.FDeptID = FDeptID;

            cPakingList.FSManagerID FSManagerID = new cPakingList.FSManagerID();
            FSManagerID.FNumber = "003";
            FSManagerID.FName = "王刚";
            Page1Item.FSManagerID = FSManagerID;

            cPakingList.FFManagerID FFManagerID = new cPakingList.FFManagerID();
            FFManagerID.FNumber = "003";
            FFManagerID.FName = "王刚";
            Page1Item.FFManagerID = FFManagerID;



            //  Page1Item.FNote = "开发导入";

            cPakingList.FBillerID FBillerID = new cPakingList.FBillerID();
            FBillerID.FNumber = "Administrator";
            FBillerID.FName = "Administrator";
            Page1Item.FBillerID = FBillerID;

            //cICSaleCommon.FDeptID FDeptID = new cICSaleCommon.FDeptID();
            //FDeptID.FNumber = "001";
            //FDeptID.FName = "销售二部";
            //Page1Item.FDeptID = FDeptID;

            //cICSaleCommon.FEmpID FEmpID = new cICSaleCommon.FEmpID();
            //FEmpID.FNumber = "005";
            //FEmpID.FName = "赵虎";
            //Page1Item.FEmpID = FEmpID;

            //Page1Item.FSysStatus = "2";




            // Page1Item.FPercentItemName = "调压阀";




            d.Page1.Add(Page1Item);

            cPakingList.Page2Item Page2Item = new cPakingList.Page2Item();

            Page2Item.FBaseUnit = "g";

            // Page2Item.fdate_2 = "2019-10-16 00:00:00";
            Page2Item.FQtyMust = 600;
            Page2Item.FQty = 3;
            Page2Item.FCostOBJNumber = "91.003";
            Page2Item.FCostOBJModel = "2323";
            Page2Item.FAuxQtyMust = 600;
            Page2Item.Fauxqty = 3;
            Page2Item.FItemName = "MOS2";

            Page2Item.FSourceBillNo = "WORK000013";

            Page2Item.FSourceTranType = 85;
            Page2Item.FSourceInterId = 1014;

            Page2Item.FICMOBillNo = "WORK000013";

            Page2Item.FICMOInterID = 1014;

            Page2Item.FPPBomEntryID = 4;
            Page2Item.FSourceEntryID = 4;

            Page2Item.FInterID2 = 1934;

            Page2Item.FEntryID2 = 1;
            Page2Item.FDetailID2 = 375;
            Page2Item.Fnote = "开发导入";


            cPakingList.FReProduceType FReProduceType = new cPakingList.FReProduceType();
            FReProduceType.FNumber = "N";
            FReProduceType.FName = "否";
            Page2Item.FReProduceType = FReProduceType;

            cPakingList.FUnitID FUnitID = new cPakingList.FUnitID();
            FUnitID.FNumber = "631";
            FUnitID.FName = "kg";
            Page2Item.FUnitID = FUnitID;

            cPakingList.FCostOBJID FCostOBJID = new cPakingList.FCostOBJID();
            FCostOBJID.FNumber = "91.003";
            FCostOBJID.FName = "V形圈";
            Page2Item.FCostOBJID = FCostOBJID;

            cPakingList.FSCStockID1 FSCStockID1 = new cPakingList.FSCStockID1();
            FSCStockID1.FNumber = "6.01";
            FSCStockID1.FName = "原料仓";
            Page2Item.FSCStockID1 = FSCStockID1;


            cPakingList.FItemID FItemID = new cPakingList.FItemID();
            FItemID.FNumber = "90.01.004";
            FItemID.FName = "MOS2";
            Page2Item.FItemID = FItemID;

            cPakingList.FPlanMode FPlanMode = new cPakingList.FPlanMode();
            FPlanMode.FNumber = "MTS";
            FPlanMode.FName = "MTS计划模式";
            Page2Item.FPlanMode = FPlanMode;



            d.Page2.Add(Page2Item);






            PakingList.Data = d;

            this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(PakingList);
            //"FBeginDay":"1900-01-01 00:00:00",
            //    "FEndDay":"2100-01-01 00:00:00",

        }

        private void genICSaleCommon()
        {
            cICSaleCommon.ICSaleCommon ICSaleCommon = new cICSaleCommon.ICSaleCommon();
            cICSaleCommon.Data d = new cICSaleCommon.Data();
            cICSaleCommon.Page1Item Page1Item = new cICSaleCommon.Page1Item();



            Page1Item.FDate = DateTime.Now.ToString();

            cICSaleCommon.FExchangeRateType FExchangeRateType = new cICSaleCommon.FExchangeRateType();
            FExchangeRateType.FNumber = "01";
            FExchangeRateType.FName = "公司汇率";
            Page1Item.FExchangeRateType = FExchangeRateType;

            cICSaleCommon.FItemClassID FItemClassID = new cICSaleCommon.FItemClassID();
            FItemClassID.FNumber = "001";
            FItemClassID.FName = "客户";
            Page1Item.FItemClassID = FItemClassID;

            Page1Item.FFincDate = DateTime.Now.ToString();

            cICSaleCommon.FCurrencyID FCurrencyID = new cICSaleCommon.FCurrencyID();
            FCurrencyID.FNumber = "RMB";
            FCurrencyID.FName = "人民币";
            Page1Item.FCurrencyID = FCurrencyID;

            cICSaleCommon.FCustID FCustID = new cICSaleCommon.FCustID();
            FCustID.FNumber = "002";
            FCustID.FName = "东方机电";
            Page1Item.FCustID = FCustID;

            Page1Item.FExchangeRate = "1";

            Page1Item.FROB = "1";

            Page1Item.FYear = "2019";
            Page1Item.FPeriod = "1";

            Page1Item.FAdjustExchangeRate = "1";
            Page1Item.FTranType = "86";

            cICSaleCommon.FSaleStyle FSaleStyle = new cICSaleCommon.FSaleStyle();
            FSaleStyle.FNumber = "FXF02";
            FSaleStyle.FName = "赊销";
            Page1Item.FSaleStyle = FSaleStyle;


            Page1Item.FNote = "开发导入";

            cICSaleCommon.FBillerID FBillerID = new cICSaleCommon.FBillerID();
            FBillerID.FNumber = "Administrator";
            FBillerID.FName = "Administrator";
            Page1Item.FBillerID = FBillerID;

            cICSaleCommon.FDeptID FDeptID = new cICSaleCommon.FDeptID();
            FDeptID.FNumber = "001";
            FDeptID.FName = "销售二部";
            Page1Item.FDeptID = FDeptID;

            cICSaleCommon.FEmpID FEmpID = new cICSaleCommon.FEmpID();
            FEmpID.FNumber = "005";
            FEmpID.FName = "赵虎";
            Page1Item.FEmpID = FEmpID;

            Page1Item.FSysStatus = "2";




            // Page1Item.FPercentItemName = "调压阀";




            d.Page1.Add(Page1Item);

            cICSaleCommon.Page2Item Page2Item = new cICSaleCommon.Page2Item();

            Page2Item.fdate_2 = "2019-10-16 00:00:00";
            Page2Item.FAmountFor = "738";
            Page2Item.FOrgID = "125";
            Page2Item.FAmount2 = "738";
            Page2Item.FRemainAmount = "738";
            Page2Item.FRemainAmountFor = "738";
            Page2Item.FRP = "1";


            d.Page2.Add(Page2Item);

            cICSaleCommon.Page3Item Page3Item = new cICSaleCommon.Page3Item();


            cICSaleCommon.FItemID FItemID = new cICSaleCommon.FItemID();
            FItemID.FNumber = "1.01.000.00000";
            FItemID.FName = "服务协议";
            Page3Item.FItemID = FItemID;

            cICSaleCommon.FUnitID FUnitID = new cICSaleCommon.FUnitID();
            FUnitID.FNumber = "641";
            FUnitID.FName = "KG";
            Page3Item.FUnitID = FUnitID;

            Page3Item.FAuxQty = "82";
            Page3Item.FAuxTaxPrice = "10";
            Page3Item.FAuxPrice = "10";
            Page3Item.FDiscountRate = "10";
            Page3Item.FSourceInterId = "1930";

            Page3Item.FPriceDiscount = "9";

            Page3Item.FAmtDiscount = "82";

            Page3Item.FStdAmtDiscount = "82";

            Page3Item.FAmount3 = "738";
            Page3Item.FPrice = "10";

            Page3Item.FTaxPrice = "10";
            Page3Item.FStdAmount = "738";
            Page3Item.FTaxRate = "17";

            Page3Item.FTaxAmount = "107.23";
            Page3Item.FStdTaxAmount = "107.23";
            Page3Item.FAmountIncludeTax = "630.77";

            Page3Item.FStdAmountIncludeTax = "630.77";
            Page3Item.FBaseUnit = "KG";
            Page3Item.FQty = "82";

            Page3Item.FAuxOrderPrice = "10";
            Page3Item.FOrderPrice = "10";
            Page3Item.FSourceBillNo = "XOUT000018";

            Page3Item.FOrderBillNo = "SEORD000038";
            Page3Item.FRemainAmountForEntry = "738";
            Page3Item.FRemainAmountEntry = "738";

            Page3Item.FOrderBillNo = "SEORD000038";
            Page3Item.FRemainAmountForEntry = "738";
            Page3Item.FRemainAmountEntry = "738";

            Page3Item.FRemainQty = "82";
            Page3Item.FSourceTranType = "21";
            Page3Item.FRemainAmountEntry = "738";

            Page3Item.FOrderEntryID = "1";
            Page3Item.FOrderInterID = "1167";
            Page3Item.FRemainAmountEntry = "738";
            Page3Item.FEntryID_SRC = 1;
            Page3Item.FEntryID3 = "1";


            cICSaleCommon.FClassID_SRC FClassID_SRC = new cICSaleCommon.FClassID_SRC();
            FClassID_SRC.FNumber = "21";
            FClassID_SRC.FName = "销售出库";
            Page3Item.FClassID_SRC = FClassID_SRC;


            d.Page3.Add(Page3Item);




            ICSaleCommon.Data = d;

            this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(ICSaleCommon);
            //"FBeginDay":"1900-01-01 00:00:00",
            //    "FEndDay":"2100-01-01 00:00:00",








        }

        private void genRoutingData()
        {
            cRouting.Routing Routing = new cRouting.Routing();
            cRouting.Data d = new cRouting.Data();
            cRouting.Page1Item Page1Item = new cRouting.Page1Item();

            Page1Item.FRoutingName = "塑料工艺";

            cRouting.FParentID FParentID = new cRouting.FParentID();
            FParentID.FNumber = "91";
            FParentID.FName = "50塑料";
            Page1Item.FParentID = FParentID;


            Page1Item.Fdefault = "1058";


            cRouting.FItemID FItemID = new cRouting.FItemID();
            FItemID.FNumber = "91.003";
            FItemID.FName = "V形圈";
            Page1Item.FItemID = FItemID;

            // Page1Item.FPercentItemName = "调压阀";




            d.Page1.Add(Page1Item);

            cRouting.Page2Item Page2Item = new cRouting.Page2Item();

            Page2Item.FOperSN1 = "10";

            cRouting.FOperID1 FOperID1 = new cRouting.FOperID1();
            FOperID1.FNumber = "601";
            FOperID1.FName = "压制";
            Page2Item.FOperID1 = FOperID1;

            cRouting.FOperName1 FOperName1 = new cRouting.FOperName1();
            FOperName1.FNumber = "601";
            FOperName1.FName = "压制";
            Page2Item.FOperName1 = FOperName1;

            cRouting.FWorkCenterID1 FWorkCenterID1 = new cRouting.FWorkCenterID1();
            FWorkCenterID1.FNumber = "6.01";
            FWorkCenterID1.FName = "机加工";
            Page2Item.FWorkCenterID1 = FWorkCenterID1;

            Page2Item.FName1 = "2379";
            Page2Item.FDeptID1 = "2379";

            cRouting.FTimeUnit1 FTimeUnit1 = new cRouting.FTimeUnit1();
            FTimeUnit1.FNumber = "H";
            FTimeUnit1.FName = "小时";
            Page2Item.FTimeUnit1 = FTimeUnit1;

            Page2Item.FWorkQty1 = "100";
            Page2Item.FTimeRun1 = "1";
            Page2Item.FMoveQty1 = "1";

            cRouting.FAutoTD1 FAutoTD1 = new cRouting.FAutoTD1();
            FAutoTD1.FNumber = "Y";
            FAutoTD1.FName = "是";
            Page2Item.FAutoTD1 = FAutoTD1;

            cRouting.FAutoOF1 FAutoOF1 = new cRouting.FAutoOF1();
            FAutoOF1.FNumber = "Y";
            FAutoOF1.FName = "是";
            Page2Item.FAutoOF1 = FAutoOF1;

            Page2Item.FFare1 = "1059";

            cRouting.FISOut1 FISOut1 = new cRouting.FISOut1();
            FISOut1.FNumber = "N";
            FISOut1.FName = "否";
            Page2Item.FISOut1 = FISOut1;

            Page2Item.FFare1 = "352";

            Page2Item.FResourceCount1 = "1";
            Page2Item.FConversion1 = "1";

            Page2Item.FMachStdTimeRun1 = "100";




            d.Page2.Add(Page2Item);


            Routing.Data = d;

            this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(Routing);
            //"FBeginDay":"1900-01-01 00:00:00",
            //    "FEndDay":"2100-01-01 00:00:00",








        }

        private void genBOMData()
        {
            cBOM.BOM bom = new cBOM.BOM();
            cBOM.Data d = new cBOM.Data();
            cBOM.Page1Item Page1Item = new cBOM.Page1Item();

            // Page1Item.FBOMNumber = "BOM000005test111";
            Page1Item.FVersion = "";
            Page1Item.FPercentQty = 1;
            Page1Item.FYield = 99.99;
            Page1Item.FEntertime = System.DateTime.Now.ToString();


            cBOM.FParentID FParentID = new cBOM.FParentID();
            FParentID.FNumber = "1";
            FParentID.FName = "50柴油机";
            Page1Item.FParentID = FParentID;

            cBOM.FPercentItemID FPercentItemID = new cBOM.FPercentItemID();
            FPercentItemID.FNumber = "1.01.100-0070-000";
            FPercentItemID.FName = "调压阀";
            Page1Item.FPercentItemID = FPercentItemID;

            // Page1Item.FPercentItemName = "调压阀";

            cBOM.FPercentUnitID FPercentUnitID = new cBOM.FPercentUnitID();
            FPercentUnitID.FNumber = "01";
            FPercentUnitID.FName = "个";
            Page1Item.FPercentUnitID = FPercentUnitID;

            cBOM.FBOMSkip FBOMSkip = new cBOM.FBOMSkip();
            FBOMSkip.FNumber = "N";
            FBOMSkip.FName = "否";
            Page1Item.FBOMSkip = FBOMSkip;





            d.Page1.Add(Page1Item);

            cBOM.Page2Item Page2Item = new cBOM.Page2Item();

            Page2Item.FEntryID = "1";

            cBOM.FItemID FItemID = new cBOM.FItemID();
            FItemID.FNumber = "1.01.100-0086-000";
            FItemID.FName = "调压阀阀盖";
            Page2Item.FItemID = FItemID;

            Page2Item.FAuxQtyScrap = 1;
            Page2Item.FScrap = 0;

            cBOM.FMaterielType FMaterielType = new cBOM.FMaterielType();
            FMaterielType.FNumber = "COM";
            FMaterielType.FName = "普通件";
            Page2Item.FMaterielType = FMaterielType;

            cBOM.FStockID FStockID = new cBOM.FStockID();
            FStockID.FNumber = "01";
            FStockID.FName = "材料仓机械类";
            Page2Item.FStockID = FStockID;

            cBOM.FUnitID FUnitID = new cBOM.FUnitID();
            FUnitID.FNumber = "01";
            FUnitID.FName = "个";
            Page2Item.FUnitID = FUnitID;

            cBOM.FMarshalType FMarshalType = new cBOM.FMarshalType();
            FMarshalType.FNumber = "COM";
            FMarshalType.FName = "通用";
            Page2Item.FMarshalType = FMarshalType;
            Page2Item.FBeginDay = "1900-01-01 00:00:00.000";
            Page2Item.FEndDay = "2100-01-01 00:00:00.000";


            d.Page2.Add(Page2Item);


            bom.Data = d;

            this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(bom);
            //"FBeginDay":"1900-01-01 00:00:00",
            //    "FEndDay":"2100-01-01 00:00:00",








        }

        private void genRountingData(string apiUrl)
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            //根据Key读取<add>元素的Value
            //System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            // MessageBox.Show(config.AppSettings.Settings["connectionstring"].Value);
            SqlDataReader drAll = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_GetAllRouting");
            while (drAll.Read())
            {
                SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_IsExitRoutingData", drAll["FBillNo"].ToString());
                if (drIsExit.Read() == false)
                {
                    SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_GetRoutingData", drAll["FBillNo"].ToString());
                    int i = 1;
                    cRouting.Routing Routing = new cRouting.Routing();
                    cRouting.Data d = new cRouting.Data();
                    while (dr.Read())
                    {




                        if (i == 1)
                        {

                            cRouting.Page1Item Page1Item = new cRouting.Page1Item();

                            // Page1Item.FBOMNumber = "BOM000005test111";
                            Page1Item.FRoutingName = dr["FRoutingName"].ToString();

                            cRouting.FParentID FParentID = new cRouting.FParentID();
                            FParentID.FNumber = dr["GroupNum"].ToString();
                            FParentID.FName = dr["GroupName"].ToString();
                            Page1Item.FParentID = FParentID;


                            Page1Item.Fdefault = dr["FDefault"].ToString();


                            cRouting.FItemID FItemID = new cRouting.FItemID();
                            FItemID.FNumber = dr["PNum"].ToString();
                            FItemID.FName = dr["PName"].ToString();
                            Page1Item.FItemID = FItemID;


                            Page1Item.fheadselfZ0216 = drAll["FBillNo"].ToString();


                            d.Page1.Add(Page1Item);
                        }



                        cRouting.Page2Item Page2Item = new cRouting.Page2Item();

                        Page2Item.FOperSN1 = dr["FOperSN"].ToString();

                        cRouting.FOperID1 FOperID1 = new cRouting.FOperID1();
                        FOperID1.FNumber = dr["FOperNum"].ToString();
                        FOperID1.FName = dr["FOperName"].ToString();
                        Page2Item.FOperID1 = FOperID1;

                        cRouting.FOperName1 FOperName1 = new cRouting.FOperName1();
                        FOperName1.FNumber = dr["FOperNum"].ToString();
                        FOperName1.FName = dr["FOperName"].ToString();
                        Page2Item.FOperName1 = FOperName1;

                        cRouting.FWorkCenterID1 FWorkCenterID1 = new cRouting.FWorkCenterID1();
                        FWorkCenterID1.FNumber = dr["WorkCenterIDNum"].ToString();
                        FWorkCenterID1.FName = dr["WorkCenterIDName"].ToString();
                        Page2Item.FWorkCenterID1 = FWorkCenterID1;

                        Page2Item.FName1 = dr["FName"].ToString();
                        Page2Item.FDeptID1 = dr["FName"].ToString();

                        cRouting.FTimeUnit1 FTimeUnit1 = new cRouting.FTimeUnit1();
                        FTimeUnit1.FNumber = dr["FTimeUnitNum"].ToString();
                        FTimeUnit1.FName = dr["FTimeUnitName"].ToString();
                        Page2Item.FTimeUnit1 = FTimeUnit1;

                        Page2Item.FWorkQty1 = dr["FWorkQty"].ToString();
                        Page2Item.FTimeRun1 = dr["FTimeRun"].ToString();
                        Page2Item.FMoveQty1 = dr["FMoveQty"].ToString();

                        cRouting.FAutoTD1 FAutoTD1 = new cRouting.FAutoTD1();
                        FAutoTD1.FNumber = dr["FFAutoTDNum"].ToString();
                        FAutoTD1.FName = dr["FFAutoTDName"].ToString();
                        Page2Item.FAutoTD1 = FAutoTD1;

                        cRouting.FAutoOF1 FAutoOF1 = new cRouting.FAutoOF1();
                        FAutoOF1.FNumber = dr["FAutoOFNum"].ToString();
                        FAutoOF1.FName = dr["FAutoOFName"].ToString();
                        Page2Item.FAutoOF1 = FAutoOF1;

                        Page2Item.FFare1 = dr["FFare"].ToString();

                        cRouting.FISOut1 FISOut1 = new cRouting.FISOut1();
                        FISOut1.FNumber = dr["FISOutNum"].ToString();
                        FISOut1.FName = dr["FISOutName"].ToString();
                        Page2Item.FISOut1 = FISOut1;


                        Page2Item.FResourceCount1 = dr["FResourceCount"].ToString();
                        Page2Item.FConversion1 = dr["FConversion"].ToString();

                        Page2Item.FMachStdTimeRun1 = dr["FMachStdTimeRun"].ToString();




                        d.Page2.Add(Page2Item);

                        i = i + 1;
                    }


                    Routing.Data = d;

                    this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(Routing);


                    AddItem(this.txtParamsIn.Text, @"/Routing/Save?token=", apiUrl, "Routing");
                }
            }
        }


        private void genBOMData(string apiUrl)
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            //根据Key读取<add>元素的Value
            //System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            // MessageBox.Show(config.AppSettings.Settings["connectionstring"].Value);
            SqlDataReader drAll = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_GetAllBOM");
            while (drAll.Read())
            {
                SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_IsExitBOMData", drAll["BOMNumber"].ToString());
                if (drIsExit.Read() == false)
                {
                    SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_GetBOMData", drAll["BOMNumber"].ToString());
                    int i = 1;
                    cBOM.BOM bom = new cBOM.BOM();
                    cBOM.Data d = new cBOM.Data();
                    while (dr.Read())
                    {




                        if (i == 1)
                        {

                            cBOM.Page1Item Page1Item = new cBOM.Page1Item();

                            // Page1Item.FBOMNumber = "BOM000005test111";
                            Page1Item.FVersion = drAll["BOMNumber"].ToString();
                            Page1Item.FPercentQty = double.Parse(dr["FQty"].ToString());
                            Page1Item.FYield = double.Parse(dr["FQty"].ToString());
                            Page1Item.FEntertime = System.DateTime.Now.ToString();


                            cBOM.FParentID FParentID = new cBOM.FParentID();
                            FParentID.FNumber = dr["FParentIDNum"].ToString();
                            FParentID.FName = dr["FParentName"].ToString();
                            Page1Item.FParentID = FParentID;

                            cBOM.FPercentItemID FPercentItemID = new cBOM.FPercentItemID();
                            FPercentItemID.FNumber = dr["FPercentItemIDNumber"].ToString();
                            FPercentItemID.FName = dr["FPercentItemIDName"].ToString();
                            Page1Item.FPercentItemID = FPercentItemID;

                            // Page1Item.FPercentItemName = "调压阀";

                            cBOM.FPercentUnitID FPercentUnitID = new cBOM.FPercentUnitID();
                            FPercentUnitID.FNumber = dr["FPercentUnitIDNum"].ToString();
                            FPercentUnitID.FName = dr["FPercentUnitIDName"].ToString();
                            Page1Item.FPercentUnitID = FPercentUnitID;

                            cBOM.FBOMSkip FBOMSkip = new cBOM.FBOMSkip();
                            FBOMSkip.FNumber = dr["FBOMSkipNumber"].ToString();
                            FBOMSkip.FName = dr["FBOMSkipName"].ToString();
                            Page1Item.FBOMSkip = FBOMSkip;


                            Page1Item.FHeadSelfZ0136 = drAll["BOMNumber"].ToString();


                            d.Page1.Add(Page1Item);
                        }



                        cBOM.Page2Item Page2Item = new cBOM.Page2Item();

                        Page2Item.FEntryID = i.ToString();

                        cBOM.FItemID FItemID = new cBOM.FItemID();
                        FItemID.FNumber = dr["FPercentItemIDNum"].ToString();
                        FItemID.FName = dr["FPercentItemIDName"].ToString();
                        Page2Item.FItemID = FItemID;

                        Page2Item.FAuxQtyScrap = double.Parse(dr["FQty"].ToString());
                        Page2Item.FScrap = double.Parse(dr["FScrap"].ToString());

                        cBOM.FMaterielType FMaterielType = new cBOM.FMaterielType();
                        FMaterielType.FNumber = dr["FMaterielTypeNum"].ToString();
                        FMaterielType.FName = dr["FMaterielTypeName"].ToString();
                        Page2Item.FMaterielType = FMaterielType;

                        cBOM.FStockID FStockID = new cBOM.FStockID();
                        FStockID.FNumber = dr["StockNum"].ToString();
                        FStockID.FName = dr["StockName"].ToString();
                        Page2Item.FStockID = FStockID;

                        cBOM.FUnitID FUnitID = new cBOM.FUnitID();
                        FUnitID.FNumber = dr["FUnitIDNum"].ToString();
                        FUnitID.FName = dr["FUnitIDName"].ToString();
                        Page2Item.FUnitID = FUnitID;


                        Page2Item.FBeginDay = dr["FBeginDay"].ToString();
                        Page2Item.FEndDay = dr["FEndDay"].ToString();


                        d.Page2.Add(Page2Item);

                        i = i + 1;
                    }


                    bom.Data = d;


                    this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(bom);


                    AddItem(this.txtParamsIn.Text, @"/BOM/Save?token=", apiUrl, "BOM");
                }
            }
        }

        private void genICItemData(string apiUrl)
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            //根据Key读取<add>元素的Value
            //System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            // MessageBox.Show(config.AppSettings.Settings["connectionstring"].Value);
            SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_getAddICItem");
            while (dr.Read())
            {
                //SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_IsExitsICItem");
                //if (drIsExit.Read() == false)
                //{
                    c_t_ICItem.t_ICItem item = new c_t_ICItem.t_ICItem();
                    c_t_ICItem.Data d = new c_t_ICItem.Data();
                    d.FNumber = dr["FNumber"].ToString();//编码
                    d.FName = dr["FName"].ToString();//名称


                //物料属性
                    c_t_ICItem.FErpClsID FErpClsID = new c_t_ICItem.FErpClsID();
                    FErpClsID.FID = dr["FErpClsIDNum"].ToString();
                    FErpClsID.FName = dr["FErpClsIDName"].ToString();
                    d.FErpClsID = FErpClsID;

                //订货策略
                    c_t_ICItem.FOrderTrategy FOrderTrategy = new c_t_ICItem.FOrderTrategy();
                    FOrderTrategy.FID = dr["FOrderTrategyNum"].ToString();
                    FOrderTrategy.FName = dr["FOrderTrategyName"].ToString();
                    d.FOrderTrategy = FOrderTrategy;

                //成本项目
                    c_t_ICItem.FCostAcctID FCostAcctID = new c_t_ICItem.FCostAcctID();
                    FCostAcctID.FNumber = dr["FCostAcctIDNum"].ToString();
                    FCostAcctID.FName = dr["FCostAcctIDName"].ToString();
                    d.FCostAcctID = FCostAcctID;

                //成本科目
                    c_t_ICItem.FCostProject FCostProject = new c_t_ICItem.FCostProject();
                    FCostProject.FNumber = dr["FCostProjectNum"].ToString();
                    FCostProject.FName = dr["FCostProjectName"].ToString();
                    d.FCostProject = FCostProject;

                //单位
                    c_t_ICItem.FUnitID FUnitID = new c_t_ICItem.FUnitID();
                    FUnitID.FNumber = dr["FUnitNumber"].ToString();
                    FUnitID.FName = dr["FUnitName"].ToString();
                    d.FUnitID = FUnitID;


                //采购计量单位
                    c_t_ICItem.FOrderUnitID FOrderUnitID = new c_t_ICItem.FOrderUnitID();
                    FOrderUnitID.FNumber = dr["FOrderUnitNumber"].ToString();
                    FOrderUnitID.FName = dr["FOrderUnitName"].ToString();
                    d.FOrderUnitID = FOrderUnitID;

                //生产计量单位
                    c_t_ICItem.FProductUnitID FProductUnitID = new c_t_ICItem.FProductUnitID();
                    FProductUnitID.FNumber = dr["FProductUnitNumber"].ToString();
                    FProductUnitID.FName = dr["FProductUnitName"].ToString();
                    d.FProductUnitID = FProductUnitID;

                //销售单位
                    c_t_ICItem.FSaleUnitID FSaleUnitID = new c_t_ICItem.FSaleUnitID();
                    FSaleUnitID.FNumber = dr["FSaleUnitNumber"].ToString();
                    FSaleUnitID.FName = dr["FSaleUnitName"].ToString();
                    d.FSaleUnitID = FSaleUnitID;

                //库存单位
                    c_t_ICItem.FStoreUnitID FStoreUnitID = new c_t_ICItem.FStoreUnitID();
                    FStoreUnitID.FNumber = dr["FStoreUnitNumber"].ToString();
                    FStoreUnitID.FName = dr["FStoreUnitName"].ToString();
                    d.FStoreUnitID = FStoreUnitID;


                //单位组内码
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FName = dr["UnitGroupName"].ToString();
                    FUnitGroupID.FNumber = dr["FUnitGroupID"].ToString();
                    d.FUnitGroupID = FUnitGroupID;



                //存货科目
                    c_t_ICItem.FAcctID FAcctID = new c_t_ICItem.FAcctID();
                    FAcctID.FNumber = dr["FAcctIDNum"].ToString();
                    FAcctID.FName = dr["FFAcctIDName"].ToString();
                    d.FAcctID = FAcctID;

                //变动提前期批量
                    d.FBatChangeEconomy = double.Parse(dr["FBatChangeEconomy"].ToString());
                //标准加工批量
                    d.FStdBatchQty = double.Parse(dr["FStdBatchQty"].ToString());
                //看板容量
                    d.FKanBanCapability = double.Parse(dr["FKanBanCapability"].ToString());

                    //d.F_134 = dr["OldFnumber"].ToString();
                //销售科目
                    c_t_ICItem.FSaleAcctID FSaleAcctID = new c_t_ICItem.FSaleAcctID();
                    FSaleAcctID.FNumber = dr["FSaleAcctIDNum"].ToString();
                    FSaleAcctID.FName = dr["FSaleAcctIDName"].ToString();
                    d.FSaleAcctID = FSaleAcctID;

                //计价方法
                    c_t_ICItem.FTrack FTrack = new c_t_ICItem.FTrack();
                    FTrack.FID = dr["FTrackNum"].ToString();
                    FTrack.FName = dr["FTrackName"].ToString();
                    d.FTrack = FTrack;


                    c_t_ICItem.FDSManagerID FDSManagerID = new c_t_ICItem.FDSManagerID();
                    FDSManagerID.FNumber = "";
                    FDSManagerID.FName = "";
                    d.FDSManagerID = FDSManagerID;




                    //盘点周期
                    d.FCheckCycle = 1;

                    item.Data = d;

                    this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(item);


                    AddItem(Newtonsoft.Json.JsonConvert.SerializeObject(item), @"/Material/Save?token=", apiUrl, "ICItem");
                //}
            }


            //c_t_ICItem.t_ICItem item = new c_t_ICItem.t_ICItem();
            //c_t_ICItem.Data d = new c_t_ICItem.Data();
            //d.FNumber = "1.01.01.001test";
            //d.FName = "50KW 柴油机整机test";


            //c_t_ICItem.FErpClsID FErpClsID = new c_t_ICItem.FErpClsID();
            //FErpClsID.FID = "ZZ";
            //FErpClsID.FName = "自制";
            //d.FErpClsID = FErpClsID;

            //c_t_ICItem.FOrderTrategy FOrderTrategy = new c_t_ICItem.FOrderTrategy();
            //FOrderTrategy.FID = "LFL";
            //FOrderTrategy.FName = "批对批(LFL)";
            //d.FOrderTrategy = FOrderTrategy;

            //c_t_ICItem.FCostAcctID FCostAcctID = new c_t_ICItem.FCostAcctID();
            //FCostAcctID.FNumber = "6401.01";
            //FCostAcctID.FName = "销售商品成本";
            //d.FCostAcctID = FCostAcctID;

            //c_t_ICItem.FCostProject FCostProject = new c_t_ICItem.FCostProject();
            //FCostProject.FNumber = "4001";
            //FCostProject.FName = "直接材料";
            //d.FCostProject = FCostProject;

            //c_t_ICItem.FUnitID FUnitID = new c_t_ICItem.FUnitID();
            //FUnitID.FNumber = "01";
            //FUnitID.FName = "个";
            //d.FUnitID = FUnitID;


            //c_t_ICItem.FOrderUnitID FOrderUnitID = new c_t_ICItem.FOrderUnitID();
            //FOrderUnitID.FNumber = "11";
            //FOrderUnitID.FName = "台";
            //d.FOrderUnitID = FOrderUnitID;

            //c_t_ICItem.FProductUnitID FProductUnitID = new c_t_ICItem.FProductUnitID();
            //FProductUnitID.FNumber = "11";
            //FProductUnitID.FName = "台";
            //d.FProductUnitID = FProductUnitID;

            //c_t_ICItem.FSaleUnitID FSaleUnitID = new c_t_ICItem.FSaleUnitID();
            //FSaleUnitID.FNumber = "11";
            //FSaleUnitID.FName = "台";
            //d.FSaleUnitID = FSaleUnitID;

            //c_t_ICItem.FStoreUnitID FStoreUnitID = new c_t_ICItem.FStoreUnitID();
            //FStoreUnitID.FNumber = "11";
            //FStoreUnitID.FName = "台";
            //d.FStoreUnitID = FStoreUnitID;



            //c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
            //FUnitGroupID.FName = "数量组";
            //FUnitGroupID.FNumber = "248";
            //d.FUnitGroupID = FUnitGroupID;




            //c_t_ICItem.FAcctID FAcctID = new c_t_ICItem.FAcctID();
            //FAcctID.FNumber = "1405";
            //FAcctID.FName = "库存商品";
            //d.FAcctID = FAcctID;

            //d.FBatChangeEconomy = 100;
            //d.FStdBatchQty = 1;
            //d.FKanBanCapability = 1;

            //c_t_ICItem.FSaleAcctID FSaleAcctID = new c_t_ICItem.FSaleAcctID();
            //FSaleAcctID.FNumber = "6001.01";
            //FSaleAcctID.FName = "销售商品收入";
            //d.FSaleAcctID = FSaleAcctID;

            //c_t_ICItem.FTrack FTrack = new c_t_ICItem.FTrack();
            //FTrack.FID = "F001";
            //FTrack.FName = "加权平均法";
            //d.FTrack = FTrack;


            //c_t_ICItem.FDSManagerID FDSManagerID = new c_t_ICItem.FDSManagerID();
            //FDSManagerID.FNumber = "";
            //FDSManagerID.FName = "";
            //d.FDSManagerID = FDSManagerID;




            //// d.FCheckCycle = 0;
            //d.FCheckCycle = 1;

            //item.Data = d;

            //    "FPlanTrategy":{
            //    "FID":"MPS",
            //    "FName":"主生产计划(MPS)"
            //},
            //"FPOHghPrcMnyType":{
            //    "FName":"人民币",
            //    "FNumber":"RMB"
            //},






        }


        private void genSeOrderData(string apiUrl)
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
           
            //SqlDataReader drAll = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_GetAllBOM");
            //while (drAll.Read())
            //{
            SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_getPOBillNo", this.textBoxIndenNum.Text);
            while (drIsExit.Read())
            {
                SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_getPOData", this.textBoxIndenNum.Text, drIsExit[0].ToString());
                int i = 1;
                POOrder.PO po = new POOrder.PO();
                POOrder.Data d = new POOrder.Data();
                while (dr.Read())
                {

                    if (i == 1)
                    {
                       // cSO.Page1 Page1Item = new cSO.Page1();
                        POOrder.Page1 Page1Item = new POOrder.Page1();

                        Page1Item.FTranType = 71;
                        Page1Item.FSysStatus = 2;
                        Page1Item.FStatus = 1;
                        Page1Item.FExchangeRate = 0;
                        

                        Page1Item.FBillNo = dr["PO"].ToString();
                        Page1Item.FHeadSelfP0265 = dr["Valid from"].ToString();
                        Page1Item.FHeadSelfP0266 = dr["Valid till"].ToString();
                        Page1Item.FHeadSelfP0262 = dr["Header"].ToString();                        
                        //                      
                        Page1Item.Fdate = dr["DeliveryD#"].ToString();                       

                        POOrder.FPlanCategory FPlanCategory = new POOrder.FPlanCategory();
                        FPlanCategory.FNumber = "STD";
                        FPlanCategory.FName = "标准";
                        Page1Item.FPlanCategory = FPlanCategory;

                        POOrder.FPOMode FPOMode = new POOrder.FPOMode();
                        FPOMode.FNumber = "PTCG";
                        FPOMode.FName = "普通采购";
                        Page1Item.FPOMode = FPOMode;

                        POOrder.FAreaPS FAreaPS = new POOrder.FAreaPS();
                        FAreaPS.FNumber = "1";
                        FAreaPS.FName = "购销";
                        Page1Item.FAreaPS = FAreaPS;

                        POOrder.FExchangeRateType FExchangeRateType = new POOrder.FExchangeRateType();
                        FExchangeRateType.FNumber = "01";
                        FExchangeRateType.FName = "公司汇率";
                        Page1Item.FExchangeRateType = FExchangeRateType;

                        POOrder.FCurrencyID FCurrencyID = new POOrder.FCurrencyID();
                        FCurrencyID.FNumber = dr["Currency"].ToString();
                        FCurrencyID.FName = dr["Currency"].ToString();
                        Page1Item.FCurrencyID = FCurrencyID;

                        POOrder.FDeptID FDeptID = new POOrder.FDeptID();
                        FDeptID.FNumber = dr["Dept#"].ToString();
                        FDeptID.FName = dr["Dept#"].ToString();
                        Page1Item.FDeptID = FDeptID;

                        POOrder.FEmpID FEmpID = new POOrder.FEmpID();
                        FEmpID.FNumber = dr["Purch#Gr#"].ToString();
                        FEmpID.FName = dr["Purch#Gr#"].ToString();
                        Page1Item.FEmpID = FEmpID;

                        POOrder.FSupplyID FSupplyID = new POOrder.FSupplyID();
                        FSupplyID.FNumber = dr["Vendor"].ToString();
                        FSupplyID.FName = dr["Vendor"].ToString();
                        Page1Item.FSupplyID = FSupplyID;

                        POOrder.FPOStyle FPOStyle = new POOrder.FPOStyle();
                        FPOStyle.FNumber = "PO02";
                        FPOStyle.FName = "赊购";
                        Page1Item.FPOStyle = FPOStyle;

                        Page1Item.Fdate = System.DateTime.Now.ToString();
                        Page1Item.FSettleDate = System.DateTime.Now.ToString();

                        d.Page1.Add(Page1Item);
                    }

                    POOrder.Page2 Page2Item = new POOrder.Page2();

                    //Page2Item.Fauxprice = 1;
                    //Page2Item.FAuxTaxPrice = 1.17;
                    //Page2Item.FAmount = 1800;
                    //Page2Item.FAuxPriceDiscount = 1.17;
                    //Page2Item.FCess = 17;
                    //Page2Item.FTaxAmount = 306;
                    //Page2Item.FAllAmount = 2106;
                    //Page2Item.FSourceTranType = 1000020;
                    //Page2Item.FSourceInterId = 1020;
                    //Page2Item.FSourceEntryID = 22;
                    //Page2Item.FContractInterID = 1020;
                    Page2Item.FEntryID2 = 1;

                    Page2Item.FEntrySelfP0268 = dr["Item"].ToString();//项目
                    Page2Item.Fnote = dr["Remark"].ToString();//备注
                    Page2Item.FQty = double.Parse(dr["Qty"].ToString());//数量
                    Page2Item.FAuxQty = double.Parse(dr["Qty"].ToString());//辅助订货数量
                    Page2Item.Fauxprice = double.Parse(dr["UnitPrice"].ToString());//辅助单价
                    Page2Item.FTaxPrice = double.Parse(dr["UnitPrice"].ToString());//含税单价(本位币)
                    Page2Item.FAuxTaxPrice = double.Parse(dr["UnitPrice"].ToString());//含税单价(本位币)
                    Page2Item.FPrice = double.Parse(dr["UnitPrice"].ToString());//单价
                    Page2Item.FAuxPriceDiscount = double.Parse(dr["UnitPrice"].ToString());
                    Page2Item.FPriceDiscount = double.Parse(dr["UnitPrice"].ToString());//实际含税单价
                    Page2Item.FAllAmount = double.Parse(dr["Qty"].ToString()) * double.Parse(dr["UnitPrice"].ToString());
                    Page2Item.FAmount = double.Parse(dr["Qty"].ToString()) * double.Parse(dr["UnitPrice"].ToString());
                    
                    Page2Item.FEntryID2 = i;


                    POOrder.FEntrySelfP0266 FEntrySelfP0266 = new POOrder.FEntrySelfP0266();
                    FEntrySelfP0266.FNumber = dr["Plant"].ToString();
                    FEntrySelfP0266.FName = dr["Plant"].ToString();
                    Page2Item.FEntrySelfP0266 = FEntrySelfP0266;

                    POOrder.FEntrySelfP0267 FEntrySelfP0267 = new POOrder.FEntrySelfP0267();
                    FEntrySelfP0267.FNumber = dr["SLOC"].ToString();
                    FEntrySelfP0267.FName = dr["SLOC"].ToString();
                    Page2Item.FEntrySelfP0267 = FEntrySelfP0267;

                    POOrder.FItemID FItemID = new POOrder.FItemID();
                    FItemID.FNumber = dr["Material"].ToString();
                    FItemID.FName = dr["Material"].ToString();
                    Page2Item.FItemID = FItemID;

                    POOrder.FUnitID FUnitID = new POOrder.FUnitID();
                    FUnitID.FNumber = dr["FNumber"].ToString();
                    FUnitID.FName = dr["FName"].ToString(); 
                    Page2Item.FUnitID = FUnitID;

                    POOrder.FPlanMode FPlanMode = new POOrder.FPlanMode();
                    FPlanMode.FNumber = "MTS";
                    FPlanMode.FName = "MTS计划模式";
                    Page2Item.FPlanMode = FPlanMode;

                    POOrder.FCheckMethod FCheckMethod = new POOrder.FCheckMethod();
                    FCheckMethod.FNumber = "MJ";
                    FCheckMethod.FName = "免检";
                    Page2Item.FCheckMethod = FCheckMethod;                    
               

                    d.Page2.Add(Page2Item);

                    i = i + 1;
                }

                po.Data = d;

                this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(po);

                AddItem(this.txtParamsIn.Text, @"/PO/Save?token=", apiUrl, "PO");
            }

        }

        /// <summary>
        /// 采购订单(PO) 获取明细
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        private void btnGetDetail_Click(object sender, EventArgs e)
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string authCode = this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            //this.txtResponse.Text = httpResponse;
            cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

            if (to.StatusCode == 200)
            {
                txtToken.Text = to.Data.Token;
                // getItemDetail(); //物料明细获取

                //新增物料
                //genICItemData();
                //AddItem(this.txtParamsIn.Text, @"/Material/Save?token=");
                // AddItem(this.txtResponse.Text);

                //获取BOM明细
               // getBOMDetail();

                //新增物料
                //genBOMData();
                //AddItem(this.txtParamsIn.Text, @"/BOM/Save?token=");

                //获取工艺路线
                // getRoutingDetail();

                //新增工艺路线
                //genRoutingData();
                // AddItem(this.txtParamsIn.Text, @"/Routing/Save?token=");
             
                //获取普通发票
                //getCommonInvoice();

                //新增普通发票
                // genICSaleCommon();
                //  AddItem(this.txtParamsIn.Text, @"/Bill1000000/Save?token=");

                //领料单
                //getPickListDetail();

                //新增领料单
                // genPackingList();
                // AddItem(this.txtParamsIn.Text, @"/PickList/Save?token=");
                //if (KYL(1003))
                //{
                //    AddItem(this.txtParamsIn.Text, @"/PickList/Save?token=");
                //}

                //调拨单
                //CheckPK();
                //getTransfer();

                //获取销售订单
                // getSODetail();
                genSeOrderData("");
               // AddItem(this.txtParamsIn.Text, @"/Routing/Save?token=");

            }

            //   getItemDetail();
            //            string apiUrl = this.txtUrl.Text.Trim();
            //            string token = this.txtToken.Text.Trim();

            //            string httpResponse = string.Empty;
            //            string postJson = @"{
            //                                 ""Data"": {
            //                                    ""FBillNo"": ""POORD000014""
            //                                }
            //                            }";
            //            string url = apiUrl+"/PO/GetDetail?Token=" + token;
            //            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            //            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //            //用户需要传入的参数
            //            this.txtParamsIn.Text = postJson;

            //            //接口返回的参数
            //            this.txtResponse.Text = httpResponse;

        }

        private void getItemDetail()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FNumber"": ""1.01.01.001""
                                },
                                ""GetProperty"": false
                            }";
            string url = apiUrl + "/Material/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void getSODetail()
        {

            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;

            if (IsSuceess(httpResponse))
            {

                // IsSuceess
                cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

                if (to.StatusCode == 200)
                //if (IsSuceess(httpResponse))
                {
                    txtToken.Text = to.Data.Token;

                    // string apiUrl = this.txtUrl.Text.Trim();
                    string token = this.txtToken.Text.Trim();

                    //string httpResponse = string.Empty;
                    string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""SEORD000066""
                                }                 
                            }";
                    string url1 = apiUrl + "/SO/GetDetail?Token=" + token;
                    byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
                    bool flag1 = HttpHelper.HttpPost(url1, data, out httpResponse, 30000);

                    //用户需要传入的参数
                    this.txtParamsIn.Text = postJson;

                    //接口返回的参数
                    this.txtResponse.Text = httpResponse;
                }
            }
        }

        private void getRoutingDetail()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""70001""
                                }                 
                            }";
            string url = apiUrl + "/Routing/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void getPickListDetail()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""SOUT000024""
                                }                 
                            }";
            string url = apiUrl + "/PickList/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void getTransfer()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""CHG000003""
                                }                 
                            }";
            string url = apiUrl + "/Transfer/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void CheckPK()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""SOUT000038"",
                                   ""FChecker"": ""administrator"",
                                   ""FCheckDirection"": ""1"",
                                    ""FDealComment"": ""
                                }                 
                            }";
            string url = apiUrl + "/PickList/CheckBill?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void getCommonInvoice()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""XSPP000009""
                                }                 
                            }";
            string url = apiUrl + "/Bill1000000/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void getBOMDetail()
        {
            string apiUrl = this.txtUrl.Text.Trim();
            string token = this.txtToken.Text.Trim();

            string httpResponse = string.Empty;
            string postJson = @"{
                                 ""Data"": {
                                    ""FBillNo"": ""BOM000005""
                                }                 
                            }";
            string url = apiUrl + "/BOM/GetDetail?token=" + token;
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;
        }

        private void AddItem(string json, string AddType, string apiUrl,string IType)
        {
            //string apiUrl = this.txtUrl.Text.Trim();
            string token = "63FD9BBF16FC2C343D708CEA56157C1861945458A7E95B1D4838FFC120BBB0F1A2304662E019DF94";

            string httpResponse = string.Empty;
            string postJson = json;
            string url = apiUrl + AddType + token;  //"/Material/Save?token="
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

            //用户需要传入的参数
            this.txtParamsIn.Text = postJson;

            //接口返回的参数
            this.txtResponse.Text = httpResponse;

            if (IsSuceess(httpResponse))
            {
                //System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
                ////更新已经同步标识
                //if (IType == "ICItem")
                //{
                //    SqlHelper.ExecuteNonQuery(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_TransFinish", FItemNum);
                //}
                //if (IType == "BOM")
                //{
                //    SqlHelper.ExecuteNonQuery(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_BOMTransFinish", FItemNum);
                //}
                //if (IType == "Routing")
                //{
                //    SqlHelper.ExecuteNonQuery(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_RoutingTransFinish", FItemNum);
                //}

                //if (IType == "SO")
                //{
                //    SOResult.SOResultSussces to = JsonConverter.DeserializeObject<SOResult.SOResultSussces>(httpResponse);

                //    if (to.StatusCode == 200)
                //    //MessageBox.Show(to.Data.BillInterID.ToString());


                //    SqlHelper.ExecuteNonQuery(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_SetDYDM", to.Data.BillInterID);
                //}

            }

        }

        private void AddK3Routing()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;
            if (IsSuceess(httpResponse))
            {
                cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

                if (to.StatusCode == 200)
                {
                    txtToken.Text = to.Data.Token;
                    // getItemDetail(); //物料明细获取

                    //新增物料
                    genRountingData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }
        }

        private void AddK3BOM()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;
            if (IsSuceess(httpResponse))
            {
                cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

                if (to.StatusCode == 200)
                {
                    txtToken.Text = to.Data.Token;
                    // getItemDetail(); //物料明细获取

                    //新增物料
                    genBOMData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }
        }
         private  string gainName(string join)
        {
            // 初始化字符串
            string str = join;
            //定义正则表达式规则
            Regex reg = new Regex("\"Token\": \"(\\w+)");
            //返回一个结果集
            MatchCollection result = reg.Matches(str);
            //遍历每个结果
            string Token = "";
            foreach (Match m in result)
            {
                //输出结果
                if (m.ToString().Contains("\"Token\": \""))
                {
                    Token = m.ToString().Replace("\"Token\": \"", "");
                }
                
            }
            return Token;
        }
        

        private void AddSO()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;
           
            string Token = gainName(httpResponse);
            if (IsSuceess(httpResponse))

            //if (IsSuceess(httpResponse))
            //{
                // IsSuceess
              //  cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);
                
                
              // if (to.StatusCode == 200)
                //if (IsSuceess(httpResponse))
                {
                    //txtToken.Text = to.Data.Token;
                    txtToken.Text = Token;
                    // getItemDetail(); //物料明细获取

                    //新增物料
                    genSeOrderData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }

        

        private void AddK3ICItem()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;
            if (IsSuceess(httpResponse))
            {
              
                // IsSuceess
                cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

                if (to.StatusCode == 200)
                //if (IsSuceess(httpResponse))
                {
                    txtToken.Text = to.Data.Token;
                    // getItemDetail(); //物料明细获取

                    //新增物料
                    genICItemData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }
            
        }

        /// <summary>
        ///  采购订单(PO) 新增
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {

            AddK3ICItem();
          
        }

        /// <summary>
        /// 采购订单(PO) 修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AddK3BOM();
        }

        /// <summary>
        /// 审核（只支持BOS审批流）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCheckBill_Click(object sender, EventArgs e)
        {
            AddK3Routing();
            
//            string apiUrl = this.txtUrl.Text.Trim();
//            string token = this.txtToken.Text.Trim();

//            string httpResponse = string.Empty;
//            string postJson = @"{
//                                ""Data"": {
//                                    ""FBillNo"": ""POORD000014"", 
//                                    ""FChecker"": ""administrator"", 
//                                    ""FCheckDirection"": ""1"", 
//                                    ""FDealComment"": """"
//                                }
//                            }";
//            string url = apiUrl + "/PO/CheckBill?Token=" + token;
//            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
//            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);

//            //用户需要传入的参数
//            this.txtParamsIn.Text = postJson;

//            //接口返回的参数
//            this.txtResponse.Text = httpResponse;
        }
        string Comstr;
        private void MainForm_Load(object sender, EventArgs e)
        {
            Comstr = "Data Source=127.0.0.1;Initial Catalog=K3ERP_JH1;User ID=user;Password=1";
            OldFileName = "";

        }

        private bool IsSuceess(string Response)
        {
            if (Response.IndexOf(": 200") > 0)
            {
               return true;

            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (OldFileName == this.textBoxFileName.Text)
            {
                MessageBox.Show("检测到是同一个路径、同一个文件名，不允许重复导入");
               
            }
            else
            {
                if (this.textBoxIndenNum.Text.Length > 5)
                {
                    AddSO();
                    OldFileName = openFileDialog1.FileName;
                }
            }
            //Log.Debug(this.txtParamsIn.Text);
            Log.Error(txtResponse.Text);
            //log4net.ILog log = log4net.LogManager.GetLogger("Logger");
            //if (log.IsDebugEnabled)
            //{
            //    log.Debug(txtResponse.Text);

            //}                 
        }

        private void EcxelToGridView(string Strconn, string BtnExcPath, string sheetName, string IndenNum, string E3ExcelInDBTableName)
        {
            //FileName = openFileDialog1.FileName;

            //ExcelIO ei = new ExcelIO();

            //DataSet ds = ei.ImportExcel(FileName);//sheet1

            //根据路径打开一个Excel文件并将数据填充到ds中
            string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = " + BtnExcPath + ";Extended Properties ='Excel 8.0;HDR=YES;IMEX=1'";
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Open();
            string strExcel = "";
            OleDbDataAdapter myCommand = null;

            strExcel = "select *  from [" + sheetName + "] where PO<>'' "; //and 借方金额+贷方金额<>0
            myCommand = new OleDbDataAdapter(strExcel, strConn);
            System.Data.DataSet ds = new System.Data.DataSet();
            myCommand.Fill(ds, "table1");
            conn.Close();
            //List<string> strList = new List<string>();
            //string str = string.Empty;
            //strList.Clear();
            if (ds.Tables["table1"].Rows.Count == 0)
            {
                MessageBox.Show("要导入的Excel没有数据");
            }
            else
            {
                System.Data.DataTable dt = ds.Tables[0].Copy();

               
                dt.Columns.Add(new DataColumn("FIdentity", System.Type.GetType("System.String")));


                int i;
                for (i = 0; i < dt.Rows.Count; i++)
                {
                   //dt.Rows[i]["PO"] = i+1;

                    dt.Rows[i]["FIdentity"] = IndenNum;

                }

                if (dt.Rows.Count > 0)
                {

                    this.buttonImportSO.Enabled = true;

                    this.textBoxIndenNum.Text = IndenNum;

                }
                else
                {
                    this.buttonImportSO.Enabled = false;
                    this.textBoxIndenNum.Text = "";
                }

              //  DeleteOldData(IndenNum);
                DtToDb(Strconn,E3ExcelInDBTableName, dt);

//                string strSqlUpdate = "UPDATE t_DD_VoucherExcelModel SET [科目代码]=replace([科目代码],',','') WHERE CHARINDEX(',',[科目代码],0)>0";

//                SqlHelper.ExecuteNonQuery(strconnection, CommandType.Text, strSqlUpdate);
//                string strsqlGetdata = "SELECT * FROM [dbo].[t_DD_VoucherExcelModel] WHERE [FIdentity]=@FIdentity ORDER BY [FEntryID]";
//                SqlParameter[] para = new SqlParameter[]
//{
//new SqlParameter("FIdentity",IndenNum)
//};
                System.Data.DataTable dtGetData = SqlHelper.ExecuteDataset(Strconn, "pr_kl_getExcelData", IndenNum).Tables[0];
                dataGridView1.DataSource = dtGetData;
               // LabelCount.Text = dtGetData.Rows.Count.ToString();

                //this.dataGridView1.DataSource = ds.Tables["table1"];
            }
        }

        private void DtToDb(string strconnection,string tableName, System.Data.DataTable dt)
        {
            SqlBulkCopy sbc = new SqlBulkCopy(strconnection, SqlBulkCopyOptions.UseInternalTransaction);
            sbc.NotifyAfter = dt.Rows.Count;
            sbc.DestinationTableName = tableName;
            sbc.WriteToServer(dt);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Excel文件(*.xls)|*.xls";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                this.textBoxFileName.Text = openFileDialog1.FileName;
              

                System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

                string strconn = config.AppSettings.Settings["connectionstring"].Value;

                Random ro = new Random();
               string IndenNum = System.DateTime.Now.ToString() + "," + ro.Next().ToString();
                if (openFileDialog1.FileName.Length>10)
                {

                    EcxelToGridView(strconn, openFileDialog1.FileName, "Sheet1$", IndenNum, "t_kl_POOrder");
                }
                //FileName = openFileDialog1.FileName;              

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            getSODetail();

        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            AddK3ICItem();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }
    }
}
