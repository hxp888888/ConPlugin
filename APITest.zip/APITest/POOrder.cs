﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class POOrder
    {
        public class FHeadSelfP0264
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FHeadSelfP0269
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAreaPS
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSettleID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBrID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPOStyle
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FRelateBrID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSupplyID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCurrencyID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPlanCategory
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FExchangeRateType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPOMode
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FMangerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FDeptID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FEmpID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBillerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FConsignee
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FChangeUser
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FCancellation { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FClassTypeID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEnterpriseID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0252 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0253 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0254 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0255 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0256 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0257 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0258 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0259 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0260 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0261 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0262 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0263 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FHeadSelfP0264 FHeadSelfP0264 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0265 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0266 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0267 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHeadSelfP0268 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FHeadSelfP0269 FHeadSelfP0269 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSendStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fdate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAreaPS FAreaPS { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSettleID FSettleID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBrID FBrID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPOStyle FPOStyle { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FRelateBrID FRelateBrID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSettleDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSupplyID FSupplyID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPOOrdBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FExplanation { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCurrencyID FCurrencyID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSelTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSelBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FExchangeRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDeliveryPlace { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Attachments { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPrintCount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanCategory FPlanCategory { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FExchangeRateType FExchangeRateType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPOMode FPOMode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMangerID FMangerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDeptID FDeptID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FEmpID FEmpID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBillerID FBillerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FManageType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FConsignee FConsignee { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FSysStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FValidaterName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FVersionNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FChangeDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FChangeUser FChangeUser { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FChangeCauses { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FChangeMark { get; set; }
        }

        public class FEntrySelfP0266
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FEntrySelfP0267
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckMethod
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FMapNumber
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSupConfirmor
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPlanMode
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page2
        {
            /// <summary>
            /// 
            /// </summary>
            public double FEntryID2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntrySelfP0264 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntrySelfP0265 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FEntrySelfP0266 FEntrySelfP0266 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FEntrySelfP0267 FEntrySelfP0267 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntrySelfP0268 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntrySelfP0269 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntrySelfP0270 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsCheck { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckMethod FCheckMethod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOutSourceEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOutSourceInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOutSourceTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMapNumber FMapNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMapName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAuxPropID FAuxPropID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBaseUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecCoefficient { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double Fauxprice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxTaxPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FTaxPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTaxRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxPriceDiscount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FPriceDiscount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDescount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FCess { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FTaxAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAllAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fdate1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fnote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCommitQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxReceiptQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxCommitQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecCommitQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxReturnQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStockQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecStockQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxStockQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FSourceTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntryAccessoryCount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FSourceInterId { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FSourceEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRefuseNote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContractBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRejectRefuseNote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FContractInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSupConDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContractEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSupConFetchDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxQtyInvoice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSupConfirm { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecInvoiceQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSupConfirmor FSupConfirmor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQtyInvoice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSupConMem { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxPropCls { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSupConQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMrpLockFlag { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FReceiveAmountFor_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanMode FPlanMode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMTONo { get; set; }
        }

        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public List<Page1> Page1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page2> Page2 { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public Data()
            {
                Page1 = new List<Page1>();
                Page2 = new List<Page2>();
            }
        }
        public class PO
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}



