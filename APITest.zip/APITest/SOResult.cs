﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
   public class SOResult
    {
        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public int BillInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string BillNo { get; set; }
        }

        public class SOResultSussces
        {
            /// <summary>
            /// 
            /// </summary>
            public int StatusCode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Message { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
