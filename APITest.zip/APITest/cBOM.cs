﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class cBOM
    {
        public class FParentID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPercentAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBOMUseStatus
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPercentUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FRoutingID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBOMSkip
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPercentItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1Item
        {
            /// <summary>
            /// 
            /// </summary>
            public FParentID FParentID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBOMNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FVersion { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPercentAuxPropID FPercentAuxPropID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAudDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPercentErpClsID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBOMUseStatus FBOMUseStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPercentItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPercentUnitID FPercentUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPercentItemModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRoutingName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FRoutingID FRoutingID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBOMSkip FBOMSkip { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPercentItemID FPercentItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FPercentQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FYield { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsCharSourceItem { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntertime { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckDate { get; set; }
             /// <summary>
            /// 
            /// </summary>

            public string FHeadSelfZ0136 { get; set; }
            
        }

        public class FItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FMaterielType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FOperID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSPID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FStockID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBackFlush
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FMarshalType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page2Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FErpClsID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsPrimary { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMaterielType FMaterielType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOperID FOperID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOperSN { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMachinePos { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPositionNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxQtyScrap { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSPID FSPID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FStockID FStockID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FScrap { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FUseStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBeginDay { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEndDay { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBackFlush FBackFlush { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemSize { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemSuite { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMarshalType FMarshalType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPercent { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FForbitUse { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOffSetDay { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAuxPropID FAuxPropID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxClassID { get; set; }
        }

        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public List<Page1Item> Page1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page2Item> Page2 { get; set; }

            public Data()
            {
                Page1 = new List<Page1Item>();
                Page2 = new List<Page2Item>();
           
             }
        }

        public class BOM
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
