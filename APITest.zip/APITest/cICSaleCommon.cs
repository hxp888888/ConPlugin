﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    //销售订单字段
    class cICSaleCommon
    {
        public class FItemClassID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCustID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FExchangeRateType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCurrencyID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSaleStyle
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSettleID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FDeptID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FEmpID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBillerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FTaskID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FResourceID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FOrderID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FHookerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FConfirmor
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPayCondition
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FJSBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FJSExported { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FItemClassID FItemClassID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCustID FCustID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDate { get; set; }

       
            /// <summary>
            /// 
            /// </summary>
            public string FFincDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FClassTypeID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FExchangeRateType FExchangeRateType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCurrencyID FCurrencyID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FExchangeRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInterestRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAdjustExchangeRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTaxNum { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAcctID FAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSaleStyle FSaleStyle { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSettleNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSettleID FSettleID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCompactNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillNo1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDeptID FDeptID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FEmpID FEmpID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBillerID FBillerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FTaskID FTaskID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FResourceID FResourceID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPosterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBudgetAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOrderID FOrderID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FVchInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBillStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFreeItem3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FROB { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFreeItem4 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FArApStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAdjustAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FYear { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPeriod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSubSystemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAddress { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FYearPeriod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPrintCount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAccount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FHookerID FHookerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRegion { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBank { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTrade { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckAmountForBill { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckAmountBill { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmountForBill { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmountBill { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSysStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FObtainRateWay { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FConfirmAdvice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FConfirmor FConfirmor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FConfirmDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FText { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FText1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FConfirmFlag { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FJSDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPayCondition FPayCondition { get; set; }
        }

        public class Page2Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FEntryID2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string fdate_2 { get; set; }

            public string FEntrySelfS0171 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrgID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmount2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRP { get; set; }
        }

        public class FItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSecUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FClassID_SRC
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page3Item
        {
            /// <summary>
            /// 
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemID36422 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemID36436 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEntryID3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAuxPropID FAuxPropID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQuantityPayApply_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQuantityReceive_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSecUnitID FSecUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FsecCoefficient { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxTaxPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDiscountRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceInterId { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPriceDiscount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmtDiscount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStdAmtDiscount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmount3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTaxPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStdAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContractEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public Int32 FEntryID_SRC { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTaxRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTaxAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFreeItem3_3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFreeItem4_3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStdTaxAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmountIncludeTax { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStdAmountIncludeTax { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNote_3 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBatchNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBaseUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxOrderPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FClassID_SRC FClassID_SRC { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContractBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLinkCheckAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLinkCheckAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmountForEntry { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLinkCheckQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainAmountEntry { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRemainQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmountFor_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAmount_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvLinkCheckAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvoiceAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvoiceAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvLinkCheckAmountFor { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvLinkCheckQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FInvoiceQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FConfirmAdviceEntry { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOnLineOrderNo { get; set; }
        }

        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public List<Page1Item> Page1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page2Item> Page2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page3Item> Page3 { get; set; }

            public Data()
            {
                Page1 = new List<Page1Item>();
                Page2 = new List<Page2Item>();
                Page3 = new List<Page3Item>();

            }
        }

        public class ICSaleCommon
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
