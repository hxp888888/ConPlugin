﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class cPakingList
    {
        public class FPurposeID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 一般领料
            /// </summary>
            public string FName { get; set; }
        }

        public class FAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FDeptID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 机加车间
            /// </summary>
            public string FName { get; set; }
        }

        public class FSCStockID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBillReviewer
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSManagerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 王刚
            /// </summary>
            public string FName { get; set; }
        }

        public class FFManagerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 王刚
            /// </summary>
            public string FName { get; set; }
        }

        public class FBillerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBackFlushed { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FWBINTERID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBrNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FClassTypeID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FVchInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FManageType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPurposeID FPurposeID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAcctID FAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDeptID FDeptID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fuse { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fdate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSCStockID FSCStockID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBillReviewer FBillReviewer { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPosterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSManagerID FSManagerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FFManagerID FFManagerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBillerID FBillerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBillReviewDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FROB { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FReProduceType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 否
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCostOBJID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// V形圈
            /// </summary>
            public string FName { get; set; }
        }

        public class FSCStockID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 原料仓
            /// </summary>
            public string FName { get; set; }
        }

        public class FAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCostObjGroupID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBomInterID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FIsVMI
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FEntrySupply
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FDCSPID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FOperID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCostCenterID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPlanMode
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// MTS计划模式
            /// </summary>
            public string FName { get; set; }
        }

        public class Page2Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBaseUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FKFPeriod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FQtyMust { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double Fauxprice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCostOBJNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCostOBJModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double Famount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBatchNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxQtyMust { get; set; }
            /// <summary>
            /// 
            /// </summary>
          //  public DateTime FKFDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double Fauxqty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStockQtyOnlyForShow { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSecCoefficient { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FSecQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FAuxPlanPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPeriodDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FPlanAmount { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FReviewBillsQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOperSN { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSNListID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsSNManage { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSourceTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSourceInterId { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FICMOBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FICMOInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPPBomEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FAuxPropCls { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FInStockID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMTONo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPositionNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemSize { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemSuite { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSourceEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBrNo2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FInterID2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FEntryID2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FDetailID2 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fnote { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FReProduceType FReProduceType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCostOBJID FCostOBJID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSCStockID1 FSCStockID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAuxPropID FAuxPropID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCostObjGroupID FCostObjGroupID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBomInterID FBomInterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FIsVMI FIsVMI { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FEntrySupply FEntrySupply { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDCSPID FDCSPID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOperID FOperID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCostCenterID FCostCenterID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanMode FPlanMode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public List<Page1Item> Page1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page2Item> Page2 { get; set; }

            public Data()
            {
                Page1 = new List<Page1Item>();
                Page2 = new List<Page2Item>();

            }
        }

        public class PakingList
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
