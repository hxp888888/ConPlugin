﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class cRouting
    {
        public class FItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FParentID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBillNO { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRoutingName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FParentName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fdefault { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FParentID FParentID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCheckDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FClassTypeID { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string fheadselfZ0216 { get; set; }
        }

        public class FOperID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FOperName1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FWorkCenterID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FTimeUnit1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAutoTD1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FAutoOF1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FISOut1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSupplyID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FQualityShcemeID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FFManagerID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FTeamID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FWorkerID1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page2Item
        {
            /// <summary>
            /// 
            /// </summary>
            public string FIndex { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOperSN1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOperID1 FOperID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOperName1 FOperName1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fnote1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FWorkCenterID1 FWorkCenterID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDeptID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FTimeUnit1 FTimeUnit1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLeadTime1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTimeSetup1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FWorkQty1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FTimeRun1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMoveQty1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMoveTime1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAutoTD1 FAutoTD1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAutoOF1 FAutoOF1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFare1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FISOut1 FISOut1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSupplyID1 FSupplyID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFee1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQualityChkID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FQualityShcemeID1 FQualityShcemeID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FFManagerID1 FFManagerID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FTeamID1 FTeamID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FWorkerID1 FWorkerID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FDeviceID1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FResourceCount1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FConversion1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPieceRate1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMachStdTimeSetup1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMachStdTimeRun1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPersonStdTimeSetup1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPersonStdTimeRun1 { get; set; }
        }

        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public List<Page1Item> Page1 { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public List<Page2Item> Page2 { get; set; }

            public Data()
            {
                Page1 = new List<Page1Item>();
                Page2 = new List<Page2Item>();

            }
        }

        public class Routing
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
