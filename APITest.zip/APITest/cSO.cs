﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class cSO
    {
        public class FPlanCategory
        {
            /// <summary>
            /// STD
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 标准
            /// </summary>
            public string FName { get; set; }
        }

        public class FConsignee
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCustID
        {
            /// <summary>
            /// 002
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 东方机电
            /// </summary>
            public string FName { get; set; }
        }

        public class FAreaPS
        {
            /// <summary>
            /// 1
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 购销
            /// </summary>
            public string FName { get; set; }
        }

        public class FSettleID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FRelateBrID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FSaleStyle
        {
            /// <summary>
            /// FXF02
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 赊销
            /// </summary>
            public string FName { get; set; }
        }

        public class FBrID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FExchangeRateType
        {
            /// <summary>
            /// 01
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 公司汇率
            /// </summary>
            public string FName { get; set; }
        }

        public class FFetchStyle
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCurrencyID
        {
            /// <summary>
            /// RMB
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 人民币
            /// </summary>
            public string FName { get; set; }
        }

        public class FChangeUser
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCheckerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FDeptID
        {
            /// <summary>
            /// 000
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 销售一部
            /// </summary>
            public string FName { get; set; }
        }

        public class FEmpID
        {
            /// <summary>
            /// 003
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 王刚
            /// </summary>
            public string FName { get; set; }
        }

        public class FMangerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBillerID
        {
            /// <summary>
            /// Administrator
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// Administrator
            /// </summary>
            public string FName { get; set; }
        }

        public class FCustAddress
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class Page1
        {
            /// <summary>
            /// 
            /// </summary>
            public string FValidaterName { get; set; }
            /// <summary>
            /// FInterID
            /// </summary>
            public int FInterID { get; set; }
            /// <summary>
            /// FTranType
            /// </summary>
            public int FTranType { get; set; }
            /// <summary>
            /// FPlanCategory
            /// </summary>
            public FPlanCategory FPlanCategory { get; set; }
            /// <summary>
            /// FManageType
            /// </summary>
            public int FManageType { get; set; }
            /// <summary>
            /// FImport
            /// </summary>
            public int FImport { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPOOrdBillNo { get; set; }
            /// <summary>
            /// FConsignee
            /// </summary>
            public FConsignee FConsignee { get; set; }
            /// <summary>
            /// FCustID
            /// </summary>
            public FCustID FCustID { get; set; }
            /// <summary>
            /// 2019-10-15 00:00:00
            /// </summary>
            public DateTime FSettleDate { get; set; }
            /// <summary>
            /// FSysStatus
            /// </summary>
            public int FSysStatus { get; set; }
            /// <summary>
            /// SEORD000020
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// FAreaPS
            /// </summary>
            public FAreaPS FAreaPS { get; set; }
            /// <summary>
            /// FSettleID
            /// </summary>
            public FSettleID FSettleID { get; set; }
            /// <summary>
            /// FRelateBrID
            /// </summary>
            public FRelateBrID FRelateBrID { get; set; }
            /// <summary>
            /// FSaleStyle
            /// </summary>
            public FSaleStyle FSaleStyle { get; set; }
            /// <summary>
            /// FTransitAheadTime
            /// </summary>
            public int FTransitAheadTime { get; set; }
            /// <summary>
            /// FBrID
            /// </summary>
            public FBrID FBrID { get; set; }
            /// <summary>
            /// FExchangeRateType
            /// </summary>
            public FExchangeRateType FExchangeRateType { get; set; }
            /// <summary>
            /// FFetchStyle
            /// </summary>
            public FFetchStyle FFetchStyle { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFetchAdd { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FExplanation { get; set; }
            /// <summary>
            /// FCurrencyID
            /// </summary>
            public FCurrencyID FCurrencyID { get; set; }
            /// <summary>
            /// 2019-10-15 00:00:00
            /// </summary>
            public DateTime Fdate { get; set; }
            /// <summary>
            /// FExchangeRate
            /// </summary>
            public double FExchangeRate { get; set; }

            //客户PO
            public string FHeadSelfS0158 { get; set; }
            /// <summary>
            /// 000
            /// </summary>
            public string FVersionNo { get; set; }
            /// <summary>
            /// FChangeMark
            /// </summary>
            public int FChangeMark { get; set; }
            /// <summary>
            /// FChangeDate
            /// </summary>
            public string FChangeDate { get; set; }
            /// <summary>
            /// FChangeUser
            /// </summary>
            public FChangeUser FChangeUser { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FChangeCauses { get; set; }
            /// <summary>
            /// 2
            /// </summary>
            public string FMultiCheckStatus { get; set; }
            /// <summary>
            /// FCheckerID
            /// </summary>
            public FCheckerID FCheckerID { get; set; }
            /// <summary>
            /// FCheckDate
            /// </summary>
            public string FCheckDate { get; set; }
            /// <summary>
            /// FDeptID
            /// </summary>
            public FDeptID FDeptID { get; set; }
            /// <summary>
            /// FEmpID
            /// </summary>
            public FEmpID FEmpID { get; set; }
            /// <summary>
            /// FMangerID
            /// </summary>
            public FMangerID FMangerID { get; set; }
            /// <summary>
            /// FBillerID
            /// </summary>
            public FBillerID FBillerID { get; set; }
            /// <summary>
            /// FCustAddress
            /// </summary>
            public FCustAddress FCustAddress { get; set; }
            /// <summary>
            /// FCancellation
            /// </summary>
            public bool FCancellation { get; set; }
            /// <summary>
            /// FClassTypeID
            /// </summary>
            public int FClassTypeID { get; set; }
            /// <summary>
            /// FEnterpriseID
            /// </summary>
            public int FEnterpriseID { get; set; }
            /// <summary>
            /// FSendStatus
            /// </summary>
            public int FSendStatus { get; set; }
            /// <summary>
            /// FStatus
            /// </summary>
            public int FStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FATPDeduct
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FMapNumber
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FItemID
        {
            /// <summary>
            /// 1.01.01.001
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 50KW 柴油机整机
            /// </summary>
            public string FName { get; set; }
        }

        public class FAuxPropID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 11
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 台
            /// </summary>
            public string FName { get; set; }
        }

        public class FInForecast
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FPlanMode
        {
            /// <summary>
            /// MTO
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// MTO计划模式
            /// </summary>
            public string FName { get; set; }
        }

        public class FBomInterID
        {
            /// <summary>
            /// SEORD000020_1
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// SEORD000020_1
            /// </summary>
            public string FName { get; set; }
        }

        public class FCostObjectID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FBOMCategory
        {
            /// <summary>
            /// LDBOM
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 订单BOM
            /// </summary>
            public string FName { get; set; }
        }

        public class FOrderBOMStatus
        {
            /// <summary>
            /// PZZ
            /// </summary>
            public string FNumber { get; set; }
            /// <summary>
            /// 配置中
            /// </summary>
            public string FName { get; set; }
        }

        public class Page2
        {
            

 

          

            /// <summary>
            /// 客户订单号1
            /// </summary>
            public string FEntrySelfS0164 { get; set; }

            /// <summary>
            /// S
            /// </summary>
            public string FEntrySelfS0161 { get; set; } 


             /// <summary>
            /// LB
            /// </summary>
            public string FEntrySelfS0168 { get; set; } 


            /// <summary>
            /// 客户交期
            /// </summary>
            public DateTime FEntrySelfS0163 { get; set; }


             /// <summary>
            /// PC首次交期
            /// </summary>
            public DateTime FEntrySelfS01101 { get; set; }

             /// <summary>
            /// CS要求交期
            /// </summary>
            public DateTime FEntrySelfS0179 { get; set; }

            //现场到货时间
            public DateTime FEntrySelfS0171 { get; set; }
            

            /////////////////////////////////////////////////////////////////////////////

      
            /// <summary>
            /// FEntrySelfS0169
            /// </summary>
            public string FEntrySelfS0169 { get; set; }
            /// <summary>
            /// FOutSourceEntryID
            /// </summary>
            public int FOutSourceEntryID { get; set; }
            /// <summary>
            /// FOutSourceInterID
            /// </summary>
            public int FOutSourceInterID { get; set; }
            /// <summary>
            /// FOutSourceTranType
            /// </summary>
            public int FOutSourceTranType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMapName { get; set; }
            /// <summary>
            /// 50KW 柴油机整机
            /// </summary>
            public string FItemName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FItemModel { get; set; }
            /// <summary>
            /// 个
            /// </summary>
            public string FBaseUnit { get; set; }
            /// <summary>
            /// FQty
            /// </summary>
            public double FQty { get; set; }
            /// <summary>
            /// Fauxqty
            /// </summary>
            public double Fauxqty { get; set; }
            /// <summary>
            /// FSecUnitID
            /// </summary>
            public string FSecUnitID { get; set; }
            /// <summary>
            /// FSecCoefficient
            /// </summary>
            public int FSecCoefficient { get; set; }
            /// <summary>
            /// FSecQty
            /// </summary>
            public int FSecQty { get; set; }
            /// <summary>
            /// Fauxprice
            /// </summary>
            public double Fauxprice { get; set; }
            /// <summary>
            /// FAuxTaxPrice
            /// </summary>
            public double FAuxTaxPrice { get; set; }
            /// <summary>
            /// Famount
            /// </summary>
            public double Famount { get; set; }
            /// <summary>
            /// FCess
            /// </summary>
            public double FCess { get; set; }
            /// <summary>
            /// FTaxRate
            /// </summary>
            public int FTaxRate { get; set; }
            /// <summary>
            /// FUniDiscount
            /// </summary>
            public int FUniDiscount { get; set; }
            /// <summary>
            /// FTaxAmount
            /// </summary>
            public int FTaxAmount { get; set; }
            /// <summary>
            /// FAuxPriceDiscount
            /// </summary>
            public double FAuxPriceDiscount { get; set; }
            /// <summary>
            /// FTaxAmt
            /// </summary>
            public double FTaxAmt { get; set; }
            /// <summary>
            /// FAllAmount
            /// </summary>
            public double FAllAmount { get; set; }
            /// <summary>
            /// FTranLeadTime
            /// </summary>
            public int FTranLeadTime { get; set; }
            /// <summary>
            /// 2019-10-25 00:00:00
            /// </summary>
            public DateTime FDate1 { get; set; }
            /// <summary>
            /// FCommitQty
            /// </summary>
            public int FCommitQty { get; set; }
            /// <summary>
            /// FAuxCommitQty
            /// </summary>
            public int FAuxCommitQty { get; set; }
            /// <summary>
            /// FSecCommitQty
            /// </summary>
            public int FSecCommitQty { get; set; }
            /// <summary>
            /// FSecStockQty
            /// </summary>
            public int FSecStockQty { get; set; }
            /// <summary>
            /// FStockQty
            /// </summary>
            public int FStockQty { get; set; }
            /// <summary>
            /// FAuxStockQty
            /// </summary>
            public int FAuxStockQty { get; set; }
            /// <summary>
            /// SEORD000020-001
            /// </summary>
            public string FMTONo { get; set; }
            /// <summary>
            /// 2019-10-25 00:00:00
            /// </summary>
            public DateTime FAdviceConsignDate { get; set; }
            /// <summary>
            /// FLockFlag
            /// </summary>
            public int FLockFlag { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSourceBillNo { get; set; }
            /// <summary>
            /// FSourceTranType
            /// </summary>
            public int FSourceTranType { get; set; }
            /// <summary>
            /// FOrderBOMInterID
            /// </summary>
            public int FOrderBOMInterID { get; set; }
            /// <summary>
            /// FSourceInterId
            /// </summary>
            public int FSourceInterId { get; set; }
            /// <summary>
            /// FSourceEntryID
            /// </summary>
            public int FSourceEntryID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContractBillNo { get; set; }
            /// <summary>
            /// FContractInterID
            /// </summary>
            public int FContractInterID { get; set; }
            /// <summary>
            /// FContractEntryID
            /// </summary>
            public int FContractEntryID { get; set; }
            /// <summary>
            /// FAuxQtyInvoice
            /// </summary>
            public int FAuxQtyInvoice { get; set; }
            /// <summary>
            /// FSecInvoiceQty
            /// </summary>
            public int FSecInvoiceQty { get; set; }
            /// <summary>
            /// FQtyInvoice
            /// </summary>
            public int FQtyInvoice { get; set; }
            /// <summary>
            /// FSecCommitInstall
            /// </summary>
            public int FSecCommitInstall { get; set; }
            /// <summary>
            /// FCommitInstall
            /// </summary>
            public int FCommitInstall { get; set; }
            /// <summary>
            /// FAuxCommitInstall
            /// </summary>
            public int FAuxCommitInstall { get; set; }
            /// <summary>
            /// FAuxPropCls
            /// </summary>
            public int FAuxPropCls { get; set; }
            /// <summary>
            /// FAllStdAmount
            /// </summary>
            public double FAllStdAmount { get; set; }
            /// <summary>
            /// FMrpLockFlag
            /// </summary>
            public int FMrpLockFlag { get; set; }
            /// <summary>
            /// FHaveMrp
            /// </summary>
            public int FHaveMrp { get; set; }
            /// <summary>
            /// FReceiveAmountFor_Commit
            /// </summary>
            public int FReceiveAmountFor_Commit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOrderBillNo { get; set; }
            /// <summary>
            /// FOrderEntryID
            /// </summary>
            public int FOrderEntryID { get; set; }
            /// <summary>
            /// FDetailID2
            /// </summary>
            public int FDetailID2 { get; set; }
            /// <summary>
            /// FInterID2
            /// </summary>
            public int FInterID2 { get; set; }
            /// <summary>
            /// FEntryID2
            /// </summary>
            public int FEntryID2 { get; set; }
            /// <summary>
            /// FATPDeduct
            /// </summary>
            public FATPDeduct FATPDeduct { get; set; }
            /// <summary>
            /// FMapNumber
            /// </summary>
            public FMapNumber FMapNumber { get; set; }
            /// <summary>
            /// FItemID
            /// </summary>
            public FItemID FItemID { get; set; }
            /// <summary>
            /// FAuxPropID
            /// </summary>
            public FAuxPropID FAuxPropID { get; set; }
            /// <summary>
            /// FUnitID
            /// </summary>
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// FInForecast
            /// </summary>
            public FInForecast FInForecast { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Fnote { get; set; }
            /// <summary>
            /// FPlanMode
            /// </summary>
            public FPlanMode FPlanMode { get; set; }
            /// <summary>
            /// FBomInterID
            /// </summary>
            public FBomInterID FBomInterID { get; set; }
            /// <summary>
            /// FCostObjectID
            /// </summary>
            public FCostObjectID FCostObjectID { get; set; }
            /// <summary>
            /// FBOMCategory
            /// </summary>
            public FBOMCategory FBOMCategory { get; set; }
            /// <summary>
            /// FOrderBOMStatus
            /// </summary>
            public FOrderBOMStatus FOrderBOMStatus { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }

           

        }

        public class Data
        {
            /// <summary>
            /// Page1
            /// </summary>
            public List<Page1> Page1 { get; set; }
            /// <summary>
            /// Page2
            /// </summary>
            public List<Page2> Page2 { get; set; }

            public Data()
            {
                Page1 = new List<Page1>();
                Page2 = new List<Page2>();

            }
        }

        public class SO
        {
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }



    }
}
