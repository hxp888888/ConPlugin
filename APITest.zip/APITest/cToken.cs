﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    class cToken
    {
        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
            public int AcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int UserID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Token { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Code { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double Validity { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string IPAddress { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Language { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string Create { get; set; }
        }

        public class Token
        {
            /// <summary>
            /// 
            /// </summary>
            public int StatusCode { get; set; }
            /// <summary>
            /// Token申请成功!
            /// </summary>
            public string Message { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public Data Data { get; set; }
        }
    }
}
