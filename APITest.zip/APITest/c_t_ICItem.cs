﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APITest
{
    //物料字段
    class c_t_ICItem
    {
        //public class F_101
        //{
        //    /// <summary>
        //    /// 
        //    /// </summary>
        //    public string FName { get; set; }
        //    /// <summary>
        //    /// 
        //    /// </summary>
        //    public string FNumber { get; set; }
        //}
        
        /// <summary>
        /// 科目
        /// </summary>
        public class FAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FAdminAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FAPAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FAuxClassID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FBackFlushSPID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FBackFlushStockID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCAVAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCBAppendProject
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCBRouting
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRoutingName { get; set; }
        }

        public class FCharSourceItemID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCheckCycUnit
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCostAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCostBomID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBOMNumber { get; set; }
        }

        public class FCostProject
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FCtrlStraregy
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCtrlType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FCubicMeasure
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FDefaultLoc
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FDefaultReadyLoc
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FDefaultRoutingID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FRoutingName { get; set; }
        }

        public class FDefaultWorkTypeID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FDSManagerID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FErpClsID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 外购
            /// </summary>
            public string FName { get; set; }
        }

        public class FGoodSpec
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FHSNumber
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FIdentifier
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FInspectionLevel
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FInspectionProject
        {
            /// <summary>
            /// 
            /// </summary>
            public string FBillNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSchemeName { get; set; }
        }

        public class FManageType
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FMaund
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FMCVAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FOrderDept
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FOrderRector
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FOrderTrategy
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 批对批(LFL)
            /// </summary>
            public string FName { get; set; }
        }

        public class FOrderUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FOtherChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FOutMachFeeProject
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FPCVAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FPIVAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FPlanMode
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// MTS计划模式
            /// </summary>
            public string FName { get; set; }
        }

        public class FPlanner
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FPlanTrategy
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 物料需求计划(MRP)
            /// </summary>
            public string FName { get; set; }
        }

        public class FPOHghPrcMnyType
        {
            /// <summary>
            /// 人民币
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FPOVAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FProChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FProductDesigner
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FProductPrincipal
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FProductUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSaleAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSaleUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSampStdCritical
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSampStdSlight
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSampStdStrict
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSecUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSLAcctID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSOChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FSOLowPrcMnyType
        {
            /// <summary>
            /// 人民币
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSource
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSPID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FSPIDReady
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FStkChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FStoreUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FTrack
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FTypeID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
        }

        public class FUnitGroupID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FUnitID
        {
            /// <summary>
            /// 
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        public class FUseState
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 使用
            /// </summary>
            public string FName { get; set; }
        }

        public class FWthDrwChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FWWChkMde
        {
            /// <summary>
            /// 
            /// </summary>
            public string FID { get; set; }
            /// <summary>
            /// 免检
            /// </summary>
            public string FName { get; set; }
        }

        public class FWWHghPrcMnyType
        {
            /// <summary>
            /// 人民币
            /// </summary>
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNumber { get; set; }
        }

        /// <summary>
        /// 物料字段
        /// </summary>
        public class Data
        {
            /// <summary>
            /// 
            /// </summary>
           // public F_101 F_101 { get; set; }

            

            // 存货科目
            public FAcctID FAcctID { get; set; }
            /// <summary>
            /// 代管物资科目
            /// </summary>
            public FAdminAcctID FAdminAcctID { get; set; }
            /// <summary>
            /// 别名
            /// </summary>
            public string FAlias { get; set; }
            /// <summary>
            /// 应付科目
            /// </summary>
            public FAPAcctID FAPAcctID { get; set; }
            /// <summary>
            /// 批准文号
            /// </summary>
            public string FApproveNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FAuxClassID FAuxClassID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FAuxInMrpCal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBackFlushSPID FBackFlushSPID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FBackFlushStockID FBackFlushStockID { get; set; }
           // 变动提前期批量
            public double FBatChangeEconomy { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FBatchAppendQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBatchManager { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FBatchSplit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FBatchSplitDays { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FBatFixEconomy { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FBeforeExpire { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FBookPlan { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCAVAcctID FCAVAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCBAppendProject FCBAppendProject { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FCBAppendRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FCBRestore { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCBRouting FCBRouting { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCharSourceItemID FCharSourceItemID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FChartNumber { get; set; }
           //盘点周期
            public int FCheckCycle { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCheckCycUnit FCheckCycUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FChgFeeRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FConsumeTaxRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FContainerName { get; set; }
           //成本科目
            public FCostAcctID FCostAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCostBomID FCostBomID { get; set; }
            /// <summary>
            /// 成本项目
            /// </summary>
            public FCostProject FCostProject { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCtrlStraregy FCtrlStraregy { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FCtrlType FCtrlType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FCubageDecimal { get; set; }
            //长单位
            public FCubicMeasure FCubicMeasure { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FDailyConsume { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FDaysPer { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDefaultLoc FDefaultLoc { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDefaultReadyLoc FDefaultReadyLoc { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDefaultRoutingID FDefaultRoutingID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FDefaultWorkTypeID FDefaultWorkTypeID { get; set; }
            //FDSManagerID
            public FDSManagerID FDSManagerID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FEquipmentNum { get; set; }
            //物料属性
            public FErpClsID FErpClsID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FExportRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFirstUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FFirstUnitRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFixLeadTime { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FForbbitBarcodeEdit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FFullName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FGoodSpec FGoodSpec { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FGrossWeight { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FHeight { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FHelpCode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FHighLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FHSNumber FHSNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FIdentifier FIdentifier { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FImpostTaxRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FInHighLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FInLowLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FInspectionLevel FInspectionLevel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FInspectionProject FInspectionProject { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsBackFlush { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FIsCharSourceItem { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsEquipment { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsFix { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsFixedReOrder { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsKeyItem { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FISKFPeriod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsManage { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsSale { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsSNManage { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsSparePart { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FIsSpecialTax { get; set; }
            //看板容量
            public double FKanBanCapability { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FKFPeriod { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLastCheckDate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FLeadTime { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FLenDecimal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FLength { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FLowLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMakeFile { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FManageType FManageType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMaund FMaund { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FMCVAcctID FMCVAcctID { get; set; }
            /// <summary>
            /// 规格型号
            /// </summary>
            public string FModel { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FModelEn { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMRPCon { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FMRPOrder { get; set; }
           //物料名称
            public string FName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNameEn { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FNetWeight { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FNote { get; set; }
            //物料代码
            public string FNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOIHighLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOILowLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOnlineShopPName { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FOnlineShopPNo { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOrderDept FOrderDept { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOrderInterVal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOrderPoint { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOrderPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOrderRector FOrderRector { get; set; }
           //订货策略
            public FOrderTrategy FOrderTrategy { get; set; }
            //采购计量单位
            public FOrderUnitID FOrderUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOtherChkMde FOtherChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FOutMachFee { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FOutMachFeeProject FOutMachFeeProject { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPCVAcctID FPCVAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPickHighLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPickLowLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPieceRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPIVAcctID FPIVAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanMode FPlanMode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanner FPlanner { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPlanPoint { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPlanPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPlanTrategy FPlanTrategy { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPOHghPrcMnyType FPOHghPrcMnyType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FPOHighPrice { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FPOVAcctID FPOVAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPriceDecimal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FProChkMde FProChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FProductDesigner FProductDesigner { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FProductPrincipal FProductPrincipal { get; set; }
           //生产计量单位
            public FProductUnitID FProductUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FProfitRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FPutInteger { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FQtyDecimal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FQtyMax { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FQtyMin { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FRequirePoint { get; set; }
            //销售科目
            public FSaleAcctID FSaleAcctID { get; set; }
           //销售单价
            public double FSalePrice { get; set; }
            //销售计量单位
            public FSaleUnitID FSaleUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSampStdCritical FSampStdCritical { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSampStdSlight FSampStdSlight { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSampStdStrict FSampStdStrict { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSecCoefficient { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSecInv { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FSecondUnit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSecondUnitRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSecUnitID FSecUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSize { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSLAcctID FSLAcctID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSOChkMde FSOChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSOHighLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSOLowLimit { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FSOLowPrc { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSOLowPrcMnyType FSOLowPrcMnyType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSource FSource { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSPID FSPID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FSPIDReady FSPIDReady { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStandardCost { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStandardManHour { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStartService { get; set; }
          
            //public string F_134 { get; set; }
            //标准加工批量
            public double FStdBatchQty { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStdFixFeeRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStdPayRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStkChkAlrm { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FStkChkMde FStkChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FStkChkPrd { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FStockTime { get; set; }
           //库存计量单位
            public FStoreUnitID FStoreUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FTaxRate { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FTotalTQQ { get; set; }
         //计价方法
            public FTrack FTrack { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FTtermOfService { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FTtermOfUsefulTime { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FTypeID FTypeID { get; set; }
         //单位组内码
            public FUnitGroupID FUnitGroupID { get; set; }
           //单位内码
            public FUnitID FUnitID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FUnitPackageNumber { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FUseState FUseState { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string FVersion { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FWeightDecimal { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public double FWidth { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FWthDrwChkMde FWthDrwChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FWWChkMde FWWChkMde { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public int FWWHghPrc { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FWWHghPrcMnyType FWWHghPrcMnyType { get; set; }

            //长
            public double F_103 { get; set; }
            //长单位
            public string F_104 { get; set; }

            //宽
            public double F_105 { get; set; }
            //高
            public double F_106 { get; set; }
            //宽1
            public double F_109 { get; set; }

            //宽单位
            public string F_107 { get; set; }
            //高单位
            public string F_108 { get; set; }

            //宽1单位
            public string F_110 { get; set; }

        }

        public class t_ICItem
        {
            /// <summary>
            /// 物料数据
            /// </summary>
            public Data Data { get; set; }
        }

       
    }
}
