﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Kingdee.K3.API.SDK;
using Microsoft.ApplicationBlocks.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;


namespace APITest
{
    public partial class test : Form
    {
        public test()
        {
            InitializeComponent();
        }








        private void genICItemData(string apiUrl)
        {
            

            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_getAddICItem");

            while (dr.Read())
            {
                //SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring1"].Value, "pr_kl_IsExitsICItem", dr["FNumber"].ToString());
                //if (drIsExit.Read() == false)
                //{
                c_t_ICItem.t_ICItem item = new c_t_ICItem.t_ICItem();
                c_t_ICItem.Data d = new c_t_ICItem.Data();
                d.FNumber = "1." + dr["FNumber"].ToString();//编码
                d.FName = dr["FName"].ToString();//名称
                d.FSalePrice = Convert.ToDouble(dr["FSalePrice"]);
                d.FLength = Convert.ToDouble(dr["FLength"]); //长

                d.F_103 = Convert.ToDouble(dr["FLength"]);//长
                d.F_105 = Convert.ToDouble(dr["FWidth"]);//宽
                d.F_106 = Convert.ToDouble(dr["FHeight"]);//高
                d.F_109 = Convert.ToDouble(dr["CustWidth1"]);//宽1

                d.F_104 = dr["lengthunit"].ToString();//长单位
                d.F_107 = dr["widthunit"].ToString();//宽单位
                d.F_108 = dr["HighUnit"].ToString();//高单位
                d.F_110 = dr["Width1Unit"].ToString();//宽1单位
                d.FModel = Convert.ToDouble(dr["FLength"]) + dr["lengthunit"].ToString() + "*"
                    + Convert.ToDouble(dr["FWidth"]) + dr["widthunit"].ToString() + "*"
                    + Convert.ToDouble(dr["FHeight"]) + dr["HighUnit"].ToString();


                //d.FCubicMeasure.FName = dr[""].ToString();
                d.FWidth = Convert.ToDouble(dr["FWidth"]); //宽
                d.FHeight = Convert.ToDouble(dr["FHeight"]); //高
                //d.F_107 = dr["F_107"].ToString(); //宽单位
                //d.F_108 = dr["F_108"].ToString(); //高单位


                //物料属性
                c_t_ICItem.FErpClsID FErpClsID = new c_t_ICItem.FErpClsID();
                //FErpClsID.FID = dr["FErpClsIDNum"].ToString();
                //FErpClsID.FName = dr["FErpClsIDName"].ToString();
                FErpClsID.FID = "WG";
                FErpClsID.FName = "外购";
                d.FErpClsID = FErpClsID;

                //订货策略
                c_t_ICItem.FOrderTrategy FOrderTrategy = new c_t_ICItem.FOrderTrategy();
                //FOrderTrategy.FID = dr["FOrderTrategyNum"].ToString();
                //FOrderTrategy.FName = dr["FOrderTrategyName"].ToString();
                FOrderTrategy.FID = "LFL";
                FOrderTrategy.FName = "批对批(LFL)";
                d.FOrderTrategy = FOrderTrategy;

                //成本科目
                c_t_ICItem.FCostAcctID FCostAcctID = new c_t_ICItem.FCostAcctID();
                //FCostAcctID.FNumber = dr["FCostAcctIDNum"].ToString();
                //FCostAcctID.FName = dr["FCostAcctIDName"].ToString();
                FCostAcctID.FNumber = "1001";
                FCostAcctID.FName = "库存现金";
                d.FCostAcctID = FCostAcctID;



                //单位组内码
                //c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                //FUnitGroupID.FNumber = "282";
                //FUnitGroupID.FName = "重量";
                //d.FUnitGroupID = FUnitGroupID;

                ////单位
                c_t_ICItem.FUnitID FUnitID = new c_t_ICItem.FUnitID();
                //funitid.FNumber = "01";
                //funitid.FName = "KG";
                //d.FUnitID = funitid;
                if (dr["ProductUnit"].ToString().Equals("m"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FUnitID.FNumber = "04";
                    FUnitID.FName = "M";

                }
                else if (dr["ProductUnit"].ToString().Equals("PCS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "284";
                    FUnitGroupID.FName = "PCS";
                    d.FUnitGroupID = FUnitGroupID;

                    FUnitID.FNumber = "02";
                    FUnitID.FName = "PCS";
                }
                else if (dr["ProductUnit"].ToString().Equals("YDS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FUnitID.FNumber = "03";
                    FUnitID.FName = "YDS";
                }
                else
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "604";
                    FUnitGroupID.FName = "数量";
                    d.FUnitGroupID = FUnitGroupID;

                    FUnitID.FNumber = "25";
                    FUnitID.FName = "套";
                }
                d.FUnitID = FUnitID;

                //采购计量单位
                c_t_ICItem.FOrderUnitID FOrderUnitID = new c_t_ICItem.FOrderUnitID();
                //FOrderUnitID.FNumber = "01";
                //FOrderUnitID.FName = "KG";
                if (dr["ProductUnit"].ToString().Equals("m"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FOrderUnitID.FNumber = "04";
                    FOrderUnitID.FName = "M";
                }
                else if (dr["ProductUnit"].ToString().Equals("PCS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "284";
                    FUnitGroupID.FName = "PCS";
                    d.FUnitGroupID = FUnitGroupID;

                    FOrderUnitID.FNumber = "02";
                    FOrderUnitID.FName = "PCS";
                }
                else if (dr["ProductUnit"].ToString().Equals("YDS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FOrderUnitID.FNumber = "03";
                    FOrderUnitID.FName = "YDS";
                }
                else
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "604";
                    FUnitGroupID.FName = "数量";
                    d.FUnitGroupID = FUnitGroupID;


                    FOrderUnitID.FNumber = "25";
                    FOrderUnitID.FName = "套";
                }
                d.FOrderUnitID = FOrderUnitID;

                //生产计量单位
                c_t_ICItem.FProductUnitID FProductUnitID = new c_t_ICItem.FProductUnitID();
                //FProductUnitID.FNumber = "01";
                //FProductUnitID.FName = "KG";
                if (dr["ProductUnit"].ToString().Equals("m"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FProductUnitID.FNumber = "04";
                    FProductUnitID.FName = "M";
                }
                else if (dr["ProductUnit"].ToString().Equals("PCS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "284";
                    FUnitGroupID.FName = "PCS";
                    d.FUnitGroupID = FUnitGroupID;

                    FProductUnitID.FNumber = "02";
                    FProductUnitID.FName = "PCS";
                }
                else if (dr["ProductUnit"].ToString().Equals("YDS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FProductUnitID.FNumber = "03";
                    FProductUnitID.FName = "YDS";
                }
                else
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "604";
                    FUnitGroupID.FName = "数量";
                    d.FUnitGroupID = FUnitGroupID;


                    FProductUnitID.FNumber = "25";
                    FProductUnitID.FName = "套";
                }
                d.FProductUnitID = FProductUnitID;

                //销售单位
                c_t_ICItem.FSaleUnitID FSaleUnitID = new c_t_ICItem.FSaleUnitID();
                //FSaleUnitID.FNumber = "01";
                //FSaleUnitID.FName = "KG";
                if (dr["ProductUnit"].ToString().Equals("m"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FSaleUnitID.FNumber = "04";
                    FSaleUnitID.FName = "M";
                }
                else if (dr["ProductUnit"].ToString().Equals("PCS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "284";
                    FUnitGroupID.FName = "PCS";
                    d.FUnitGroupID = FUnitGroupID;

                    FSaleUnitID.FNumber = "02";
                    FSaleUnitID.FName = "PCS";
                }
                else if (dr["ProductUnit"].ToString().Equals("YDS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FSaleUnitID.FNumber = "03";
                    FSaleUnitID.FName = "YDS";
                }
                else
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "604";
                    FUnitGroupID.FName = "数量";
                    d.FUnitGroupID = FUnitGroupID;


                    FSaleUnitID.FNumber = "25";
                    FSaleUnitID.FName = "套";
                }
                d.FSaleUnitID = FSaleUnitID;

                //库存单位
                c_t_ICItem.FStoreUnitID FStoreUnitID = new c_t_ICItem.FStoreUnitID();
                //FStoreUnitID.FNumber = "01";
                //FStoreUnitID.FName = "KG";
                if (dr["ProductUnit"].ToString().Equals("m"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FStoreUnitID.FNumber = "04";
                    FStoreUnitID.FName = "M";
                }
                else if (dr["ProductUnit"].ToString().Equals("PCS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "284";
                    FUnitGroupID.FName = "PCS";
                    d.FUnitGroupID = FUnitGroupID;

                    FStoreUnitID.FNumber = "02";
                    FStoreUnitID.FName = "PCS";
                }
                else if (dr["ProductUnit"].ToString().Equals("YDS"))
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "286";
                    FUnitGroupID.FName = "长度";
                    d.FUnitGroupID = FUnitGroupID;

                    FStoreUnitID.FNumber = "03";
                    FStoreUnitID.FName = "YDS";
                }
                else
                {
                    c_t_ICItem.FUnitGroupID FUnitGroupID = new c_t_ICItem.FUnitGroupID();
                    FUnitGroupID.FNumber = "604";
                    FUnitGroupID.FName = "数量";
                    d.FUnitGroupID = FUnitGroupID;

                    FStoreUnitID.FNumber = "25";
                    FStoreUnitID.FName = "套";
                }
                d.FStoreUnitID = FStoreUnitID;




                //长单位
                c_t_ICItem.FCubicMeasure fcunit = new c_t_ICItem.FCubicMeasure();
                //fcunit.FNumber = dr["FCubicMeasure"].ToString();
                //fcunit.FName = "厘米";
                if (dr["FCubicMeasure"].ToString().Equals("m"))
                {
                    fcunit.FNumber = "04";
                    fcunit.FName = "M";
                }
                else if (dr["FCubicMeasure"].ToString().Equals("PCS"))
                {
                    fcunit.FNumber = "02";
                    fcunit.FName = "PCS";
                }
                else if (dr["FCubicMeasure"].ToString().Equals("YDS"))
                {
                    fcunit.FNumber = "03";
                    fcunit.FName = "YDS";
                }
                else
                {
                    fcunit.FNumber = "25";
                    fcunit.FName = "套";
                }
                d.FCubicMeasure = fcunit;





                //存货科目
                c_t_ICItem.FAcctID FAcctID = new c_t_ICItem.FAcctID();
                FAcctID.FNumber = "1001";
                FAcctID.FName = "库存现金";
                d.FAcctID = FAcctID;



                //变动提前期批量
                d.FBatChangeEconomy = 1.0;
                //标准加工批量
                d.FStdBatchQty = 1.0;
                //看板容量
                d.FKanBanCapability = 1.0;

                //d.F_134 = dr["OldFnumber"].ToString();
                //销售科目
                c_t_ICItem.FSaleAcctID FSaleAcctID = new c_t_ICItem.FSaleAcctID();
                FSaleAcctID.FNumber = "1001";
                FSaleAcctID.FName = "库存现金";
                d.FSaleAcctID = FSaleAcctID;

                //计价方法
                c_t_ICItem.FTrack FTrack = new c_t_ICItem.FTrack();
                FTrack.FID = "F001";
                FTrack.FName = "加权平均法";
                d.FTrack = FTrack;


                c_t_ICItem.FDSManagerID FDSManagerID = new c_t_ICItem.FDSManagerID();
                FDSManagerID.FNumber = "";
                FDSManagerID.FName = "";
                d.FDSManagerID = FDSManagerID;



                //盘点周期
                d.FCheckCycle = 1;

                item.Data = d;

                // this.txtParamsIn.Text = Newtonsoft.Json.JsonConvert.SerializeObject(item);


                AddItem(Newtonsoft.Json.JsonConvert.SerializeObject(item), @"/Material/Save?token=", apiUrl, "ICItem");
                //}


            }
            if (this.txtResponse.Text.Contains("Token申请成功!") || this.txtResponse.Text.Equals(""))
            {
                this.txtResponse.Text = "无任何产品需要同步！请确认...";
            }




        }

        private void AddItem(string json, string AddType, string apiUrl, string IType)
        {
            //string apiUrl = this.txtUrl.Text.Trim();
            //string token = "63FD9BBF16FC2C343D708CEA56157C1861945458A7E95B1D4838FFC120BBB0F1A2304662E019DF94";
            string token = this.txtToken.Text.Trim();
            string httpResponse = string.Empty;
            string postJson = json;
            string url = apiUrl + AddType + token;  //"/Material/Save?token="
            byte[] data = System.Text.Encoding.UTF8.GetBytes(postJson);
            bool flag = HttpHelper.HttpPost(url, data, out httpResponse, 30000);


            if (!httpResponse.Equals(""))
            {
                //接口返回的参数
                this.txtResponse.Text = httpResponse;
            }

        }


        private string gainName(string join)
        {
            // 初始化字符串
            string str = join;
            //定义正则表达式规则
            Regex reg = new Regex("\"Token\": \"(\\w+)");
            //返回一个结果集
            MatchCollection result = reg.Matches(str);
            //遍历每个结果
            string Token = "";
            foreach (Match m in result)
            {
                //输出结果
                if (m.ToString().Contains("\"Token\": \""))
                {
                    Token = m.ToString().Replace("\"Token\": \"", "");
                }

            }
            return Token;
        }



        private void AddK3ICItem()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            txtToken.Text = "111";
            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            txtToken.Text = "222";
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            txtToken.Text = "333";
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            txtToken.Text = authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            string Token = gainName(httpResponse);
            //this.txtResponse.Text = httpResponse;
            txtToken.Text = "Token" + Token;

            // IsSuceess
            cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);
            txtToken.Text = "httpResponse" + httpResponse;

            if (to.StatusCode == 200)
            {
                if (IsSuceess(httpResponse))
                {
                    txtToken.Text = to.Data.Token;
                    // getItemDetail(); //物料明细获取

                    //新增物料
                    genICItemData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }

        }

        private bool IsSuceess(string Response)
        {
            if (Response.IndexOf(": 200") > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }


        private void btnTest_Click(object sender, EventArgs e)
        {
            AddK3ICItem();
        }
        string Comstr;
        private void test_Load(object sender, EventArgs e)
        {
            //Comstr = "Data Source=127.0.0.1;Initial Catalog=K3ERP_JH1;User ID=user;Password=1";
            this.dtpStart.Text = DateTime.Now.AddDays(-1).ToShortDateString();
            this.dtpEnd.Text = DateTime.Now.ToShortDateString();
            //StreamReader objReader = new StreamReader("SQL.txt");
            //this.txtResponse.Text = objReader.ToString();
            //MessageBox.Show("aa");
           
            //MessageBox.Show("搜索");
            //FileStream sdasda = new FileStream(@"SQL.txt", FileMode.Open);
            //StreamReader reader = new StreamReader(sdasda);
            //string conStr = reader.ReadToEnd();
          
            //MessageBox.Show(conStr);

        }

        //退出程序
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //同步订单
        private void btnSale_Click(object sender, EventArgs e)
        {
            AddSO();
        }

        //获取销售订单数据
        private void genSeOrderData(string apiUrl)
        {

            
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);
            SqlParameter[] paras = new SqlParameter[]
            { 
                new SqlParameter("@dateS",Convert.ToDateTime( this.dtpStart.Text)),
                new SqlParameter("@dateE",Convert.ToDateTime(this.dtpEnd.Text).ToString("yyyy/MM/dd 23:59:59"))
            };
            //SqlDataReader drIsExit = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring1"].Value, "pr_kl_CheckPrice", list[k]);

            //DataTable dt = SqlHelper.ExecuteDataset(config.AppSettings.Settings["connectionstring1"].Value, "pr_kl_CheckPrice", list[k]).Tables[0];

            //this.dataGridView1.DataSource = dt;
            ////dt.Rows.Count>0


            DataTable dt = SqlHelper.ExecuteDataset(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_CheckPrice", paras).Tables[0];
            this.dataGridView1.DataSource = dt;
            if (dt.Rows.Count > 0)
            {
                this.txtResponse.Text = "请先导入所需物料！";
                return;
            }
            cSO.SO so = null;
            cSO.Data d = null;
            SqlDataReader drAll = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, CommandType.StoredProcedure, "pr_kl_GetAllSO ", paras);
            while (drAll.Read())
            {

                SqlDataReader dr = SqlHelper.ExecuteReader(config.AppSettings.Settings["connectionstring"].Value, "pr_kl_getSeorder", drAll["OrderID"].ToString());
                int i = 1;

                while (dr.Read())
                {
                    if (i == 1)
                    {
                        so = new cSO.SO();
                        d = new cSO.Data();

                        cSO.Page1 Page1Item = new cSO.Page1();
                        cSO.FPlanCategory FPlanCategory = new cSO.FPlanCategory();
                        FPlanCategory.FNumber = "STD";
                        FPlanCategory.FName = "标准";
                        Page1Item.FPlanCategory = FPlanCategory;

                        Page1Item.FBillNo = dr["OrderID"].ToString();//编号
                        //客户
                        cSO.FCustID FCustID = new cSO.FCustID();
                        FCustID.FNumber = drAll["CustomerCode"].ToString();
                        FCustID.FName = "客户名称";
                        Page1Item.FCustID = FCustID;


                        //币别
                        cSO.FCurrencyID FCurrencyID = new cSO.FCurrencyID();
                        FCurrencyID.FNumber = "RMB";
                        FCurrencyID.FName = "人民币";
                        Page1Item.FCurrencyID = FCurrencyID;

                        Page1Item.FExchangeRate = 1.0;//汇率

                        //部门
                        cSO.FDeptID FDeptID = new cSO.FDeptID();
                        FDeptID.FNumber = "10";
                        FDeptID.FName = "工程部";
                        Page1Item.FDeptID = FDeptID;

                        //业务员
                        cSO.FEmpID FEmpID = new cSO.FEmpID();
                        FEmpID.FNumber = "JH02";
                        FEmpID.FName = "叶小姐";
                        Page1Item.FEmpID = FEmpID;

                        Page1Item.Fdate = Convert.ToDateTime(drAll["CreateDate"].ToString());//日期
                        Page1Item.FSettleDate = System.DateTime.Now;
                        Page1Item.FExchangeRate = 1.0;
                        if (!drAll["PlanCode"].Equals("") && drAll["PlanCode"] != null)
                        {
                            Page1Item.FHeadSelfS0158 = drAll["PlanCode"].ToString();
                        }




                        d.Page1.Add(Page1Item);
                    }



                    //单据体
                    cSO.Page2 Page2Item = new cSO.Page2();


                    //Page2Item.FItemName = dr["ProductID"].ToString();

                    //Page2Item.FBaseUnit = dr["单位名称"].ToString();
                    Page2Item.FQty = double.Parse(dr["OrderQty"].ToString());//基本单位数量
                    Page2Item.Fauxqty = double.Parse(dr["OrderQty"].ToString());//数量

                    Page2Item.Fauxprice = double.Parse(dr["Price"].ToString());//单价
                    Page2Item.FAuxTaxPrice = double.Parse(dr["Price"].ToString());//含税单价

                    Page2Item.Famount = Convert.ToDouble(dr["sumPrice"].ToString());//金额

                    // Page2Item.FCess = double.Parse(dr["税率"].ToString());


                    Page2Item.FAuxPriceDiscount = double.Parse(dr["Price"].ToString());

                    Page2Item.FAllAmount = double.Parse(dr["sumPrice"].ToString());
                    //Page2Item.FTaxAmt = double.Parse(dr["数量"].ToString()) * double.Parse(dr["含税单价"].ToString()) - double.Parse(dr["数量"].ToString()) * double.Parse(dr["单价"].ToString());
                    Page2Item.FTaxAmt = 0;

                    Page2Item.FDate1 = System.DateTime.Now;

                    Page2Item.FAdviceConsignDate = System.DateTime.Now;
                    Page2Item.FEntrySelfS0171 = System.DateTime.Now;

                    Page2Item.FMTONo = "MTS";

                    Page2Item.FAllStdAmount = double.Parse(dr["sumPrice"].ToString());
                    Page2Item.FEntryID2 = i;


                    cSO.FItemID FItemID = new cSO.FItemID();

                    FItemID.FNumber = "1." + dr["ProductID"].ToString();
                    FItemID.FName = dr["ProductDesc"].ToString();
                    Page2Item.FItemID = FItemID;

                    //单位
                    cSO.FUnitID FUnitID = new cSO.FUnitID();
                    if (dr["ProductUnit"].ToString().Equals("m"))
                    {
                        FUnitID.FNumber = "04";
                        FUnitID.FName = "米";
                    }
                    else if (dr["ProductUnit"].ToString().Equals("PCS"))
                    {
                        FUnitID.FNumber = "02";
                        FUnitID.FName = "PCS";
                    }
                    else if (dr["ProductUnit"].ToString().Equals("YDS"))
                    {
                        FUnitID.FNumber = "03";
                        FUnitID.FName = "YDS";
                    }
                    else
                    {
                        FUnitID.FNumber = "25";
                        FUnitID.FName = "套";
                    }
                    //FUnitID.FNumber = dr[""].ToString();

                    Page2Item.FUnitID = FUnitID;




                    cSO.FBOMCategory FBOMCategory = new cSO.FBOMCategory();
                    FBOMCategory.FNumber = "BZBOM";
                    FBOMCategory.FName = "标准BOM";
                    Page2Item.FBOMCategory = FBOMCategory;

                    cSO.FPlanMode FPlanMode = new cSO.FPlanMode();
                    FPlanMode.FNumber = "MTS";
                    FPlanMode.FName = "MTS计划模式";
                    Page2Item.FPlanMode = FPlanMode;




                    d.Page2.Add(Page2Item);

                    i = i + 1;
                }


                so.Data = d;

                AddItem(Newtonsoft.Json.JsonConvert.SerializeObject(so), @"/SO/Save?token=", apiUrl, "SO");
            }

            if (this.txtResponse.Text.Contains("Token申请成功!") || this.txtResponse.Text.Equals(""))
            {
                this.txtResponse.Text = "没有查询到需要同步的订单！请确认...";
            }
        }

        private void AddSO()
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            string apiUrl = config.AppSettings.Settings["apiUrl"].Value;//this.txtUrl.Text.Trim();
            string authCode = config.AppSettings.Settings["authCode"].Value; //this.txtAuthCode.Text.Trim();
            if (string.IsNullOrEmpty(authCode))
            {
                MessageBox.Show("授权码不能为空");
                return;
            }
            string httpResponse = string.Empty;
            string url = apiUrl + "/Token/Create?authorityCode=" + authCode;
            bool flag = HttpHelper.HttpGet(url, out httpResponse, 30000);
            this.txtResponse.Text = httpResponse;

            if (IsSuceess(httpResponse))
            {


                // IsSuceess
                cToken.Token to = JsonConverter.DeserializeObject<cToken.Token>(httpResponse);

                if (to.StatusCode == 200)
                //if (IsSuceess(httpResponse))
                {
                    txtToken.Text = to.Data.Token;
                    // getItemDetail(); //物料明细获取

                    //新增订单
                    genSeOrderData(apiUrl);
                    //  AddItem(this.txtResponse.Text, @"/Material/Save?token=");
                }
            }

        }

        //更新单价
        private void btnUPice_Click(object sender, EventArgs e)
        {
            getPriceOld();
        }


        public void getPriceOld()
        {

            FileStream sdasda = new FileStream(@"SQL.txt", FileMode.Open);
            StreamReader reader = new StreamReader(sdasda);
            string conStr = reader.ReadToEnd();
            
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Configuration.ConfigurationUserLevel.None);

            int results = SqlHelper.ExecuteNonQuery(conStr, CommandType.StoredProcedure, "pr_RenewalUPrice");
            if (results == 1)
            {
                this.txtResponse.Text = "单价更新成功！";
            }
            else
            {
                this.txtResponse.Text = "无任何单价需要更新！请确认...";
            }
            sdasda.Close();
            reader.Close();
        }

    }
}
