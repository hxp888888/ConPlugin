﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISC_Http_Openapi
{
    public abstract class DBHelper
    {
        /// <summary>  
        /// 连接字符串  
        /// </summary>  
       //public static readonly string connectionString = "server=.;database=AttendanceDataa; uid=sa ;pwd=sa@2019 ;Max Pool Size =512; Min Pool Size=0; Connection Lifetime = 300;packet size=1000;";
         public static readonly string connectionString = "server=158.118.76.230;database=AttendanceData; uid=mro ;pwd=Mr2018 ;Max Pool Size =512; Min Pool Size=0; Connection Lifetime = 300;packet size=1000;";


        public static DataSet GetDataSet2(string connectionString, string cmdText, params SqlParameter[] commandParameters)
        {
            DataSet dataSet = new DataSet();
            using (SqlDataAdapter mySqlDataAdapter = new SqlDataAdapter(cmdText, connectionString))
            {
                mySqlDataAdapter.Fill(dataSet);
            }
            return dataSet;
        }
    }
}
