﻿namespace ISC_Http_Openapi
{
    partial class ISC_Http_Openapi
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Appkey = new System.Windows.Forms.Label();
            this.label_Secret = new System.Windows.Forms.Label();
            this.label_addr = new System.Windows.Forms.Label();
            this.label_httptype = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOutData = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.tb_RequestUrl = new System.Windows.Forms.TextBox();
            this.label_URL = new System.Windows.Forms.Label();
            this.tb_Respone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Request = new System.Windows.Forms.TextBox();
            this.label_request_data = new System.Windows.Forms.Label();
            this.btn_Test = new System.Windows.Forms.Button();
            this.comb_Httptype = new System.Windows.Forms.ComboBox();
            this.tb_PlatAddr = new System.Windows.Forms.TextBox();
            this.tb_Secret = new System.Windows.Forms.TextBox();
            this.tb_Appkey = new System.Windows.Forms.TextBox();
            this.dateTstrart = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTend = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_Appkey
            // 
            this.label_Appkey.AutoSize = true;
            this.label_Appkey.Location = new System.Drawing.Point(21, 26);
            this.label_Appkey.Name = "label_Appkey";
            this.label_Appkey.Size = new System.Drawing.Size(47, 12);
            this.label_Appkey.TabIndex = 0;
            this.label_Appkey.Text = "Appkey:";
            // 
            // label_Secret
            // 
            this.label_Secret.AutoSize = true;
            this.label_Secret.Location = new System.Drawing.Point(173, 26);
            this.label_Secret.Name = "label_Secret";
            this.label_Secret.Size = new System.Drawing.Size(47, 12);
            this.label_Secret.TabIndex = 1;
            this.label_Secret.Text = "Secret:";
            // 
            // label_addr
            // 
            this.label_addr.AutoSize = true;
            this.label_addr.Location = new System.Drawing.Point(161, 61);
            this.label_addr.Name = "label_addr";
            this.label_addr.Size = new System.Drawing.Size(59, 12);
            this.label_addr.TabIndex = 2;
            this.label_addr.Text = "平台地址:";
            // 
            // label_httptype
            // 
            this.label_httptype.AutoSize = true;
            this.label_httptype.Location = new System.Drawing.Point(33, 61);
            this.label_httptype.Name = "label_httptype";
            this.label_httptype.Size = new System.Drawing.Size(35, 12);
            this.label_httptype.TabIndex = 3;
            this.label_httptype.Text = "协议:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dateTend);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dateTstrart);
            this.groupBox1.Controls.Add(this.btnOutData);
            this.groupBox1.Controls.Add(this.btnInsert);
            this.groupBox1.Controls.Add(this.tb_RequestUrl);
            this.groupBox1.Controls.Add(this.label_URL);
            this.groupBox1.Controls.Add(this.tb_Respone);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tb_Request);
            this.groupBox1.Controls.Add(this.label_request_data);
            this.groupBox1.Controls.Add(this.btn_Test);
            this.groupBox1.Controls.Add(this.comb_Httptype);
            this.groupBox1.Controls.Add(this.tb_PlatAddr);
            this.groupBox1.Controls.Add(this.label_httptype);
            this.groupBox1.Controls.Add(this.tb_Secret);
            this.groupBox1.Controls.Add(this.tb_Appkey);
            this.groupBox1.Controls.Add(this.label_Appkey);
            this.groupBox1.Controls.Add(this.label_Secret);
            this.groupBox1.Controls.Add(this.label_addr);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(618, 530);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // btnOutData
            // 
            this.btnOutData.Location = new System.Drawing.Point(522, 81);
            this.btnOutData.Name = "btnOutData";
            this.btnOutData.Size = new System.Drawing.Size(75, 23);
            this.btnOutData.TabIndex = 15;
            this.btnOutData.Text = "导出数据";
            this.btnOutData.UseVisualStyleBackColor = true;
            this.btnOutData.Click += new System.EventHandler(this.btnOutData_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(522, 51);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(75, 23);
            this.btnInsert.TabIndex = 14;
            this.btnInsert.Text = "插入数据";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // tb_RequestUrl
            // 
            this.tb_RequestUrl.Location = new System.Drawing.Point(74, 88);
            this.tb_RequestUrl.Name = "tb_RequestUrl";
            this.tb_RequestUrl.Size = new System.Drawing.Size(416, 21);
            this.tb_RequestUrl.TabIndex = 13;
            // 
            // label_URL
            // 
            this.label_URL.AutoSize = true;
            this.label_URL.Location = new System.Drawing.Point(9, 93);
            this.label_URL.Name = "label_URL";
            this.label_URL.Size = new System.Drawing.Size(59, 12);
            this.label_URL.TabIndex = 12;
            this.label_URL.Text = " 请求URL:";
            // 
            // tb_Respone
            // 
            this.tb_Respone.Location = new System.Drawing.Point(21, 314);
            this.tb_Respone.MaxLength = 999999;
            this.tb_Respone.Multiline = true;
            this.tb_Respone.Name = "tb_Respone";
            this.tb_Respone.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_Respone.Size = new System.Drawing.Size(591, 182);
            this.tb_Respone.TabIndex = 11;
            this.tb_Respone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Respone_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 291);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "返回结果:";
            // 
            // tb_Request
            // 
            this.tb_Request.Location = new System.Drawing.Point(23, 152);
            this.tb_Request.Multiline = true;
            this.tb_Request.Name = "tb_Request";
            this.tb_Request.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_Request.Size = new System.Drawing.Size(589, 127);
            this.tb_Request.TabIndex = 9;
            this.tb_Request.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Request_KeyPress);
            // 
            // label_request_data
            // 
            this.label_request_data.AutoSize = true;
            this.label_request_data.Location = new System.Drawing.Point(33, 128);
            this.label_request_data.Name = "label_request_data";
            this.label_request_data.Size = new System.Drawing.Size(59, 12);
            this.label_request_data.TabIndex = 8;
            this.label_request_data.Text = "请求参数:";
            // 
            // btn_Test
            // 
            this.btn_Test.Location = new System.Drawing.Point(522, 21);
            this.btn_Test.Name = "btn_Test";
            this.btn_Test.Size = new System.Drawing.Size(75, 23);
            this.btn_Test.TabIndex = 7;
            this.btn_Test.Text = "测试";
            this.btn_Test.UseVisualStyleBackColor = true;
            this.btn_Test.Click += new System.EventHandler(this.btn_Test_Click);
            // 
            // comb_Httptype
            // 
            this.comb_Httptype.FormattingEnabled = true;
            this.comb_Httptype.Items.AddRange(new object[] {
            "Https",
            "Http"});
            this.comb_Httptype.Location = new System.Drawing.Point(74, 58);
            this.comb_Httptype.Name = "comb_Httptype";
            this.comb_Httptype.Size = new System.Drawing.Size(78, 20);
            this.comb_Httptype.TabIndex = 6;
            this.comb_Httptype.Text = "Https";
            this.comb_Httptype.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tb_PlatAddr
            // 
            this.tb_PlatAddr.Location = new System.Drawing.Point(226, 56);
            this.tb_PlatAddr.Name = "tb_PlatAddr";
            this.tb_PlatAddr.Size = new System.Drawing.Size(264, 21);
            this.tb_PlatAddr.TabIndex = 5;
            // 
            // tb_Secret
            // 
            this.tb_Secret.Location = new System.Drawing.Point(226, 23);
            this.tb_Secret.Name = "tb_Secret";
            this.tb_Secret.Size = new System.Drawing.Size(264, 21);
            this.tb_Secret.TabIndex = 4;
            // 
            // tb_Appkey
            // 
            this.tb_Appkey.Location = new System.Drawing.Point(74, 23);
            this.tb_Appkey.Name = "tb_Appkey";
            this.tb_Appkey.Size = new System.Drawing.Size(78, 21);
            this.tb_Appkey.TabIndex = 3;
            // 
            // dateTstrart
            // 
            this.dateTstrart.Location = new System.Drawing.Point(232, 122);
            this.dateTstrart.Name = "dateTstrart";
            this.dateTstrart.Size = new System.Drawing.Size(136, 21);
            this.dateTstrart.TabIndex = 16;
            this.dateTstrart.Value = new System.DateTime(2019, 6, 1, 10, 8, 14, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(168, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 17;
            this.label2.Text = "开始时间:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(397, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 19;
            this.label3.Text = "结束时间:";
            // 
            // dateTend
            // 
            this.dateTend.Location = new System.Drawing.Point(461, 122);
            this.dateTend.Name = "dateTend";
            this.dateTend.Size = new System.Drawing.Size(136, 21);
            this.dateTend.TabIndex = 18;
            this.dateTend.Value = new System.DateTime(2019, 6, 1, 10, 8, 35, 0);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "导出参数：";
            // 
            // ISC_Http_Openapi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 554);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "ISC_Http_Openapi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ISC接口测试工具";
            this.Load += new System.EventHandler(this.ISC_Http_Openapi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_Appkey;
        private System.Windows.Forms.Label label_Secret;
        private System.Windows.Forms.Label label_addr;
        private System.Windows.Forms.Label label_httptype;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comb_Httptype;
        private System.Windows.Forms.TextBox tb_PlatAddr;
        private System.Windows.Forms.TextBox tb_Secret;
        private System.Windows.Forms.TextBox tb_Appkey;
        private System.Windows.Forms.TextBox tb_Respone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Request;
        private System.Windows.Forms.Label label_request_data;
        private System.Windows.Forms.Button btn_Test;
        private System.Windows.Forms.TextBox tb_RequestUrl;
        private System.Windows.Forms.Label label_URL;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnOutData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTend;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTstrart;
        private System.Windows.Forms.Label label4;
    }
}

