﻿using ISC_Http_Openapi.Util;
using log4net;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Web;
using System.Windows.Forms;
using Microsoft.CSharp.RuntimeBinder;
using System.Collections;
using System.Data.OleDb;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using Newtonsoft.Json.Linq;

namespace ISC_Http_Openapi
{
    public partial class ISC_Http_Openapi : Form
    {
        [CompilerGenerated]
        private static class o__SiteContainer0
        {
            public static CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>> p__Site1;
        }

        private string requestHeader;
        private static string ARTEMIS_PATH = "/artemis";
        ILog log = LogManager.GetLogger("log");
        public ISC_Http_Openapi()
        {
            InitializeComponent();
            log.Info("-------程序启动------");
            log.Info("-------开始读取配置文件信息------");
            string conf_AppKey = ConfigurationManager.AppSettings.Get("AppKey");
            log.Info("获取配置文件中AppKey:" + conf_AppKey);
            string conf_Secret = ConfigurationManager.AppSettings.Get("Secret");
            log.Info("获取配置文件中Secret:" + conf_Secret);
            string conf_Protocol = ConfigurationManager.AppSettings.Get("Protocol");
            log.Info("获取配置文件中Protocol:" + conf_Protocol);
            string conf_PlatAddr = ConfigurationManager.AppSettings.Get("PlatAddr");
            log.Info("获取配置文件中PlatAddr:" + conf_PlatAddr);
            string NowTime1 = ConfigurationManager.AppSettings.Get("NowTime1");
            log.Info("获取配置文件中NowTime1:" + NowTime1);
            string NowTime2 = ConfigurationManager.AppSettings.Get("NowTime2");
            log.Info("获取配置文件中NowTime2:" + NowTime2);
            this.tb_Appkey.Text = string.IsNullOrEmpty(conf_AppKey) ? "" : conf_AppKey;
            this.tb_Secret.Text = string.IsNullOrEmpty(conf_Secret) ? "" : conf_Secret;
            //this.tb_Appkey.Text = string.IsNullOrEmpty(conf_AppKey) ? "" : "21194539";
            // this.tb_Secret.Text = string.IsNullOrEmpty(conf_Secret) ? "" : "2YnVcobQqmF6a6YdDHbV";
            this.comb_Httptype.Text = string.IsNullOrEmpty(conf_Protocol) ? "https://" : conf_Protocol;
            requestHeader = this.comb_Httptype.Text == "Https" ? "https://" : "http://";
            this.tb_PlatAddr.Text = string.IsNullOrEmpty(conf_PlatAddr) ? "" : conf_PlatAddr;
            //this.tb_PlatAddr.Text = string.IsNullOrEmpty(conf_PlatAddr) ? "" : "192.168.1.250";
            //this.tb_Secret.Text = "wqaVdUU88PHjxuGn71yD";
            //this.tb_PlatAddr.Text = "10.33.47.50:443";
            //this.tb_RequestUrl.Text = "/api/resource/v1/org/advance/orgList";
            this.tb_RequestUrl.Text = "/api/acs/v1/door/events";
            //this.tb_Request.Text = "{\"pageNo\":1,\"pageSize\":1000}";
            string time1 = string.IsNullOrWhiteSpace(NowTime1) ? "22:00:00" : NowTime1;
            string time2 = string.IsNullOrWhiteSpace(NowTime2) ? "22:00:00" : NowTime2;
            if (ConfigurationManager.AppSettings.Get("AllImport") == "1")
            {
                this.tb_Request.Text = "{\"startTime\": \"" + DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd") + "T" + time1 + ".000+08:00\",\"endTime\": \"" + DateTime.Now.ToString("yyyy-MM-dd") + "T" + time2 + ".000+08:00\",\"pageNo\": 1, \"pageSize\": 1000}";

            }
            this.tb_Request.Text = "{\"startTime\": \"" + DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd") + "T" + time1 + ".000+08:00\",\"endTime\": \"" + DateTime.Now.ToString("yyyy-MM-dd") + "T" + time2 + ".000+08:00\",\"pageNo\": 1, \"pageSize\": 1000}";

            //requestHeader = "https://";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            log.Info("选择接口调用协议:" + this.comb_Httptype.Text);
            if (this.comb_Httptype.Text == "Https")
            {
                requestHeader = "https://";
            }
            else
            {
                requestHeader = "http://";
            }
        }

        private void btn_Test_Click(object sender, EventArgs e)
        {
            string strD = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
            //string strD = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
            SqlConnection conn = new SqlConnection(strD);
            conn.Open();


            GetData();

            #region 导出数据库
            //            string[] arrHead = new string[]
            //            {
            //                "人员编号",
            //                "姓名",
            //                "考勤编号",
            //                "打卡日期",
            //                "打卡时间",
            //                "卡机号"
            //            };
            //            int[] arrColWidth = { 15, 15, 10, 15, 15, 12, 10 };

            //            string cmdText = string.Concat(new string[]
            //                {
            //                     "select cardNo 考勤编号, personName 姓名, cardNo 人员编号,CONVERT(char(10), eventTimeDate,120) 打卡日期,CONVERT(char(10), eventTimeDate,108) 打卡时间, doorName 卡机号 from AttendeTable where eventName='acs.acs.eventType.successCard' and doorName like '%考勤闸机%' AND CONVERT(varchar,eventTimeDate,120) >='"	+Convert.ToDateTime( this.dateTstrart.Text).ToString("yyyy-MM-dd").Substring(0,10)+	"' and CONVERT(varchar,eventTimeDate,120)  <='"+Convert.ToDateTime( this.dateTend.Text).ToString("yyyy-MM-dd").Substring(0,10)+"'"
            //                });
            //            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
            //            DataTable dt = dataSet.Tables[0];
            //            HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
            //            string datetime = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            //            //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
            //            FileStream file = new FileStream("C:\\Users\\Administrator\\Desktop\\手动导出的考勤数据" + datetime + ".xls",

            //FileMode.OpenOrCreate);
            //            book.Write(file);
            //            MessageBox.Show("导出数据成功！");
            //            file.Flush();
            //            file.Close();
            //            book = null;
            //            conn.Close();


            #endregion
        }

        private void GetData()
        {
            #region 加载
            if (string.IsNullOrEmpty(this.tb_PlatAddr.Text))
            {
                MessageBox.Show("请先输入平台地址！");
            }
            else if (string.IsNullOrEmpty(this.tb_Appkey.Text))
            {
                MessageBox.Show("请先输入Appkey！");
            }
            else if (string.IsNullOrEmpty(this.tb_Secret.Text))
            {
                MessageBox.Show("请先输入Secret！");
            }
            else
            {
                string apiUrl = ARTEMIS_PATH + this.tb_RequestUrl.Text;
                log.Info("请求接口地址:" + apiUrl);
                Dictionary<string, object> paramMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(this.tb_Request.Text);
                //入参中的时间转为ISO8601
                paramMap = ConvertMapTimeStyle(paramMap);
                string body = GetParamsJson(paramMap);

                //格式化json串,时间格式为ISO8601
                IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
                timeFormat.DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
                this.tb_Request.Text = JsonConvert.SerializeObject(paramMap, Formatting.Indented, timeFormat);

                log.Info("请求参数:" + this.tb_Request.Text);
                Dictionary<string, string> path = new Dictionary<string, string>();
                path.Add(requestHeader, apiUrl);

                string responeStr = HttpPost(path, body, null, null, "application/json");

                try
                {
                    Dictionary<string, object> resultMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(responeStr);
                    //入参中的时间转为ISO8601
                    resultMap = ConvertMapTimeStyle(resultMap);
                    //格式化json串,时间格式为ISO8601
                    this.tb_Respone.Text = JsonConvert.SerializeObject(resultMap, Formatting.Indented, timeFormat);
                }
                catch (Exception ex)
                {
                    this.tb_Respone.Text = ConvertJsonString(responeStr);
                }
                //this.tb_Respone.Text = ConvertJsonString(responeStr);
                //this.tb_Respone.Text = responeStr;
                log.Info("请求响应:" + this.tb_Respone.Text);
            }
            #endregion
        }
        /// <summary>
        /// NPOI导出EXCEl
        /// </summary>
        /// <param name="sheetName">工作表名</param>
        /// <param name="arrHead">表头</param>
        /// <param name="arrColWidth">列宽</param>
        /// <param name="headHeight">表头高度</param>
        /// <param name="colHeight">列高度</param>
        /// <param name="dt">数据</param>
        /// <returns>工作簿</returns>
        // [DllImport("NPOI.dll", SetLastError = true)]
        public static HSSFWorkbook ExcelToNpoiCustom(string sheetName, string[] arrHead, int[] arrColWidth, int headHeight, int colHeight, DataTable dt)
        {
            //建立空白工作簿
            HSSFWorkbook book = new HSSFWorkbook();
            //在工作簿中：建立空白工作表
            ISheet sheet = book.CreateSheet(sheetName);

            IFont font = book.CreateFont();
            font.Boldweight = short.MaxValue;
            font.FontHeightInPoints = 11;

            ////设置单元格的样式：水平垂直对齐居中
            //CellStyle cellStyle = book.CreateCellStyle();
            //cellStyle.Alignment = HorizontalAlignment.CENTER;
            //cellStyle.VerticalAlignment = VerticalAlignment.CENTER;
            //cellStyle.BorderBottom = CellBorderType.THIN;
            //cellStyle.BorderLeft = CellBorderType.THIN;
            //cellStyle.BorderRight = CellBorderType.THIN;
            //cellStyle.BorderTop = CellBorderType.THIN;
            //cellStyle.BottomBorderColor = HSSFColor.BLACK.index;
            //cellStyle.LeftBorderColor = HSSFColor.BLACK.index;
            //cellStyle.RightBorderColor = HSSFColor.BLACK.index;
            //cellStyle.TopBorderColor = HSSFColor.BLACK.index;


            //cellStyle.WrapText = true;//自动换行


            ////设置表头的样式：水平垂直对齐居中，加粗
            //CellStyle titleCellStyle = book.CreateCellStyle();
            //titleCellStyle.Alignment = HorizontalAlignment.CENTER;
            //titleCellStyle.VerticalAlignment = VerticalAlignment.CENTER;
            //titleCellStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.GREY_25_PERCENT.index; //图案颜色
            //titleCellStyle.FillPattern = FillPatternType.SPARSE_DOTS; //图案样式
            //titleCellStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.GREY_25_PERCENT.index; //背景颜色
            ////设置边框
            //titleCellStyle.BorderBottom = CellBorderType.THIN;
            //titleCellStyle.BorderLeft = CellBorderType.THIN;
            //titleCellStyle.BorderRight = CellBorderType.THIN;
            //titleCellStyle.BorderTop = CellBorderType.THIN;
            //titleCellStyle.BottomBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.LeftBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.RightBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.TopBorderColor = HSSFColor.BLACK.index;
            //设置字体
            //titleCellStyle.SetFont(font);

            //表头
            IRow headRow = sheet.CreateRow(0);
            headRow.HeightInPoints = headHeight;
            for (int i = 0; i < arrHead.Length; i++)
            {
                headRow.CreateCell(i).SetCellValue(arrHead[i]);
                // headRow.GetCell(i).CellStyle = titleCellStyle;
            }

            //列宽
            for (int j = 0; j < arrColWidth.Length; j++)
            {
                sheet.SetColumnWidth(j, arrColWidth[j] * 256);
            }

            //循环添加行
            for (int k = 0; k < dt.Rows.Count; k++)
            {
                IRow row = sheet.CreateRow(k + 1);
                row.HeightInPoints = colHeight;
                //循环列赋值
                for (int l = 0; l < dt.Columns.Count; l++)
                {

                    row.CreateCell(l).SetCellValue(dt.Rows[k][l].ToString());
                    //row.GetCell(l).CellStyle = cellStyle;


                }
            };

            return book;
        }


        public string HttpPost(Dictionary<string, string> path, string body, Dictionary<string, string> querys, string accept, string contentType)
        {
            string httpSchema = path.Keys.First();
            if (!string.IsNullOrEmpty(httpSchema))
            {
                string responseStr = "";
                try
                {
                    Dictionary<string, string> headers = new Dictionary<string, string>();
                    string reqAccept = string.IsNullOrWhiteSpace(accept) ? "*/*" : accept;
                    headers.Add("Accept", reqAccept);
                    string reqContenType = string.IsNullOrWhiteSpace(contentType) ? "application/text;charset=UTF-8" : contentType;
                    headers.Add("Content-Type", reqContenType);
                    Request request = new Request(Method.POST_STRING, httpSchema + this.tb_PlatAddr.Text, path[httpSchema], this.tb_Appkey.Text, this.tb_Secret.Text, 20000);
                    request.Headers = headers;
                    request.SignHeaderPrefixList = null;
                    request.Querys = querys;
                    request.StringBody = body;

                    return doPoststring(request.Host, request.Path, request.Timeout, request.Headers, request.Querys, request.StringBody, request.SignHeaderPrefixList, request.AppKey, request.AppSecret);
                }
                catch (Exception ex)
                {
                    log.Info("接口请求报错:" + ex.Message);
                    //MessageBox.Show("error:" + ex.Message);
                }
                return responseStr;
            }
            else
            {
                log.Info("http和https参数错误httpSchema: " + httpSchema);
                return "http和https参数错误httpSchema: " + httpSchema;
                //throw new RuntimeException("http和https参数错误httpSchema: " + httpSchema);
            }
        }

        public string doPoststring(string host, string path, int connectTimeout, Dictionary<string, string> headers, Dictionary<string, string> querys, string body, List<string> signHeaderPrefixList, string appKey, string appSecret)
        {
            try
            {
                headers = initialBasicHeader("POST", path, headers, querys, null, signHeaderPrefixList, appKey, appSecret);
                if (requestHeader == "https://")
                {
                    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteCertificateValidate);//验证服务器证书回调自动验证
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                }
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(initUrl(host, path, querys));
                request.KeepAlive = false;
                request.ProtocolVersion = HttpVersion.Version10;
                //设置HTTP协议的并发连接数
                //ServicePointManager.DefaultConnectionLimit = 512;
                //关闭重定向
                request.AllowAutoRedirect = false;
                request.Method = "POST";
                request.Timeout = connectTimeout;
                string accept = headers["Accept"];
                request.Accept = accept;
                string contentType = headers["Content-Type"];
                request.ContentType = contentType;

                foreach (string headerKey in headers.Keys)
                {
                    if (headerKey.Contains("x-ca-"))
                    {
                        request.Headers.Add(headerKey + ":" + (string.IsNullOrWhiteSpace(headers[headerKey]) ? "" : headers[headerKey]));
                    }
                }
                log.Info("请求头信息: " + request.Headers.ToString());

                if (!string.IsNullOrWhiteSpace(body))
                {
                    byte[] postBytes = Encoding.UTF8.GetBytes(body);
                    request.ContentLength = postBytes.Length;
                    Stream requestStream = request.GetRequestStream();

                    requestStream.Write(postBytes, 0, postBytes.Length);
                    requestStream.Close();
                }
                log.Info("请求参数: " + body);

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string result = "";
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    using (StreamReader rdr = new StreamReader(response.GetResponseStream()))
                    {
                        result = rdr.ReadToEnd();
                    }
                }
                //HttpStatusCode.Found==302重定向的时候，获取图片url的时候
                else if (response.StatusCode == HttpStatusCode.Found)
                {
                    result = response.Headers["Location"].ToString();
                    response.Close();
                }
                return result;
            }
            catch (Exception ex)
            {
                //MessageBox.Show("error:" + ex.Message);
                return "error:" + ex.Message;
            }
        }

        //入参转Json
        public string GetParamsJson(Dictionary<string, object> jsondataDictionary)
        {
            string jsonStr = "";
            jsonStr = JsonHelper.SerializeObject(jsondataDictionary);
            return jsonStr;
        }

        //获取当时时间戳
        public static long GetTimestamp(DateTime time)
        {
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            long t = (time.Ticks - startTime.Ticks) / 10000;   //除10000调整为13位      
            return t;

        }

        private static bool RemoteCertificateValidate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error)
        {
            //为了通过证书验证，总是返回true
            return true;
        }

        public Dictionary<string, string> initialBasicHeader(string method, string path, Dictionary<string, string> headers, Dictionary<string, string> querys, Dictionary<string, string> bodys, List<string> signHeaderPrefixList, string appKey, string appSecret) //throws MalformedURLException
        {
            if (headers == null)
            {
                headers = new Dictionary<string, string>();
            }
            headers["x-ca-timestamp"] = GetTimestamp(DateTime.Now).ToString();
            //headers["x-ca-nonce"] = "5d1b5861-2e04-4bdc-ab02-d393acc6e8df";
            headers["x-ca-nonce"] = System.Guid.NewGuid().ToString();
            headers["x-ca-key"] = appKey;
            headers["x-ca-signature"] = sign(appSecret, method, path, headers, querys, bodys, signHeaderPrefixList);
            log.Info("生成的签名: " + headers["x-ca-signature"]);
            return headers;
        }

        public string initUrl(string host, string path, Dictionary<string, string> querys) //throws UnsupportedEncodingException
        {
            StringBuilder sbUrl = new StringBuilder();
            sbUrl.Append(host);
            if (!string.IsNullOrWhiteSpace(path))
            {
                sbUrl.Append(path);
            }

            if (null != querys)
            {
                StringBuilder sbQuery = new StringBuilder();

                foreach (string queryKey in querys.Keys)
                {
                    if (0 < sbQuery.Length)
                    {
                        sbQuery.Append("&");
                    }

                    if (string.IsNullOrWhiteSpace(queryKey) && !string.IsNullOrWhiteSpace(querys[queryKey]))
                    {
                        sbQuery.Append(querys[queryKey]);
                    }

                    if (!string.IsNullOrWhiteSpace(queryKey))
                    {
                        sbQuery.Append(queryKey);
                        if (!string.IsNullOrWhiteSpace(querys[queryKey]))
                        {
                            sbQuery.Append("=").Append(HttpUtility.UrlEncode(querys[queryKey], Encoding.UTF8));
                        }
                    }
                }

                if (0 < sbQuery.Length)
                {
                    sbUrl.Append("?").Append(sbQuery);
                }
            }
            return sbUrl.ToString();
        }

        public string sign(string secret, string method, string path, Dictionary<string, string> headers, Dictionary<string, string> querys, Dictionary<string, string> bodys, List<string> signHeaderPrefixList)
        {
            try
            {
                //return HmacSHA256(buildstringToSign(method, path, headers, querys, bodys, signHeaderPrefixList), secret);

                /*---message里的内容---*/
                //POST
                //*/*
                //application/json
                //x-ca-key:23125513
                //x-ca-nonce:12d28d90-a7c3-45cc-ae6a-0cc8d5e22118
                //x-ca-timestamp:1544495633599
                //artemis/api/resource/v1/org/advance/orgList
                string message = buildstringToSign(method, path, headers, querys, bodys, signHeaderPrefixList);
                log.Info("生成签名的message: " + message);
                log.Info("生成签名的secret: " + secret);
                return HmacSHA256(message, secret);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string buildstringToSign(string method, string path, Dictionary<string, string> headers, Dictionary<string, string> querys, Dictionary<string, string> bodys, List<string> signHeaderPrefixList)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(method.ToUpper()).Append("\n");
            if (null != headers)
            {
                if (null != headers["Accept"])
                {
                    sb.Append((string)headers["Accept"]);
                    sb.Append("\n");
                }

                if (headers.Keys.Contains("Content-MD5") && null != headers["Content-MD5"])
                {
                    sb.Append((string)headers["Content-MD5"]);
                    sb.Append("\n");
                }

                if (null != headers["Content-Type"])
                {
                    sb.Append((string)headers["Content-Type"]);
                    sb.Append("\n");
                }

                if (headers.Keys.Contains("Date") && null != headers["Date"])
                {
                    sb.Append((string)headers["Date"]);
                    sb.Append("\n");
                }
            }

            sb.Append(buildHeaders(headers, signHeaderPrefixList));
            sb.Append(buildResource(path, querys, bodys));
            return sb.ToString();
        }

        public string buildHeaders(Dictionary<string, string> headers, List<string> signHeaderPrefixList)
        {
            StringBuilder sb = new StringBuilder();
            if (null != signHeaderPrefixList)
            {
                signHeaderPrefixList.Remove("x-ca-signature");
                signHeaderPrefixList.Remove("Accept");
                signHeaderPrefixList.Remove("Content-MD5");
                signHeaderPrefixList.Remove("Content-Type");
                signHeaderPrefixList.Remove("Date");
                signHeaderPrefixList.Sort();
            }

            if (null != headers)
            {
                Dictionary<string, string> sortDictionary = new Dictionary<string, string>();
                sortDictionary = headers;
                //按key值升序排序
                var dicSort = from objDic in sortDictionary orderby objDic.Key ascending select objDic;

                StringBuilder signHeadersStringBuilder = new StringBuilder();

                foreach (KeyValuePair<string, string> kvp in dicSort)
                {
                    if (kvp.Key.Replace(" ", "").Contains("x-ca-"))
                    {
                        sb.Append(kvp.Key + ":");
                        if (!string.IsNullOrWhiteSpace(kvp.Value))
                        {
                            sb.Append(kvp.Value);
                        }
                        sb.Append("\n");
                        if (signHeadersStringBuilder.Length > 0)
                        {
                            signHeadersStringBuilder.Append(",");
                        }
                        signHeadersStringBuilder.Append(kvp.Key);
                    }
                }

                headers.Add("x-ca-signature-headers", signHeadersStringBuilder.ToString());
            }

            //x-ca-key:23125513
            //x-ca-nonce:12d28d90-a7c3-45cc-ae6a-0cc8d5e22118
            //x-ca-timestamp:1544495633599

            return sb.ToString();
        }

        public string buildResource(string path, Dictionary<string, string> querys, Dictionary<string, string> bodys)
        {
            StringBuilder sb = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(path))
            {
                sb.Append(path);
            }

            Dictionary<string, string> sortDictionary = new Dictionary<string, string>();
            if (querys != null)
            {
                //按key值升序排序
                var dicSort = from objDic in querys orderby objDic.Key ascending select objDic;
                foreach (KeyValuePair<string, string> kvp in dicSort)
                {
                    if (!string.IsNullOrWhiteSpace(kvp.Key))
                    {
                        sortDictionary[kvp.Key] = kvp.Value;
                    }
                }
            }

            if (bodys != null)
            {
                //按key值升序排序
                var dicSort = from objDic in bodys orderby objDic.Key ascending select objDic;
                foreach (KeyValuePair<string, string> kvp in dicSort)
                {
                    if (!string.IsNullOrWhiteSpace(kvp.Key))
                    {
                        sortDictionary[kvp.Key] = kvp.Value;
                    }
                }
            }

            StringBuilder sbParam = new StringBuilder();

            //按key值升序排序
            var dicSortDictionary = from objDic in sortDictionary orderby objDic.Key ascending select objDic;
            foreach (KeyValuePair<string, string> kvp in dicSortDictionary)
            {
                if (!string.IsNullOrWhiteSpace(kvp.Key))
                {
                    if (sbParam.Length > 0)
                    {
                        sbParam.Append("&");
                    }
                    sbParam.Append(kvp.Key);
                    if (!string.IsNullOrWhiteSpace(kvp.Value))
                    {
                        sbParam.Append("=").Append(kvp.Value);
                    }
                }
            }

            if (0 < sbParam.Length)
            {
                sb.Append("?");
                sb.Append(sbParam);
            }
            //artemis/api/resource/v1/org/advance/orgList
            return sb.ToString();
        }

        public string HmacSHA256(string message, string secret)
        {
            secret = secret ?? "";
            var encoding = new System.Text.UTF8Encoding();
            byte[] keyByte = encoding.GetBytes(secret);
            byte[] messageBytes = encoding.GetBytes(message);
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                byte[] hashmessage = hmacsha256.ComputeHash(messageBytes);
                return Convert.ToBase64String(hashmessage);
            }
        }

        public string ConvertJsonString(string str)
        {
            try
            {
                //格式化json字符串
                JsonSerializer serializer = new JsonSerializer();
                TextReader tr = new StringReader(str);

                JsonTextReader jtr = new JsonTextReader(tr);
                object obj = serializer.Deserialize(jtr);
                if (obj != null)
                {
                    StringWriter textWriter = new StringWriter();
                    JsonTextWriter jsonWriter = new JsonTextWriter(textWriter)
                    {
                        Formatting = Formatting.Indented,
                        Indentation = 4,
                        IndentChar = ' '
                    };
                    serializer.Serialize(jsonWriter, obj);
                    return textWriter.ToString();
                }
                else
                {
                    return str;
                }
            }
            catch (Exception ex)
            {
                return str;
            }
        }

        public string ConvertJsonString11(string str)
        {
            Dictionary<string, object> paramMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(this.tb_Request.Text);
            paramMap = ConvertMapTimeStyle(paramMap);
            string body = GetParamsJson(paramMap);
            IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
            timeFormat.DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
            //this.tb_Request.Text = ConvertJsonString(body);
            this.tb_Request.Text = JsonConvert.SerializeObject(paramMap, Formatting.Indented, timeFormat);
            try
            {
                //格式化json字符串
                JsonSerializer serializer = new JsonSerializer();
                TextReader tr = new StringReader(str);

                JsonTextReader jtr = new JsonTextReader(tr);
                object obj = serializer.Deserialize(jtr);
                if (obj != null)
                {
                    StringWriter textWriter = new StringWriter();
                    JsonTextWriter jsonWriter = new JsonTextWriter(textWriter)
                    {
                        Formatting = Formatting.Indented,
                        Indentation = 4,
                        IndentChar = ' '
                    };
                    serializer.Serialize(jsonWriter, obj);
                    return textWriter.ToString();
                }
                else
                {
                    return str;
                }
            }
            catch (Exception ex)
            {
                return str;
            }
        }

        public Dictionary<string, object> ConvertMapTimeStyle(Dictionary<string, object> paramMap)
        {
            Dictionary<string, object> timeMap = new Dictionary<string, object>();
            try
            {
                foreach (string key in paramMap.Keys)
                {

                    object mapValueObj = paramMap[key];
                    Dictionary<string, object> dic = mapValueObj as Dictionary<string, object>;
                    if (dic != null)
                    {
                        ConvertMapTimeStyle(dic);
                    }
                    //时间格式参数转为ISO8601
                    DateTime mapDate;
                    if (DateTime.TryParse(paramMap[key].ToString(), out mapDate))
                    {
                        string ISO8601time = mapDate.ToString("yyyy-MM-ddTHH:mm:ss.fffzzz");
                        timeMap.Add(key, ISO8601time);
                    }
                }
                if (timeMap.Count > 0)
                {
                    foreach (string key in timeMap.Keys)
                    {
                        paramMap[key] = timeMap[key];
                    }
                }
                return paramMap;
            }
            catch (Exception ex)
            {
                return paramMap;
            }
        }

        private void tb_Request_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x1')
            {
                ((TextBox)sender).SelectAll();
                e.Handled = true;
            }
        }

        private void tb_Respone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\x1')
            {
                ((TextBox)sender).SelectAll();
                e.Handled = true;
            }
        }

        /// <summary>
        /// 测试数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInsert_Click(object sender, EventArgs e)
        {
            string data = this.tb_Respone.Text;
            //总页数
            string count1 = data.Substring(data.IndexOf("\"totalPage\":") + 13, data.IndexOf("\"pageNo\":") - data.IndexOf("\"totalPage\":") - 20);

            for (int countTotal = 1; countTotal <= Convert.ToInt32(count1); countTotal++)
            {

                #region 查询数据
                this.tb_Respone.Text = "";
                string apiUrl = ARTEMIS_PATH + this.tb_RequestUrl.Text;
                log.Info("请求接口地址:" + apiUrl);
                string requestParm = this.tb_Request.Text.Trim();
                //当前页数
                string pageSizes = requestParm.Substring(requestParm.IndexOf("pageNo", 6) + 8, requestParm.IndexOf("pageSize", 6) - requestParm.IndexOf("pageNo", 6) - 10);

                //请求参数
                string ReParmaters = this.tb_Request.Text.Trim().Replace(pageSizes, countTotal.ToString().Trim() + ", ");
                Dictionary<string, object> paramMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(ReParmaters);
                //入参中的时间转为ISO8601
                paramMap = ConvertMapTimeStyle(paramMap);
                string body = GetParamsJson(paramMap);

                //格式化json串,时间格式为ISO8601
                IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
                timeFormat.DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
                this.tb_Request.Text = JsonConvert.SerializeObject(paramMap, Formatting.Indented, timeFormat);

                log.Info("请求参数:" + this.tb_Request.Text);
                Dictionary<string, string> path = new Dictionary<string, string>();
                path.Add(requestHeader, apiUrl);

                string responeStr = HttpPost(path, body, null, null, "application/json");

                try
                {
                    Dictionary<string, object> resultMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(responeStr);
                    //入参中的时间转为ISO8601
                    resultMap = ConvertMapTimeStyle(resultMap);
                    //格式化json串,时间格式为ISO8601
                    this.tb_Respone.Text = JsonConvert.SerializeObject(resultMap, Formatting.Indented, timeFormat);
                }
                catch (Exception ex)
                {
                    this.tb_Respone.Text = ConvertJsonString(responeStr);
                }
                this.tb_Respone.Text = ConvertJsonString(responeStr);
                this.tb_Respone.Text = responeStr;
                log.Info("请求响应:" + this.tb_Respone.Text);
                #endregion


                #region 插入数据到数据库

                JObject jo = (JObject)JsonConvert.DeserializeObject(responeStr);
                string str = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
                //string str = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
                StringBuilder sb = new StringBuilder();
                SqlConnection con = new SqlConnection(str);
                con.Open();

                string eventId;
                string eventName;
                DateTime eventTimeDate;
                string personId;
                string cardNo;
                string personName;
                string orgIndexCode;
                string doorName;
                string doorIndexCode;
                string doorRegionIndexCode;
                string picUri;
                string svrIndexCode;
                string eventType;
                string inAndOutType;
                foreach (var li in jo["data"]["list"])
                {
                    eventId = li["eventId"].ToString();
                    eventName = li["eventName"].ToString();
                    eventTimeDate = Convert.ToDateTime(li["eventTime"]);
                    personId = li["personId"].ToString();
                    cardNo = li["cardNo"].ToString().Replace('P', ' ');
                    personName = li["personName"].ToString();
                    orgIndexCode = li["orgIndexCode"].ToString();
                    doorName = li["doorName"].ToString();
                    doorIndexCode = li["doorIndexCode"].ToString();
                    doorRegionIndexCode = li["doorRegionIndexCode"].ToString();
                    picUri = li["picUri"].ToString();
                    svrIndexCode = li["svrIndexCode"].ToString();
                    eventType = li["eventType"].ToString();
                    inAndOutType = li["inAndOutType"].ToString();
                    string sql = string.Format(@"INSERT INTO AttendeTable     VALUES
                   (
                    '{0}','{1}','{2}','{3}','{4}','{5}',{6},'{7}',{8},'{9}',{10},{11},'{12}','{13}'
                    )", eventId.Trim(), eventName.Trim(), eventTimeDate, personId.Trim(), cardNo.Trim(), personName.Trim(), "'"
                       + orgIndexCode.Trim() + "'", doorName.Trim(), "'" + doorIndexCode.Trim() + "'", doorRegionIndexCode.Trim(), "'"
                       + picUri.Trim() + "'", "'" + svrIndexCode.Trim() + "'", eventType.Trim(), inAndOutType.Trim());

                    sb.Append(sql);
                    sb.Append("  ");
                }
                SqlCommand com = new SqlCommand(sb.ToString(), con);
                com.ExecuteNonQuery();
                con.Close();

             
                #endregion

            }
        }


        /// <summary>
        /// 加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ISC_Http_Openapi_Load(object sender, EventArgs e)
        {

            string AllImport = System.Configuration.ConfigurationManager.AppSettings["AllImport"];
            if (AllImport == "1")
            {

                // PushOneBill(123, "test");
                #region 加载（获取总页数）
                if (string.IsNullOrEmpty(this.tb_PlatAddr.Text))
                {
                    MessageBox.Show("请先输入平台地址！");
                }
                else if (string.IsNullOrEmpty(this.tb_Appkey.Text))
                {
                    MessageBox.Show("请先输入Appkey！");
                }
                else if (string.IsNullOrEmpty(this.tb_Secret.Text))
                {
                    MessageBox.Show("请先输入Secret！");
                }
                else
                {
                    string apiUrl = ARTEMIS_PATH + this.tb_RequestUrl.Text;
                    log.Info("请求接口地址:" + apiUrl);
                    Dictionary<string, object> paramMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(this.tb_Request.Text);
                    //入参中的时间转为ISO8601
                    paramMap = ConvertMapTimeStyle(paramMap);
                    string body = GetParamsJson(paramMap);

                    //格式化json串,时间格式为ISO8601
                    IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
                    timeFormat.DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
                    this.tb_Request.Text = JsonConvert.SerializeObject(paramMap, Formatting.Indented, timeFormat);

                    log.Info("请求参数:" + this.tb_Request.Text);
                    Dictionary<string, string> path = new Dictionary<string, string>();
                    path.Add(requestHeader, apiUrl);

                    string responeStr = HttpPost(path, body, null, null, "application/json");

                    try
                    {
                        Dictionary<string, object> resultMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(responeStr);
                        //入参中的时间转为ISO8601
                        resultMap = ConvertMapTimeStyle(resultMap);
                        //格式化json串,时间格式为ISO8601
                        this.tb_Respone.Text = JsonConvert.SerializeObject(resultMap, Formatting.Indented, timeFormat);
                    }
                    catch (Exception ex)
                    {
                        this.tb_Respone.Text = ConvertJsonString(responeStr);
                    }
                    //this.tb_Respone.Text = ConvertJsonString(responeStr);
                    //this.tb_Respone.Text = responeStr;
                    log.Info("请求响应:" + this.tb_Respone.Text);
                }
                #endregion

                string data = this.tb_Respone.Text;//首次加载为了获取总页数
                if (data != null || !data.Equals(""))
                {
                    //总页数
                    string count1 = data.Substring(data.IndexOf("\"totalPage\":") + 13, data.IndexOf("\"pageNo\":") - data.IndexOf("\"totalPage\":") - 20);

                    for (int countTotal = 1; countTotal <= Convert.ToInt32(count1); countTotal++)
                    {

                        #region 查询数据
                        this.tb_Respone.Text = "";
                        string apiUrl = ARTEMIS_PATH + this.tb_RequestUrl.Text;
                        log.Info("请求接口地址:" + apiUrl);
                        string requestParm = this.tb_Request.Text.Trim();
                        //当前页数
                        string pageSizes = requestParm.Substring(requestParm.IndexOf("pageNo", 6) + 8, requestParm.IndexOf("pageSize", 6) - requestParm.IndexOf("pageNo", 6) - 10);

                        //请求参数
                        string ReParmaters = this.tb_Request.Text.Trim().Replace(pageSizes, countTotal.ToString().Trim() + ", ");
                        Dictionary<string, object> paramMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(ReParmaters);
                        //入参中的时间转为ISO8601
                        paramMap = ConvertMapTimeStyle(paramMap);
                        string body = GetParamsJson(paramMap);

                        //格式化json串,时间格式为ISO8601
                        IsoDateTimeConverter timeFormat = new IsoDateTimeConverter();
                        timeFormat.DateTimeFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
                        this.tb_Request.Text = JsonConvert.SerializeObject(paramMap, Formatting.Indented, timeFormat);

                        log.Info("请求参数:" + this.tb_Request.Text);
                        Dictionary<string, string> path = new Dictionary<string, string>();
                        path.Add(requestHeader, apiUrl);

                        string responeStr = HttpPost(path, body, null, null, "application/json");

                        try
                        {
                            Dictionary<string, object> resultMap = JsonHelper.DeserializeJsonToObject<Dictionary<string, object>>(responeStr);
                            //入参中的时间转为ISO8601
                            resultMap = ConvertMapTimeStyle(resultMap);
                            //格式化json串,时间格式为ISO8601
                            this.tb_Respone.Text = JsonConvert.SerializeObject(resultMap, Formatting.Indented, timeFormat);
                        }
                        catch (Exception ex)
                        {
                            this.tb_Respone.Text = ConvertJsonString(responeStr);
                        }
                        this.tb_Respone.Text = ConvertJsonString(responeStr);
                        this.tb_Respone.Text = responeStr;
                        log.Info("请求响应:" + this.tb_Respone.Text);
                        #endregion


                        #region 插入数据到数据库

                        JObject jo = (JObject)JsonConvert.DeserializeObject(responeStr);
                        string str = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
                        //string str = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
                        StringBuilder sb = new StringBuilder();
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string eventId;
                        string eventName;
                        DateTime eventTimeDate;
                        string personId;
                        string cardNo;
                        string personName;
                        string orgIndexCode;
                        string doorName;
                        string doorIndexCode;
                        string doorRegionIndexCode;
                        string picUri;
                        string svrIndexCode;
                        string eventType;
                        string inAndOutType;
                        foreach (var li in jo["data"]["list"])
                        {
                            eventId = li["eventId"].ToString();
                            eventName = li["eventName"].ToString();
                            eventTimeDate = Convert.ToDateTime(li["eventTime"]);
                            personId = li["personId"].ToString();
                            cardNo = li["cardNo"].ToString().Replace('P', ' ');
                            personName = li["personName"].ToString();
                            orgIndexCode = li["orgIndexCode"].ToString();
                            doorName = li["doorName"].ToString();
                            doorIndexCode = li["doorIndexCode"].ToString();
                            doorRegionIndexCode = li["doorRegionIndexCode"].ToString();
                            picUri = li["picUri"].ToString();
                            svrIndexCode = li["svrIndexCode"].ToString();
                            eventType = li["eventType"].ToString();
                            inAndOutType = li["inAndOutType"].ToString();
                            string sql = string.Format(@"INSERT INTO AttendeTable     VALUES
                   (
                    '{0}','{1}','{2}','{3}','{4}','{5}',{6},'{7}',{8},'{9}',{10},{11},'{12}','{13}'
                    )", eventId.Trim(), eventName.Trim(), eventTimeDate, personId.Trim(), cardNo.Trim(), personName.Trim(), "'"
                               + orgIndexCode.Trim() + "'", doorName.Trim(), "'" + doorIndexCode.Trim() + "'", doorRegionIndexCode.Trim(), "'"
                               + picUri.Trim() + "'", "'" + svrIndexCode.Trim() + "'", eventType.Trim(), inAndOutType.Trim());

                            sb.Append(sql);
                            sb.Append("  ");
                        }
                        SqlCommand com = new SqlCommand(sb.ToString(), con);
                        com.ExecuteNonQuery();
                        con.Close();
                        #endregion

                    }
                }


                #region 导出数据库
                string urlPath = ConfigurationManager.AppSettings.Get("urlPath");
                string strD = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
                // string strD = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
                SqlConnection conn = new SqlConnection(strD);
                conn.Open();
                string[] arrHead = new string[]
                        {
                            "人员编号",
                            "姓名",
                            "考勤编号",
                            "打卡日期",
                            "打卡时间",
                            "卡机号"
                        };
                int[] arrColWidth = { 15, 15, 10, 15, 15, 12, 10 };

                string cmdText = string.Concat(new string[]
                            {
                                 "select distinct cardNo 考勤编号, personName 姓名, cardNo 人员编号,CONVERT(char(10), eventTimeDate,120) 打卡日期,CONVERT(char(10), eventTimeDate,108) 打卡时间, doorName 卡机号 from AttendeTable where eventName='acs.acs.eventType.successCard' and doorName like '%考勤闸机%' AND CONVERT(varchar(10),eventTimeDate,120) >='"	+Convert.ToDateTime( this.dateTstrart.Text).ToString("yyyy-MM-dd").Substring(0,10)+	"' and CONVERT(varchar(10),eventTimeDate,120)  <='"+Convert.ToDateTime( this.dateTend.Text).ToString("yyyy-MM-dd").Substring(0,10)+"'"
                            });
                DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
                DataTable dt = dataSet.Tables[0];
                HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
                string datetime = DateTime.Now.ToString("yyyyMMdd");
                //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
                FileStream file = new FileStream(urlPath + datetime + ".xls",

    FileMode.OpenOrCreate);
                book.Write(file);
                MessageBox.Show("导出数据成功！");
                file.Flush();
                file.Close();
                book = null;
                conn.Close();


                #endregion

               // System.Environment.Exit(0); //执行完后关闭程序
                // Close();
            }
            else
            {
                //tb_Request.Enabled = false;
                //tb_Respone.Enabled = false;
                tb_Appkey.Enabled = false;
                tb_Secret.Enabled = false;
                comb_Httptype.Enabled = false;
                tb_PlatAddr.Enabled = false;
                tb_RequestUrl.Enabled = false;
            }



        }

        public void ToExcel(SaveFileDialog saveFileDialog)
        {

            //string str = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
            string str = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            // saveFileDialog = new SaveFileDialog();
            //Thread.Sleep(1000); 
            saveFileDialog.Filter = "Execl files (*.xls)|*.xls";
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = false;
            saveFileDialog.Title = "导出文件保存路径";
            string[] array = new string[]
			{
				"人员编号",
				"姓名",
				"考勤编号",
				"打卡日期",
				"打卡时间",
				"卡机号"
			};

            DialogResult result = saveFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                string cmdText = string.Concat(new string[]
				{
                    //"select type as 品番,lot as LOT,amount as 数量,CONVERT(datetime, oper_date,111), OPER_NO, info3 from tb_data where oper_date >= '",
                    //Convert.ToDateTime( this.dtpStime.Text).ToString("yyyy-MM-dd").Substring(0,10),
                    //"' and oper_date <='",
                    //Convert.ToDateTime( this.dtpEtime.Text).ToString("yyyy-MM-dd").Substring(0,10)," 23:59:59'"
					 "select cardNo 考勤编号, personName 姓名, cardNo 人员编号,CONVERT(char(10), eventTimeDate,120) 打卡日期,CONVERT(char(10), eventTimeDate,108) 打卡时间, doorName 卡机号 from AttendeTable where eventName='acs.acs.eventType.successCard' and doorName like '%考勤闸机%' AND CONVERT(varchar,eventTimeDate,120) >='"	+DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 20:00:00")+	"' and CONVERT(varchar,eventTimeDate,120)  <='"+DateTime.Now.ToString("yyyy-MM-dd 22:00:00")+"'"
                });

                DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
                DataTable dataTable = dataSet.Tables[0];
                if (dataTable.Rows.Count == 0)
                {
                    return;
                }
                if (fileName.Length != 0)
                {
                    Missing value = Missing.Value;
                    Microsoft.Office.Interop.Excel.Application application = (Microsoft.Office.Interop.Excel.Application)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
                    application.Visible = false;
                    CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
                    Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                    Microsoft.Office.Interop.Excel.Workbook workbook = application.Workbooks.Add(value);
                    if (ISC_Http_Openapi.o__SiteContainer0.p__Site1 == null)
                    {
                        ISC_Http_Openapi.o__SiteContainer0.p__Site1 = CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(Microsoft.Office.Interop.Excel.Worksheet), typeof(ISC_Http_Openapi)));
                    }
                    Microsoft.Office.Interop.Excel.Worksheet worksheet = ISC_Http_Openapi.o__SiteContainer0.p__Site1.Target(ISC_Http_Openapi.o__SiteContainer0.p__Site1, workbook.Worksheets.Add(value, value, value, value));
                    worksheet.Name = "data";
                    //worksheet.AllocatedRange["A1:F8"].AutoFitColumns();
                    //worksheet.AllocatedRange["A1:F8"].AutoFitRows();
                    for (int i = 0; i < array.Length; i++)
                    {
                        worksheet.Cells[1, i + 1] = array[i];
                    }
                    Microsoft.Office.Interop.Excel.Range arg_1F8_0 = worksheet.get_Range("A2", value);
                    //Microsoft.Office.Interop.Excel.Range allColumn = worksheet.Rows;
                    //allColumn.AutoFit();
                    //((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Missing.Value]).RowHeight = 5;
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Missing.Value]).ColumnWidth = 25;
                    Microsoft.Office.Interop.Excel.Range range = null;
                    int count = dataTable.Rows.Count;
                    int j = 0;
                    int num = 1;
                    int count2 = dataTable.Columns.Count;
                    object[,] array2 = new object[num, count2];
                    try
                    {
                        int num2 = num;
                        while (j < count)
                        {
                            if (count - j < num)
                            {
                                num2 = count - j;
                            }
                            for (int k = 0; k < num2; k++)
                            {
                                for (int l = 0; l < count2; l++)
                                {
                                    array2[k, l] = dataTable.Rows[k + j][l].ToString();
                                }
                                System.Windows.Forms.Application.DoEvents();
                            }
                            range = worksheet.get_Range("A" + (j + 2).ToString(), ((char)(65 + count2 - 1)).ToString() + (j + num2 + 1).ToString());
                            range.Value2 = array2;
                            j += num2;
                        }
                        worksheet.SaveAs(fileName, value, value, value, value, value, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, value, value, value);
                        Marshal.ReleaseComObject(range);
                        this.KillSpecialExcel(application);
                        MessageBox.Show("导出数据成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        conn.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                    Thread.CurrentThread.CurrentCulture = currentCulture;
                }
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

        public void KillSpecialExcel(Microsoft.Office.Interop.Excel.Application m_objExcel)
        {
            try
            {
                if (m_objExcel != null)
                {
                    int processId = 0;
                    ISC_Http_Openapi.GetWindowThreadProcessId(new IntPtr(m_objExcel.Hwnd), out processId);
                    Process.GetProcessById(processId).Kill();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public static DataSet GetDataSet2(string connectionString, string cmdText, params SqlParameter[] commandParameters)
        {
            DataSet dataSet = new DataSet();
            using (SqlDataAdapter mySqlDataAdapter = new SqlDataAdapter(cmdText, connectionString))
            {
                mySqlDataAdapter.Fill(dataSet);
            }
            return dataSet;
        }

        /// <summary>
        /// 导出数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOutData_Click(object sender, EventArgs e)
        {
            #region 导出数据库
            string urlPath = ConfigurationManager.AppSettings.Get("urlPath");
            string strD = "data source=158.118.76.230;initial catalog=AttendanceData;uid=mro ;pwd=Mr2018;";
            // string strD = "data source=.;initial catalog=AttendanceDataa;uid=sa ;pwd=sa@2019;";
            SqlConnection conn = new SqlConnection(strD);
            conn.Open();
            string[] arrHead = new string[]
                        {
                            "人员编号",
                            "姓名",
                            "考勤编号",
                            "打卡日期",
                            "打卡时间",
                            "卡机号"
                        };
            int[] arrColWidth = { 15, 15, 10, 15, 15, 12, 10 };

            string cmdText = string.Concat(new string[]
                            {
                                 "select distinct cardNo 考勤编号, personName 姓名, cardNo 人员编号,CONVERT(char(10), eventTimeDate,120) 打卡日期,CONVERT(char(10), eventTimeDate,108) 打卡时间, doorName 卡机号 from AttendeTable where eventName='acs.acs.eventType.successCard' and doorName like '%考勤闸机%' AND CONVERT(varchar(10),eventTimeDate,120) >='"	+Convert.ToDateTime( this.dateTstrart.Text).ToString("yyyy-MM-dd").Substring(0,10)+	"' and CONVERT(varchar(10),eventTimeDate,120)  <='"+Convert.ToDateTime( this.dateTend.Text).ToString("yyyy-MM-dd").Substring(0,10)+"'"
                            });
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
            DataTable dt = dataSet.Tables[0];
            HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
            string datetime = DateTime.Now.ToString("yyyyMMdd");
            //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
            FileStream file = new FileStream(urlPath + datetime + ".xls",

FileMode.OpenOrCreate);
            book.Write(file);
            MessageBox.Show("导出数据成功！");
            file.Flush();
            file.Close();
            book = null;
            conn.Close();


            #endregion
        }
    }
}


