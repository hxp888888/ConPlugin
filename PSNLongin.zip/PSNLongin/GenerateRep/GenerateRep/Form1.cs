﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CSharp.RuntimeBinder;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GenerateRep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        System.Timers.Timer timer2;  //计时器
        private void button1_Click(object sender, EventArgs e)
        {

            //timer2 = new System.Timers.Timer();
//            string time = DBHelper.ExecuteScalar(@"SELECT TOP 1 [DICT_VALUE]
//  FROM [panasonic].[dbo].[tb_dict] where [DICT_TYPE]='EXPORT_TIME1'");
           // timer2.Interval = 1 * 60 * 1000;  //设置计时器事件间隔执行时间
            //timer2.Elapsed += new System.Timers.ElapsedEventHandler(timer1_Elapsed);
            //timer2.Enabled = true;
            string[] arrHead =
                {
               
				"品番",
				"Lot",
				"数量",
                "Part NO.",
                "订单号",
                "打印者",
                "打印时间",
                "厚度",
                "操作员",
				"操作时间"
                };
            int[] arrColWidth = { 15, 15, 10, 15, 15, 12 ,10};

            string cmdText = string.Concat(new string[]
				{
					@"select type as 品番,lot as LOT,amount as 数量,info1 'Part NO.',info2 订单号,info3 打印者,info4 打印时间,THICKNESS 厚度,oper_no, CONVERT(datetime, oper_date,111) from
                        tb_data ",
				});
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
            DataTable dt = dataSet.Tables[0];
            HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
            string path = DBHelper.ExecuteScalar(@"SELECT TOP 1 [DICT_VALUE] FROM [panasonic].[dbo].[tb_dict]   ORDER BY [DICT_VALUE] DESC");
            FileStream file = new FileStream(path + "\\报表" + datetime + ".xls", FileMode.OpenOrCreate);
            book.Write(file);
            file.Flush();
            file.Close();
            book = null;
        }

        /// <summary>
        /// NPOI导出EXCEl
        /// </summary>
        /// <param name="sheetName">工作表名</param>
        /// <param name="arrHead">表头</param>
        /// <param name="arrColWidth">列宽</param>
        /// <param name="headHeight">表头高度</param>
        /// <param name="colHeight">列高度</param>
        /// <param name="dt">数据</param>
        /// <returns>工作簿</returns>
        // [DllImport("NPOI.dll", SetLastError = true)]
        public static HSSFWorkbook ExcelToNpoiCustom(string sheetName, string[] arrHead, int[] arrColWidth, int headHeight, int colHeight, DataTable dt)
        {
            //建立空白工作簿
            HSSFWorkbook book = new HSSFWorkbook();
            //在工作簿中：建立空白工作表
            ISheet sheet = book.CreateSheet(sheetName);

            IFont font = book.CreateFont();
            font.Boldweight = short.MaxValue;
            font.FontHeightInPoints = 11;

            ////设置单元格的样式：水平垂直对齐居中
            //CellStyle cellStyle = book.CreateCellStyle();
            //cellStyle.Alignment = HorizontalAlignment.CENTER;
            //cellStyle.VerticalAlignment = VerticalAlignment.CENTER;
            //cellStyle.BorderBottom = CellBorderType.THIN;
            //cellStyle.BorderLeft = CellBorderType.THIN;
            //cellStyle.BorderRight = CellBorderType.THIN;
            //cellStyle.BorderTop = CellBorderType.THIN;
            //cellStyle.BottomBorderColor = HSSFColor.BLACK.index;
            //cellStyle.LeftBorderColor = HSSFColor.BLACK.index;
            //cellStyle.RightBorderColor = HSSFColor.BLACK.index;
            //cellStyle.TopBorderColor = HSSFColor.BLACK.index;


            //cellStyle.WrapText = true;//自动换行


            ////设置表头的样式：水平垂直对齐居中，加粗
            //CellStyle titleCellStyle = book.CreateCellStyle();
            //titleCellStyle.Alignment = HorizontalAlignment.CENTER;
            //titleCellStyle.VerticalAlignment = VerticalAlignment.CENTER;
            //titleCellStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.GREY_25_PERCENT.index; //图案颜色
            //titleCellStyle.FillPattern = FillPatternType.SPARSE_DOTS; //图案样式
            //titleCellStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.GREY_25_PERCENT.index; //背景颜色
            ////设置边框
            //titleCellStyle.BorderBottom = CellBorderType.THIN;
            //titleCellStyle.BorderLeft = CellBorderType.THIN;
            //titleCellStyle.BorderRight = CellBorderType.THIN;
            //titleCellStyle.BorderTop = CellBorderType.THIN;
            //titleCellStyle.BottomBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.LeftBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.RightBorderColor = HSSFColor.BLACK.index;
            //titleCellStyle.TopBorderColor = HSSFColor.BLACK.index;
            //设置字体
            //titleCellStyle.SetFont(font);

            //表头
            IRow headRow = sheet.CreateRow(0);
            headRow.HeightInPoints = headHeight;
            for (int i = 0; i < arrHead.Length; i++)
            {
                headRow.CreateCell(i).SetCellValue(arrHead[i]);
                // headRow.GetCell(i).CellStyle = titleCellStyle;
            }

            //列宽
            for (int j = 0; j < arrColWidth.Length; j++)
            {
                sheet.SetColumnWidth(j, arrColWidth[j] * 256);
            }

            //循环添加行
            for (int k = 0; k < dt.Rows.Count; k++)
            {
                IRow row = sheet.CreateRow(k + 1);
                row.HeightInPoints = colHeight;
                //循环列赋值
                for (int l = 0; l < dt.Columns.Count; l++)
                {

                    row.CreateCell(l).SetCellValue(dt.Rows[k][l].ToString());
                    //row.GetCell(l).CellStyle = cellStyle;


                }
            };

            return book;
        }


        private void timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            string[] arrHead =
                {
               
				"品番",
				"Lot",
				"数量",
                "Part NO.",
                "订单号",
                "打印者",
                "打印时间",
                "厚度",
                "操作员",
				"操作时间"
                };
            int[] arrColWidth = { 15, 15, 10, 15, 15, 12 };

            string cmdText = string.Concat(new string[]
				{
					@"select type as 品番,lot as LOT,amount as 数量,info1 'Part NO.',info2 订单号,info3 打印者,info4 打印时间,THICKNESS 厚度,oper_no, CONVERT(datetime, oper_date,111) from
                        tb_data '",
				});
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
            DataTable dt = dataSet.Tables[0];
            HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
            string path = DBHelper.ExecuteScalar(@"SELECT TOP 1 [DICT_VALUE] FROM [panasonic].[dbo].[tb_dict]   ORDER BY [DICT_VALUE] DESC");
            FileStream file = new FileStream(path + "报表" + datetime + ".xls", FileMode.OpenOrCreate);
            book.Write(file);
            file.Flush();
            file.Close();
            book = null;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
string[] arrHead =
                {
               
				"品番",
				"Lot",
				"数量",
                "Part NO.",
                "订单号",
                "打印者",
                "打印时间",
                "厚度",
                "操作员",
				"操作时间"
                };
            int[] arrColWidth = { 15, 15, 10, 15, 15, 12, 10 };

            string cmdText = string.Concat(new string[]
				{
					@"select type as 品番,lot as LOT,amount as 数量,info1 'Part NO.',info2 订单号,info3 打印者,info4 打印时间,THICKNESS 厚度,oper_no, CONVERT(datetime, oper_date,111) from
                        tb_data ",
				});
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
            DataTable dt = dataSet.Tables[0];
            HSSFWorkbook book = ExcelToNpoiCustom("报表", arrHead, arrColWidth, 25, 18, dt);
            string datetime = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            //string path = Server.MapPath("~/Manager/UserModule/DINA/fileUpload/UpFile/");
            string path = DBHelper.ExecuteScalar(@"SELECT TOP 1 [DICT_VALUE] FROM [panasonic].[dbo].[tb_dict]   ORDER BY [DICT_VALUE] DESC");
            FileStream file = new FileStream(path + "\\报表" + datetime + ".xls", FileMode.OpenOrCreate);
            book.Write(file);
            file.Flush();
            file.Close();
            book = null;
            this.Close();
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
    
    }
}
