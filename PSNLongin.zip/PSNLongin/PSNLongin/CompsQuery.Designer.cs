﻿using System.Windows.Forms;
namespace PSNLongin
{
    partial class CompsQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpStime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpEtime = new System.Windows.Forms.DateTimePicker();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnOutData = new System.Windows.Forms.Button();
            this.dvgQuery = new System.Windows.Forms.DataGridView();
            this.User_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USER_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PASSWORD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USER_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SEX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DEPT_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CREATE_DATE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            ((System.ComponentModel.ISupportInitialize)(this.dvgQuery)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpStime
            // 
            this.dtpStime.CustomFormat = "yyyy年MM月dd日";
            this.dtpStime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStime.Location = new System.Drawing.Point(71, 31);
            this.dtpStime.Name = "dtpStime";
            this.dtpStime.Size = new System.Drawing.Size(200, 21);
            this.dtpStime.TabIndex = 0;
            this.dtpStime.Value = new System.DateTime(2019, 4, 3, 0, 0, 0, 0);
            this.dtpStime.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "起始时间";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(309, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "结束时间";
            this.label2.Visible = false;
            // 
            // dtpEtime
            // 
            this.dtpEtime.CustomFormat = "yyyy年MM月dd日";
            this.dtpEtime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEtime.Location = new System.Drawing.Point(368, 31);
            this.dtpEtime.Name = "dtpEtime";
            this.dtpEtime.Size = new System.Drawing.Size(200, 21);
            this.dtpEtime.TabIndex = 3;
            this.dtpEtime.Value = new System.DateTime(2019, 4, 4, 0, 0, 0, 0);
            this.dtpEtime.Visible = false;
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(614, 32);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 4;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Visible = false;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnOutData
            // 
            this.btnOutData.Location = new System.Drawing.Point(724, 32);
            this.btnOutData.Name = "btnOutData";
            this.btnOutData.Size = new System.Drawing.Size(75, 23);
            this.btnOutData.TabIndex = 5;
            this.btnOutData.Text = "导出";
            this.btnOutData.UseVisualStyleBackColor = true;
            this.btnOutData.Visible = false;
            this.btnOutData.Click += new System.EventHandler(this.btnOutData_Click);
            // 
            // dvgQuery
            // 
            this.dvgQuery.AllowUserToAddRows = false;
            this.dvgQuery.AllowUserToDeleteRows = false;
            this.dvgQuery.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dvgQuery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgQuery.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.User_ID,
            this.USER_NO,
            this.PASSWORD,
            this.USER_NAME,
            this.SEX,
            this.DEPT_ID,
            this.CREATE_DATE});
            this.dvgQuery.Location = new System.Drawing.Point(14, 61);
            this.dvgQuery.Name = "dvgQuery";
            this.dvgQuery.RowTemplate.Height = 23;
            this.dvgQuery.Size = new System.Drawing.Size(851, 230);
            this.dvgQuery.TabIndex = 6;
            this.dvgQuery.Visible = false;
            // 
            // User_ID
            // 
            this.User_ID.DataPropertyName = "userId";
            this.User_ID.HeaderText = "User_ID";
            this.User_ID.Name = "User_ID";
            // 
            // USER_NO
            // 
            this.USER_NO.DataPropertyName = "code";
            this.USER_NO.HeaderText = "USER_NO";
            this.USER_NO.Name = "USER_NO";
            // 
            // PASSWORD
            // 
            this.PASSWORD.DataPropertyName = "password";
            this.PASSWORD.HeaderText = "PASSWORD";
            this.PASSWORD.Name = "PASSWORD";
            // 
            // USER_NAME
            // 
            this.USER_NAME.DataPropertyName = "name";
            this.USER_NAME.HeaderText = "USER_NAME";
            this.USER_NAME.Name = "USER_NAME";
            // 
            // SEX
            // 
            this.SEX.DataPropertyName = "sex";
            this.SEX.HeaderText = "SEX";
            this.SEX.Name = "SEX";
            // 
            // DEPT_ID
            // 
            this.DEPT_ID.DataPropertyName = "sname";
            this.DEPT_ID.HeaderText = "DEPT_ID";
            this.DEPT_ID.Name = "DEPT_ID";
            this.DEPT_ID.Visible = false;
            // 
            // CREATE_DATE
            // 
            this.CREATE_DATE.DataPropertyName = "createTime";
            this.CREATE_DATE.HeaderText = "CREATE_DATE";
            this.CREATE_DATE.Name = "CREATE_DATE";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(874, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 294);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(874, 22);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // CompsQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(874, 316);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dvgQuery);
            this.Controls.Add(this.btnOutData);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.dtpEtime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpStime);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "CompsQuery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "条码扫描管理系统";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.CompsQuery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvgQuery)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpStime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpEtime;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnOutData;
        private System.Windows.Forms.DataGridView dvgQuery;
        private System.Windows.Forms.DataGridViewTextBoxColumn User_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn USER_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PASSWORD;
        private System.Windows.Forms.DataGridViewTextBoxColumn USER_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn SEX;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEPT_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CREATE_DATE;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}