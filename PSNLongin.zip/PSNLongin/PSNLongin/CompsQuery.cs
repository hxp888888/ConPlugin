﻿using Microsoft.CSharp.RuntimeBinder;
using PSNLongin.DAO;
using PSNLongin.DLL;
using PSNLongin.MideaScanner;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class CompsQuery : Form
    {
        [CompilerGenerated]
        private static class o__SiteContainer0
        {
            public static CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>> p__Site1;
        }

        public CompsQuery()
        {
            InitializeComponent();
        }
        CompsDAO cmps = new CompsDAO();
        private DataTable dt = new DataTable();

        private Thread t;
        /// <summary>
        /// 加载 
        /// 根据登录用户控制权限
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CompsQuery_Load(object sender, EventArgs e)
        {
            //this.textBox1.Text=Login.account_Name;
            string text = "select c.menu_id as menuId, c.name as menuName, c.url as formName,c.parent_id as parentId,c.state as openType from tb_user a, tb_role_menu b, tb_menu c ";
            text = text + " where a.ROLE_ID = b.ROLE_ID and a.USER_ID = " + Login.account_ + " and b.MENU_ID = c.MENU_ID ";
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, text, null);
            this.dt = dataSet.Tables[0];
            foreach (DataRow dataRow in this.dt.Rows)
            {
                if ((int)dataRow["parentId"] == 0)
                {
                    ToolStripMenuItems toolStripMenuItems = new ToolStripMenuItems(dataRow["menuName"], dataRow["menuId"], dataRow["formName"], dataRow["openType"]);
                    //toolStripMenuItems.OpenFromName != "";
                    this.menuStrip1.Items.Add(toolStripMenuItems);
                    this.AddMenuItems(toolStripMenuItems);
                }
            }
            this.t = new Thread(new ThreadStart(this.saveData));
            this.t.Start();

            //是否自动创建 "DataGridView" 列
            this.dvgQuery.AutoGenerateColumns = false;


            //this.dvgQuery.DataSource = cmps.getCompsList(Connect.wangVaule);
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.ApplicationExitCall)
            {
                System.Windows.Forms.Application.Exit();
                return;
            }
            if (MessageBox.Show("确定退出本系统吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                this.t.Abort();
                System.Windows.Forms.Application.Exit();
            }
            e.Cancel = true;
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            //是否自动创建 "DataGridView" 列
            //this.dvgQuery.AutoGenerateColumns = false;
            //this.dtpStime.Text = Convert.ToDateTime(DateTime.Now).ToString("yyyy-MM-dd");
            //this.dtpEtime.Text = Convert.ToDateTime(DateTime.Now).ToString("yyyy-MM-dd");
            //this.dvgQuery.DataSource = cmps.getCompsListByTime(Convert.ToDateTime(this.dtpStime.Text), Convert.ToDateTime(this.dtpEtime.Text));
        }

        /// <summary>
        /// 扫描
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tripmeunSM_Click(object sender, EventArgs e)
        {
            SerialPortMng spm = new SerialPortMng();
            spm.Show();
            this.Hide();
        }

        /// <summary>
        /// 导出到EXCEL文档
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOutData_Click(object sender, EventArgs e)
        {
            ////路径
            //string path = AppDomain.CurrentDomain.BaseDirectory + @"" + "综合查询" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".Csv";
            ////导出列及数据
            //if (dt2csv(ToDataTable(cmps.getCompsList(Connect.wangVaule)), path, "综合查询", "USER_ID,USER_NO,PASSWORD,USER_NAME,SEX,CREATE_DATE"))
            //{
            //    MessageBox.Show("导出成功,文件位置:" + path, "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else
            //{
            //    MessageBox.Show("导出失败", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        /// <summary>
        /// 导出报表为xsl
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <param name="strFilePath">物理路径</param>
        /// <param name="tableheader">表头</param>
        /// <param name="columname">字段标题,逗号分隔</param>
        public static bool dt2csv(DataTable dt, string strFilePath, string tableheader, string columname)
        {
            try
            {
                string strBufferLine = "";
                StreamWriter strmWriterObj = new StreamWriter(strFilePath, false, System.Text.Encoding.UTF8);
                strmWriterObj.WriteLine(tableheader);
                strmWriterObj.WriteLine(columname);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    strBufferLine = "";
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (j > 0)
                            strBufferLine += ",";
                        strBufferLine += dt.Rows[i][j].ToString();
                    }
                    strmWriterObj.WriteLine(strBufferLine);
                }
                strmWriterObj.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// List转DataTable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static DataTable ToDataTable<T>(IEnumerable<T> collection)
        {
            var props = typeof(T).GetProperties();
            var dt = new DataTable();
            dt.Columns.AddRange(props.Select(p => new DataColumn(p.Name, p.PropertyType)).ToArray());
            if (collection.Count() > 0)
            {
                for (int i = 0; i < collection.Count(); i++)
                {
                    ArrayList tempList = new ArrayList();
                    foreach (PropertyInfo pi in props)
                    {
                        object obj = pi.GetValue(collection.ElementAt(i), null);
                        tempList.Add(obj);
                    }
                    object[] array = tempList.ToArray();
                    dt.LoadDataRow(array, true);
                }
            }
            return dt;
        }


        private void AddMenuItems(ToolStripMenuItems tm)
        {
            foreach (DataRow dataRow in this.dt.Rows)
            {
                if ((int)dataRow["parentId"] == (int)tm.Tag)
                {
                    ToolStripMenuItems toolStripMenuItems = new ToolStripMenuItems(dataRow["menuName"], dataRow["menuId"], dataRow["formName"], dataRow["openType"]);
                    if (toolStripMenuItems.OpenFromName != "")
                    {
                        toolStripMenuItems.Click += new EventHandler(this.tms_Click);
                    }
                    tm.DropDownItems.Add(toolStripMenuItems);
                    this.AddMenuItems(toolStripMenuItems);
                }
            }
        }

        /// <summary>
        /// 菜单下子项
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tms_Click(object sender, EventArgs e)
        {
            ToolStripMenuItems toolStripMenuItems = sender as ToolStripMenuItems;
            Type type = Assembly.LoadFrom("PSNLongin.exe").GetType(toolStripMenuItems.OpenFromName);
            object obj = Activator.CreateInstance(type);
            Form form = obj as Form;
            form.Text = toolStripMenuItems.Text;
          
            form.Show();
            //form.Dispose();
        }
        #region ToExcel
        public void ToExcel(string strName)
        {
            string[] array = new string[]
            {
                "品番",
                "Lot",
                "数量",
                "流水页码",
                "销售订单号",
                "支番号",
                "PartNumber"
            };
            DataSet dataSet = DBHelper.GetDataSet2(publicVar.Conn, "select dict_value from tb_dict where dict_type = 'FILE_ROOT'", null);
            string text;
            if (dataSet.Tables[0].Rows.Count == 0)
            {
                text = AppDomain.CurrentDomain.BaseDirectory;
            }
            else
            {
                text = dataSet.Tables[0].Rows[0]["dict_value"].ToString();
            }
            string text2;
            if (text.EndsWith("\\"))
            {
                text2 = text + strName + ".xls";
            }
            else
            {
                text2 = text + "\\" + strName + ".xls";
            }
            if (File.Exists(text2))
            {
                return;
            }
            string cmdText = "update tb_data set export_flag = '" + strName + "'";
            DBHelper.ExecuteNonQuery(cmdText, null);
            string cmdText2 = "select type,lot,amount,info1,info2,info3,info4 from tb_data where export_flag = '" + strName + "'";
            DataSet dataSet2 = DBHelper.GetDataSet2(publicVar.Conn, cmdText2, null);
            DataTable dataTable = dataSet2.Tables[0];
            if (dataTable.Rows.Count == 0)
            {
                return;
            }
            if (text2.Length != 0)
            {
                Missing value = Missing.Value;
                Microsoft.Office.Interop.Excel.Application application = (Microsoft.Office.Interop.Excel.Application)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
                application.Visible = false;
                CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                Microsoft.Office.Interop.Excel.Workbook workbook = application.Workbooks.Add(value);
                if (CompsQuery.o__SiteContainer0.p__Site1 == null)
                {
                    CompsQuery.o__SiteContainer0.p__Site1 = CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(Microsoft.Office.Interop.Excel.Worksheet), typeof(CompsQuery)));
                }
                
                Microsoft.Office.Interop.Excel.Worksheet worksheet = CompsQuery.o__SiteContainer0.p__Site1.Target(CompsQuery.o__SiteContainer0.p__Site1, workbook.Worksheets.Add(value, value, value, value));
                worksheet.Name = "data";
                for (int i = 0; i < array.Length; i++)
                {
                    worksheet.Cells[1, i + 1] = array[i];
                }
                Microsoft.Office.Interop.Excel.Range arg_250_0 = worksheet.get_Range("A2", value);
                Microsoft.Office.Interop.Excel.Range range = null;
                int count = dataTable.Rows.Count;
                int j = 0;
                int num = 1;
                int count2 = dataTable.Columns.Count;
                object[,] array2 = new object[num, count2];
                try
                {
                    int num2 = num;
                    while (j < count)
                    {
                        if (count - j < num)
                        {
                            num2 = count - j;
                        }
                        for (int k = 0; k < num2; k++)
                        {
                            for (int l = 0; l < count2; l++)
                            {
                                array2[k, l] = dataTable.Rows[k + j][l];
                            }
                            System.Windows.Forms.Application.DoEvents();
                        }
                        range = worksheet.get_Range("A" + (j + 2).ToString(), ((char)(65 + count2 - 1)).ToString() + (j + num2 + 1).ToString());
                        range.Value2 = array2;
                        j += num2;
                    }
                    worksheet.SaveAs(text2, value, value, value, value, value, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, value, value, value);
                    Marshal.ReleaseComObject(range);
                    //this.KillSpecialExcel(application);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
                Thread.CurrentThread.CurrentCulture = currentCulture;
            }
        }
        #endregion


       [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

       public void KillSpecialExcel(Microsoft.Office.Interop.Excel.Application m_objExcel)
       {
           try
           {
               if (m_objExcel != null)
               {
                   int processId;
                   CompsQuery.GetWindowThreadProcessId(new IntPtr(m_objExcel.Hwnd), out processId);
                   Process.GetProcessById(processId).Kill();
               }
           }
           catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
       }

        private void saveData()
        {
            string a = "";
            while (true)
            {
                Thread.Sleep(10000);
                DateTime now = DateTime.Now;
                DataSet dataSet = DBHelper.GetDataSet2(publicVar.Conn, "select dict_value from tb_dict where dict_type like 'EXPORT_TIME%' ", null);
                foreach (DataRow dataRow in dataSet.Tables[0].Rows)
                {
                    if (Convert.ToInt32(dataRow["dict_value"].ToString()) == now.Hour)
                    {
                        string text = string.Format("{0:yyyyMMddHH}", now);
                        if (a != text)
                        {
                            a = text;
                           this.ToExcel(text);
                        }
                    }
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        public void closethis()
        {
            this.Close();
        }


    }
}
