﻿namespace PSNLongin
{
    partial class Connect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvUserList = new System.Windows.Forms.DataGridView();
            this.cmbToF = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.UserId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contacts = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rows = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctmeunDel = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.meunUpd = new System.Windows.Forms.ToolStripTextBox();
            this.trlpDel = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSelect = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblMosaic = new System.Windows.Forms.Label();
            this.lblPage = new System.Windows.Forms.Label();
            this.lblPageCount = new System.Windows.Forms.Label();
            this.lblNextpage = new System.Windows.Forms.LinkLabel();
            this.lblPreviouspage = new System.Windows.Forms.LinkLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tlstrpResgin = new System.Windows.Forms.ToolStripMenuItem();
            this.tstrpExit = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserList)).BeginInit();
            this.ctmeunDel.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvUserList
            // 
            this.dgvUserList.AllowUserToAddRows = false;
            this.dgvUserList.AllowUserToDeleteRows = false;
            this.dgvUserList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUserList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cmbToF,
            this.UserId,
            this.UCode,
            this.Name,
            this.Sex,
            this.SName,
            this.contacts,
            this.phone,
            this.Rows});
            this.dgvUserList.ContextMenuStrip = this.ctmeunDel;
            this.dgvUserList.Location = new System.Drawing.Point(12, 107);
            this.dgvUserList.Name = "dgvUserList";
            this.dgvUserList.RowTemplate.Height = 23;
            this.dgvUserList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUserList.Size = new System.Drawing.Size(987, 221);
            this.dgvUserList.TabIndex = 0;
            // 
            // cmbToF
            // 
            this.cmbToF.HeaderText = " ";
            this.cmbToF.Name = "cmbToF";
            this.cmbToF.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cmbToF.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.cmbToF.Visible = false;
            // 
            // UserId
            // 
            this.UserId.DataPropertyName = "userId";
            this.UserId.HeaderText = "用户Id";
            this.UserId.Name = "UserId";
            this.UserId.Visible = false;
            // 
            // UCode
            // 
            this.UCode.DataPropertyName = "code";
            this.UCode.HeaderText = "账号";
            this.UCode.Name = "UCode";
            // 
            // Name
            // 
            this.Name.DataPropertyName = "name";
            this.Name.HeaderText = "用户名";
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            // 
            // Sex
            // 
            this.Sex.DataPropertyName = "sex";
            this.Sex.HeaderText = "性别";
            this.Sex.Name = "Sex";
            // 
            // SName
            // 
            this.SName.DataPropertyName = "Sname";
            this.SName.HeaderText = "所属班组";
            this.SName.Name = "SName";
            this.SName.ReadOnly = true;
            // 
            // contacts
            // 
            this.contacts.DataPropertyName = "contacts";
            this.contacts.HeaderText = "联系人";
            this.contacts.Name = "contacts";
            this.contacts.ReadOnly = true;
            // 
            // phone
            // 
            this.phone.DataPropertyName = "phone";
            this.phone.HeaderText = "联系电话";
            this.phone.Name = "phone";
            this.phone.ReadOnly = true;
            // 
            // Rows
            // 
            this.Rows.DataPropertyName = "rownumber";
            this.Rows.HeaderText = "行";
            this.Rows.Name = "Rows";
            this.Rows.Visible = false;
            // 
            // ctmeunDel
            // 
            this.ctmeunDel.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.meunUpd,
            this.trlpDel});
            this.ctmeunDel.Name = "ctmeunDel";
            this.ctmeunDel.Size = new System.Drawing.Size(161, 51);
            this.ctmeunDel.Text = "删除";
            // 
            // meunUpd
            // 
            this.meunUpd.Name = "meunUpd";
            this.meunUpd.Size = new System.Drawing.Size(100, 23);
            this.meunUpd.Text = "修改";
            this.meunUpd.Click += new System.EventHandler(this.meunUpd_Click);
            // 
            // trlpDel
            // 
            this.trlpDel.Name = "trlpDel";
            this.trlpDel.Size = new System.Drawing.Size(160, 22);
            this.trlpDel.Text = "删除";
            this.trlpDel.Click += new System.EventHandler(this.trlpDel_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(231, 57);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 2;
            this.btnSelect.Text = "查询";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(63, 59);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(132, 21);
            this.txtName.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(10, 62);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 12);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "用户名:";
            // 
            // lblMosaic
            // 
            this.lblMosaic.Location = new System.Drawing.Point(15, 345);
            this.lblMosaic.Name = "lblMosaic";
            this.lblMosaic.Size = new System.Drawing.Size(177, 23);
            this.lblMosaic.TabIndex = 3;
            this.lblMosaic.Text = "当前第 1 页  共 5 页 100 条数据";
            // 
            // lblPage
            // 
            this.lblPage.ForeColor = System.Drawing.Color.Black;
            this.lblPage.Location = new System.Drawing.Point(54, 345);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(18, 13);
            this.lblPage.TabIndex = 4;
            this.lblPage.Text = "1";
            // 
            // lblPageCount
            // 
            this.lblPageCount.Location = new System.Drawing.Point(105, 345);
            this.lblPageCount.Name = "lblPageCount";
            this.lblPageCount.Size = new System.Drawing.Size(19, 13);
            this.lblPageCount.TabIndex = 5;
            this.lblPageCount.Text = "5";
            // 
            // lblNextpage
            // 
            this.lblNextpage.AutoSize = true;
            this.lblNextpage.Location = new System.Drawing.Point(958, 345);
            this.lblNextpage.Name = "lblNextpage";
            this.lblNextpage.Size = new System.Drawing.Size(41, 12);
            this.lblNextpage.TabIndex = 52;
            this.lblNextpage.TabStop = true;
            this.lblNextpage.Text = "下一页";
            this.lblNextpage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblNextpage_LinkClicked);
            // 
            // lblPreviouspage
            // 
            this.lblPreviouspage.AutoSize = true;
            this.lblPreviouspage.Location = new System.Drawing.Point(879, 345);
            this.lblPreviouspage.Name = "lblPreviouspage";
            this.lblPreviouspage.Size = new System.Drawing.Size(41, 12);
            this.lblPreviouspage.TabIndex = 53;
            this.lblPreviouspage.TabStop = true;
            this.lblPreviouspage.Text = "上一页";
            this.lblPreviouspage.Visible = false;
            this.lblPreviouspage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblPreviouspage_LinkClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpResgin,
            this.tstrpExit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1023, 25);
            this.menuStrip1.TabIndex = 54;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // tlstrpResgin
            // 
            this.tlstrpResgin.Name = "tlstrpResgin";
            this.tlstrpResgin.Size = new System.Drawing.Size(44, 21);
            this.tlstrpResgin.Text = "注册";
            this.tlstrpResgin.Click += new System.EventHandler(this.tlstrpResgin_Click);
            // 
            // tstrpExit
            // 
            this.tstrpExit.Name = "tstrpExit";
            this.tstrpExit.Size = new System.Drawing.Size(44, 21);
            this.tstrpExit.Text = "退出";
            this.tstrpExit.Click += new System.EventHandler(this.tstrpExit_Click);
            // 
            // Connect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 367);
            this.Controls.Add(this.dgvUserList);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.lblNextpage);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblPreviouspage);
            this.Controls.Add(this.lblPageCount);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblPage);
            this.Controls.Add(this.lblMosaic);
            this.MaximizeBox = false;
           // this.Name = "Connect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "用户管理";
            this.Load += new System.EventHandler(this.UserMng_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserList)).EndInit();
            this.ctmeunDel.ResumeLayout(false);
            this.ctmeunDel.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvUserList;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Label lblMosaic;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label lblPageCount;
        private System.Windows.Forms.LinkLabel lblNextpage;
        private System.Windows.Forms.LinkLabel lblPreviouspage;
        private System.Windows.Forms.ContextMenuStrip ctmeunDel;
        private System.Windows.Forms.ToolStripTextBox meunUpd;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tstrpExit;
        private System.Windows.Forms.ToolStripMenuItem trlpDel;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cmbToF;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserId;
        private System.Windows.Forms.DataGridViewTextBoxColumn UCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn SName;
        private System.Windows.Forms.DataGridViewTextBoxColumn contacts;
        private System.Windows.Forms.DataGridViewTextBoxColumn phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rows;
        private System.Windows.Forms.ToolStripMenuItem tlstrpResgin;
    }
}