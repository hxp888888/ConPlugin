﻿using PSNLongin.DAO;
using PSNLongin.DLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class Connect : Form
    {
        public Connect()
        {
            InitializeComponent();
        }




        /// <summary>
        /// 根据用户名查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSelect_Click(object sender, EventArgs e)
        {
            PageNumber = 1;

            u = 1;
            //用户名称
            string name = this.txtName.Text.Trim();
            this.lblNextpage.Visible = true;
            this.lblPreviouspage.Visible = false;

            //加载所有数据
            Displaydevice(0, name);
        }
       // private Thread t;
        /// <summary>
        /// 加载事件
        /// 加载所有用户信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserMng_Load(object sender, EventArgs e)
        {
            Displaydevice(0, null);//查询所有用户信息
            this.Refresh();//刷新
            
        }

        /// <summary>
        /// 用户Id
        /// </summary>
        public static string wangVaule;

        /// <summary>
        /// 用户账号
        /// </summary>
        public static string wangVauleName;


        /// <summary>
        /// 显示页
        /// </summary>
        int u = 1;

        /// <summary>
        /// 是否是查询大于0为查询
        /// </summary>
        int PageNumber;



        /// <summary>
        /// 连接记录类
        /// </summary>
        UserDLL record = new UserDLL();
        #region 加载用户所有数据
        /// <summary>
        /// 加载用户所有数据
        /// </summary>
        public void Displaydevice(int pageSize, string Name)
        {
            try
            {
                //是否自动创建 "DataGridView" 列
                this.dgvUserList.AutoGenerateColumns = false;
                //从数据库得到的数据绑定到 "DataGridView" 上
                this.dgvUserList.DataSource = record.getRecordBuss(0,Name);

                if (PageNumber > 0)
                {
                    //数据库查询多少条数据
                    double CountList = record.getRecordBussCountList(Name);
                    double P = CountList / 8;
                    int Page = Convert.ToInt32(CountList / 8);
                    if (P > Page)
                    {
                        this.lblPageCount.Text = (Page + 1).ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                    else
                    {
                        this.lblPageCount.Text = Page.ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }

                }
                else
                {
                    //数据库查询多少条数据
                    double Count = record.countRecordBuss(Login.account_);
                    double P = Count / 8;
                    int Page = Convert.ToInt32(Count / 8);
                    if (P > Page)
                    {
                        this.lblPageCount.Text = (Page + 1).ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + Count.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + Count.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                    else
                    {
                        this.lblPageCount.Text = Page.ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + "  页 " + Count.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + "  页 " + Count.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                }



            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// 选中行，修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void meunUpd_Click(object sender, EventArgs e)
        {

            UpdUser rs = new UpdUser();
            this.DialogResult = DialogResult.OK;
            wangVaule = dgvUserList.SelectedRows[0].Cells["UserId"].Value.ToString();
            wangVauleName = dgvUserList.SelectedRows[0].Cells["UCode"].Value.ToString();
            rs.ShowDialog(this);
            
        }






    

        /// <summary>
        /// 下一页
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lblNextpage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
            //获取 “dgvRecordList” 最后一行的下标
            int last = dgvUserList.FirstDisplayedScrollingRowIndex = dgvUserList.RowCount - 1;
            //获取“dgvRecordList” rownumber的值
            string lowerId = this.dgvUserList.Rows[last].Cells["Rows"].Value.ToString();

            if (PageNumber > 0)
            {
                this.lblPreviouspage.Visible = true;
                u = u + 1;
                //设备名称
                string Equipment = this.txtName.Text.Trim();
                //加载所有数据
                Displaydevice(Convert.ToInt32(lowerId) + 1, Equipment);
            }
            else
            {
                this.lblPreviouspage.Visible = true;
                u = u + 1;
                //加载所有数据
                Displaydevice(Convert.ToInt32(lowerId) + 1, null);
            }


        }

        /// <summary>
        /// 上一页
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lblPreviouspage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            //获取 “dgvRecordList” 第一条 ‘rownumber’ 数据
            string first = dgvUserList.Rows[0].Cells["Rows"].Value.ToString();
            this.lblNextpage.Visible = true;
            if (PageNumber > 0)
            {
                u = u - 1;
                //设备名称
                string Equipment = this.txtName.Text.Trim();
                //加载所有数据
                Displaydevice(Convert.ToInt32(first) - 8, Equipment);
            }
            else
            {
                u = u - 1;
                //加载所有数据
                Displaydevice(Convert.ToInt32(first) - 8, null);
            }
        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tstrpExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void trlpDel_Click(object sender, EventArgs e)
        {
            DialogResult DLResult = MessageBox.Show("确定删除吗？", "温馨提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (DLResult == DialogResult.OK)
            {
                //删除
                string id = dgvUserList.SelectedRows[0].Cells["UserId"].Value.ToString();
                int delCount = UserDAO.DeleteUser(id);
                if (delCount == 1)
                {
                    //删除成功
                    MessageBox.Show("删除成功！","温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.dgvUserList.DataSource = record.getRecordBuss(0,null);
                    //if (true)
                    //{
                    //    new Connect().Refresh();
                    //}
                    Displaydevice(0, null);
                }
                else
                {
                    //删除失败
                    MessageBox.Show("删除失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("用户取消操作！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// 调整权限管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tlstripJsd_Click(object sender, EventArgs e)
        {
            PowerMng pMng = new PowerMng();
            pMng.Show();
           
        }

       /// <summary>
       /// 修改密码
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void tlstrpResetPwd_Click(object sender, EventArgs e)
        {
            UpdPwd uPwd = new UpdPwd();
            wangVaule = Login.account_;
            uPwd.ShowDialog(this);
            this.Hide();
        }

        /// <summary>
        /// 产品生产管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tstrpProduction_Click(object sender, EventArgs e)
        {
            CompsQuery cq = new CompsQuery();
           
          string jId=  UserDAO.GetJid(Convert.ToInt32( Login.account_));
          wangVaule = jId;//用户Id
            cq.Show();
        }


        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tlstrpResgin_Click(object sender, EventArgs e)
        {
            Register rs = new Register();
            this.DialogResult = DialogResult.OK;
            rs.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }


       






    }
}
