﻿using PSNLongin.DLL;
using PSNLongin.Model;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DAO
{
   public class CompsDAO
    {
        #region 按条件查询数据
        /// <summary>
        /// 按条件查询数据
        /// </summary>
        /// <param name="Name">用户名称</param>
        /// <returns></returns>
        public List<RecordBuss> getCompsListByTime(DateTime stime, DateTime etime)
        {
            //创建一个集合对象
            List<RecordBuss> lisReceiveData = new List<RecordBuss>();

            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    sb.Append(" select t.Uid, t.Ucode,t.password, t.Uname,Sex,createTime  from UserTable t  inner join SteamTable t1 on t.sdbTId=t1.Sid  ");
                    SqlCommand comm = new SqlCommand(sb.ToString(), conn);

                    sb.Append(" where CONVERT(varchar(100), Stime, 23)=@stime   and CONVERT(varchar(100), Etime, 23)=@etime   ");
                        SqlParameter[] paras = new SqlParameter[]
                        {
                            new SqlParameter("@stime",Convert.ToDateTime(stime).ToString("yyyy-MM-dd").Substring(0,10)),
                            new SqlParameter("@etime",Convert.ToDateTime(etime).ToString("yyyy-MM-dd").Substring(0,10))
                        };
                        comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.AddRange(paras);
                    
                    

                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出

                        while (reader.Read())
                        {

                            RecordBuss record = new RecordBuss();
                            record.userId = Convert.ToInt32(reader[0]);
                            record.code = Convert.ToString(reader[1]);
                            record.password = Convert.ToString(reader[2]);
                            record.name = Convert.ToString(reader[3]);
                            record.sex = Convert.ToString(reader[4]);
                            record.createTime = Convert.ToDateTime(reader[5]);
                            lisReceiveData.Add(record);

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return lisReceiveData;

        }
        #endregion


        #region 按条件查询数据
        /// <summary>
        /// 按条件查询数据
        /// string jspName
        /// </summary>
        /// <param name="Name">用户名称</param>
        /// <returns></returns>
        public List<Comps> getCompsList(string jspId)
        {
            //创建一个集合对象
            List<Comps> lisReceiveData = new List<Comps>();

            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    sb.Append("  select t.Uid, t.Ucode,t.password, t.Uname,Sex,createTime  from UserTable t  left join RoleTable t2 on t.roleId=t2.Rid  ");
                    SqlCommand comm =  new SqlCommand(sb.ToString(), conn); ;
                    if (jspId!="1")
                    {
                        sb.Append("where t3.Jid=@id ");
                        SqlParameter paras = new SqlParameter("@id", jspId);
                         comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.Add(paras);
                    }
                    //sb.Append(" where Stime=@stime   and Etime=@etime   ");
                    //SqlParameter[] paras = new SqlParameter[]
                    //{
                    //    new SqlParameter("@stime",Convert.ToDateTime(stime).ToString("yyyy-MM-dd HH:mm")),
                    //    new SqlParameter("@etime",Convert.ToDateTime(etime).ToString("yyyy-MM-dd HH:mm"))
                    //};
                    


                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出

                        while (reader.Read())
                        {

                            Comps record = new Comps();
                            record.userId = Convert.ToInt32(reader[0]);
                            record.code = Convert.ToString(reader[1]);
                            record.password = Convert.ToString(reader[2]);
                            record.name = Convert.ToString(reader[3]);
                          
                            record.sex = Convert.ToString(reader[4]);
                            record.createTime = Convert.ToDateTime(reader[5]);
                          
                            lisReceiveData.Add(record);

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return lisReceiveData;

        }
        #endregion
    }
}
