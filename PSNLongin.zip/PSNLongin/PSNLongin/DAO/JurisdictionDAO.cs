﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DAO
{
   public class JurisdictionDAO
    {
        #region 修改用户
        /// <summary>
        /// 修改用户
        /// </summary>
        /// <param name="user">用户对象</param>u
        /// <returns></returns>
       public int UpdateUserTable(Jurisdiction user)
        {
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "update tb_role set ROLE_NAME=@name where ROLE_ID=@Id";
                    SqlParameter[] paras = new SqlParameter[] 
                   {
                   
                    new SqlParameter("@name",user.roleName),
                    new SqlParameter("@Id",user.roleId)
                   };
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.AddRange(paras);
                    return comm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }
        #endregion

        /// <summary>
        /// 删除用户信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int DeleteUser(string id)
        {
            string sql = string.Format("delete from tb_role where ROLE_ID='{0}'", id);
            return DBHelper.ExecuteNonQuery(sql);
        }


        #region 查询所有用户
        /// <summary>
        /// 查询所有用户
        /// </summary>
        /// <param name="uname">用户账号</param>
        /// <returns></returns>
        public Jurisdiction Queryuser(string uname)
        {
            Jurisdiction jsdtion = new Jurisdiction();
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql =string.Format( @" select * from tb_role t  where ROLE_ID=@uname");
                    SqlParameter para = new SqlParameter("@uname", uname);
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.Add(para);
                    using (SqlDataReader reader1 = comm.ExecuteReader())
                    {
                        //循坏输出
                        while (reader1.Read())
                        {
                            jsdtion.roleId = Convert.ToInt32(reader1["ROLE_ID"]);
                            jsdtion.roleName = reader1["ROLE_NAME"].ToString();
                            //jsdtion.JsdName = reader["Jname"].ToString();
                           

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return jsdtion;
        }
        #endregion


        #region 查询所有用户集合判断用户账号是否相等
        /// <summary>
        /// 查询所有用户集合判断用户账号是否相等
        /// </summary>
        /// <param name="uname">用户账号</param>
        /// <returns></returns>
        public List<Jurisdiction> QueryuserList(string uname)
        {
            List<Jurisdiction> userList = new List<Jurisdiction>();
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql =string.Format( "select ROLE_NAME from tb_role  where ROLE_ID=@uname");
                    SqlParameter para = new SqlParameter("@uname", uname);
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.Add(para);
                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出
                        while (reader.Read())
                        {
                            Jurisdiction user = new Jurisdiction();
                            user.roleName = reader["ROLE_NAME"].ToString();
                            userList.Add(user);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return userList;
        }
        #endregion
   }
}
