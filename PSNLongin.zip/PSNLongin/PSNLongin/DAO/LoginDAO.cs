﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DAO
{
   public class LoginDAO
    {

   



       //登录
        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="name"></param>
        /// <param name="password"></param>
        /// <returns></returns>
       public static string Sign(string user, string pwd)
        {
            string sql = "select USER_ID from tb_user where user_no = '" + user + "' and password = '" + pwd + "'";
            return DBHelper.ExecuteScalar(sql);
        }
       public static string getName(string user, string pwd)
       {
           string sql = "select USER_NO from tb_user where user_no = '" + user + "' and password = '" + pwd + "'";
           return DBHelper.ExecuteScalar(sql);
       }

      


   }
}
