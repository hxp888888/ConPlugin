﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using  PSNLongin.Model;

namespace PSNLongin.DAO
{
   public class UserDAO
    {

        #region 修改用户
        /// <summary>
        /// 修改用户
        /// </summary>
        /// <param name="user">用户对象</param>u
        /// <returns></returns>
        public int UpdateUserTable(UserTable user)
        {
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "update tb_user set password=@pwd , phone=@phone,LoginTim=@aTime where USER_ID=@Id";
                    SqlParameter[] paras = new SqlParameter[] 
                   {
                    new SqlParameter("@pwd",user.pwd),
                    new SqlParameter("@phone",user.phone),
                    new SqlParameter("@Id",user.userId),
                     new SqlParameter("@aTime",user.createTime)
                   };
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.AddRange(paras);
                    return comm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }
        #endregion

        /// <summary>
        /// 删除用户信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static int DeleteUser(string id)
        {
            string sql = string.Format("delete from tb_user where USER_ID='{0}'", id);
            return DBHelper.ExecuteNonQuery(sql);
        }


        #region 查询所有用户
        /// <summary>
        /// 查询所有用户
        /// </summary>
        /// <param name="uname">用户账号</param>
        /// <returns></returns>
        public UserTable Queryuser(string uname)
        {
            UserTable user = new UserTable();
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "select * from tb_user as u where USER_ID=@uname";
                    SqlParameter para = new SqlParameter("@uname", uname);
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.Add(para);
                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出
                        while (reader.Read())
                        {
                            user.code = Convert.ToString(reader["USER_NO"]);
                            user.name = reader["USER_NAME"].ToString();
                            user.pwd = reader["password"].ToString();
                            user.sex = reader["Sex"].ToString();
                            //user.sbdTeam = reader["SbdTeam"].ToString();
                            //user.contacts = reader["Contacts"].ToString();
                            user.phone = reader["phone"].ToString();
                            
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return user;
        }
        #endregion

        #region 修改密码
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="user">用户对象</param>u
        /// <returns></returns>
        public int UpdateUserPwd(UserTable user)
        {
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "update tb_user set password=@pwd,LoginTim=@time  where USER_ID=@Id";
                    SqlParameter[] paras = new SqlParameter[] 
                   {
                    new SqlParameter("@pwd",user.pwd),
                    new SqlParameter("@Id",user.userId),
                     new SqlParameter("@time",user.createTime)
                   };
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.AddRange(paras);
                    return comm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }
        #endregion

        #region 查询所有用户集合判断用户账号是否相等
        /// <summary>
        /// 查询所有用户集合判断用户账号是否相等
        /// </summary>
        /// <param name="uname">用户账号</param>
        /// <returns></returns>
        public List<UserTable> QueryuserList(string uname)
        {
            List<UserTable> userList = new List<UserTable>();
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "select u.Ucode from tb_user as u";
                    SqlParameter para = new SqlParameter("@uname", uname);
                    SqlCommand comm = new SqlCommand(sql, conn);
                    comm.Parameters.Add(para);
                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出
                        while (reader.Read())
                        {
                            UserTable user = new UserTable();
                            user.code = reader["Ucode"].ToString();
                            userList.Add(user);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return userList;
        }
        #endregion

       /// <summary>
       /// 获取权限ID
       /// </summary>
       /// <param name="user"></param>
       /// <param name="pwd"></param>
       /// <returns></returns>
        public static string GetJid(int uid)
        {
            string sql = "select jid  from tb_user t  inner join SteamTable t1 on t.sdbTId=t1.Sid left join RoleTable t2 on t.roleId=t2.Rid left join JurisdictionTable t3 on t3.Jid=t2.JsdId  where uid=" + uid;
            return DBHelper.ExecuteScalar(sql);
        }

       /// <summary>
       /// 获取上一次登录时间
       /// </summary>
       /// <param name="uid"></param>
       /// <returns></returns>
        public static string GetLoginTime(int uid)
        {
            string sql = @"select Logintim from tb_user where USER_ID="+uid;
            return DBHelper.ExecuteScalar(sql);
        }
       /// <summary>
       /// 更新最新一次登录时间
       /// </summary>
       /// <returns></returns>
        //public static int UpdLoginDate(int id)
        //{
        //    string sql = string.Format("update tb_user set Logintim=GETDATE() where USER_ID={0}", id);
        //    return DBHelper.ExecuteNonQuery(sql);
        //}

    }
}
