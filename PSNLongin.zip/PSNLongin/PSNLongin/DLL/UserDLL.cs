﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DLL
{
   public class UserDLL
    {
        #region 按条件查询数据
        /// <summary>
        /// 按条件查询数据
        /// </summary>
        /// <param name="Name">用户名称</param>
        /// <returns></returns>
       public List<RecordBuss> getRecordBuss(int pageSize, string Name)
        {
            //创建一个集合对象
            List<RecordBuss> lisReceiveData = new List<RecordBuss>();

            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    sb.Append(@"select top 8 * from ( select t.USER_ID, t.USER_NO, t.USER_NAME,t.phoneMaster,t.Phone,row_number()over(order by t.USER_ID desc) rownumber,Sex,t1.ROLE_ID  from tb_user t  left join tb_role t1 on t.ROLE_ID=t1.ROLE_ID  ");
                    SqlCommand comm = new SqlCommand(sb.ToString(), conn);
                    if (Name != null)
                    {
                        sb.Append("where t.USER_NAME like @USER_NAME    ) p where p.rownumber>=" + pageSize + "order by p.USER_ID desc");
                        SqlParameter[] paras = new SqlParameter[]
                        {
                            new SqlParameter("@USER_NAME",'%'+ Name +'%'),
                        };
                        comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.AddRange(paras);
                    }
                    else
                    {
                    sb.Append("  ) p where p.rownumber>=" + pageSize + "order by p.USER_ID desc");
                    comm = new SqlCommand(sb.ToString(), conn);
                    }
                  
                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出

                        while (reader.Read())
                        {

                            RecordBuss record = new RecordBuss();
                            record.userId =Convert.ToInt32( reader[0]);
                            record.code = Convert.ToString(reader[1]);
                            record.name = Convert.ToString(reader[2]);
                            //record.sName = Convert.ToString(reader[3]);
                            record.contacts = Convert.ToString(reader[3]);
                            record.phone = Convert.ToString(reader[4]);
                            record.rownumber = Convert.ToInt32(reader[5]);
                            record.sex = Convert.ToString(reader[6]);
                            record.JId = Convert.ToInt32(reader[7]);
                            lisReceiveData.Add(record);

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return lisReceiveData;

        }
        #endregion

        #region 查询总数量
        /// <summary>
        /// 查询总数量
        /// </summary>
        /// <param name="account">用户账号</param>
        /// <returns></returns>
        public int countRecordBuss(string account)
        {
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "select count(1) from tb_user t  where 1=1";
                    SqlCommand comm = new SqlCommand(sql, conn);
                    return Convert.ToInt32(comm.ExecuteScalar());
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }

        }
        #endregion

        #region 条件查询总数量
        /// <summary>
        /// 条件查询总数量
        /// </summary>
        /// <param name="Name">设备名称</param>
        /// <param name="account">用户账号</param>
        /// <returns></returns>
        public int getRecordBussCountList(string Name)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    //SQL语句
                    sb.Append("select count(1) from tb_user t   where 1=1 ");
                    SqlCommand comm = new SqlCommand(sb.ToString(), conn);
                    if (Name != null)
                    {
                        sb.Append(" and t.USER_NAME like  @USER_NAME ");
                        SqlParameter[] paras = new SqlParameter[]
                        {
                            new SqlParameter("@USER_NAME",'%'+ Name +'%'),
                        };
                        comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.AddRange(paras);
                    }
                    else
                    {
                        comm = new SqlCommand(sb.ToString(), conn);
                    }
                    return Convert.ToInt32(comm.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion
    }
}
