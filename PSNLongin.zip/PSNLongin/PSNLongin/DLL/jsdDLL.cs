﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DLL
{
  public  class jsdDLL
    {
        #region 按条件查询数据
        /// <summary>
        /// 按条件查询数据
        /// </summary>
        /// <param name="Name">用户名称</param>
        /// <returns></returns>
        public List<RecordBuss> getRecordBuss(string Name)
        {
            //创建一个集合对象
            List<RecordBuss> lisReceiveData = new List<RecordBuss>();

            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    sb.Append("select ROLE_ID,ROLE_NAME from tb_role t  where 1=1");
                    SqlCommand comm = new SqlCommand(sb.ToString(), conn);
                    if (Name != null)
                    {
                        sb.Append("and ROLE_NAME like @Name  ");
                        SqlParameter[] paras = new SqlParameter[]
                        {
                            new SqlParameter("@Name",'%'+ Name +'%'),
                        };
                        comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.AddRange(paras);
                    }

                    using (SqlDataReader reader = comm.ExecuteReader())
                    {
                        //循坏输出

                        while (reader.Read())
                        {

                            RecordBuss record = new RecordBuss();
                            record.RId = Convert.ToInt32(reader[0]);
                            //record.Jname = Convert.ToString(reader[2]);
                            record.Rname = Convert.ToString(reader[1]);
                            lisReceiveData.Add(record);

                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return lisReceiveData;

        }
        #endregion

        #region 查询总数量
        /// <summary>
        /// 查询总数量
        /// </summary>
        /// <param name="account">用户账号</param>
        /// <returns></returns>
        public int countRecordBuss(string account)
        {
            using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
            {
                try
                {
                    conn.Open();
                    string sql = "select count(1) from tb_role t where 1=1 ";
                    SqlCommand comm = new SqlCommand(sql, conn);
                    return Convert.ToInt32(comm.ExecuteScalar());
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }

        }
        #endregion

        #region 条件查询总数量
        /// <summary>
        /// 条件查询总数量
        /// </summary>
        /// <param name="Name">设备名称</param>
        /// <param name="account">用户账号</param>
        /// <returns></returns>
        public int getRecordBussCountList(string Name)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                //连接数据库
                using (SqlConnection conn = new SqlConnection(DBHelper.connectionString))
                {
                    //打开数据库
                    conn.Open();
                    //SQL语句
                    sb.Append("select count(1) from tb_role t  where 1=1");
                    SqlCommand comm = new SqlCommand(sb.ToString(), conn);
                    if (Name != null)
                    {
                        sb.Append(" and ROLE_NAME like  @Name ");
                        SqlParameter[] paras = new SqlParameter[]
                        {
                            new SqlParameter("@Name",'%'+ Name +'%'),
                        };
                        comm = new SqlCommand(sb.ToString(), conn);
                        comm.Parameters.AddRange(paras);
                    }
                    else
                    {
                        comm = new SqlCommand(sb.ToString(), conn);
                    }
                    return Convert.ToInt32(comm.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion
    }
}
