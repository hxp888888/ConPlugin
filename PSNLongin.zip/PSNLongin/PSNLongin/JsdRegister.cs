﻿using PSNLongin.DAO;
using PSNLongin.DLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class JsdRegister : Form
    {
        public JsdRegister()
        {
            InitializeComponent();
        }
        jsdDLL jsdDlls = new jsdDLL();
        private Dictionary<string, bool> dicBool = new Dictionary<string, bool>();
        public int @roleId;//角色ID
     
        /// <summary>
        /// 加载班次
        /// 赋值ID
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JsdRegister_Load(object sender, EventArgs e)
        {

            ////加载权限数据
            //SqlConnection conn = new SqlConnection(DBHelper.connectionString);
            //string sql = "select * from JurisdictionTable";
            //try
            //{
            //    SqlCommand comm = new SqlCommand(sql, conn);
            //    conn.Open();
            //    SqlDataReader reader = comm.ExecuteReader();
            //    while (reader.Read())
            //    {
            //       cmbJsd.Items.Add(reader["JName"].ToString());
            //    }
            //    reader.Close();
            //    this.cmbJsd.SelectedIndex = 0;
            //}
            //catch (Exception ex)
            //{

            //    throw ex;
            //}

          //int countId=  jsdDlls.countRecordBuss(null);
          //this.txtJsdId.Text = (countId+1).ToString();
            this.BindAllGrant();
         
        }


        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();

            string sdbTeam = this.cmbJsd.Text;
            if (this.txtName.Text.Equals("") )
            {
                MessageBox.Show("请全部信息填写完整！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select isnull(max(role_id),0) as maxid from tb_role", null);
                this.roleId = Convert.ToInt32(dataSet.Tables[0].Rows[0][0].ToString()) + 1;
                string cmdText = "insert into tb_role(role_id, role_name) values( @roleId, @roleName)";
                SqlParameter[] commandParameters = new SqlParameter[]
			{
				new SqlParameter("@roleId", this.roleId),
				new SqlParameter("@roleName", this.txtName.Text)
			};
              int regidsterJ=  DBHelper.ExecuteNonQuery(cmdText, commandParameters);
                if (regidsterJ == 1)
                {
                    MessageBox.Show("新增成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (new PowerMng().ShowDialog() == DialogResult.OK)
                    {
                        //刷新操作 
                        new PowerMng().Refresh();
                    }
                    foreach (TreeNode treeNode in this.tvRight.Nodes)
                    {
                        this.UpdateGrnat(treeNode);
                        this.NodeIsChang(treeNode);
                    }
                    //this.txtJsdId.Text = (Convert.ToInt32(this.txtJsdId.Text.Trim())+1).ToString();
                 
                    this.Close();
                }
                else
                {
                    MessageBox.Show("新增失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } 
               
                //base.Close();
                #region Oldupd
                //  string rName = this.txtName.Text.Trim();//角色名
                //  string jsdName=this.cmbJsd.Text.Trim();
                //  string teamSql = string.Format("select Jid from JurisdictionTable where JName='{0}'", jsdName);//权限
                //  string jsdId = DBHelper.ExecuteScalar(teamSql);//获取权限Id
                //  string sql = string.Format("insert into RoleTable(Rname,JsdId,cTime) values('{0}',{1},'{2}')", rName, jsdId, Convert.ToDateTime(DateTime.Now).ToString("yyyy-MM-dd HH:mm:ss"));
                ////  string sqlS = string.Format("insert into SbdTeamTable({0},'{1}'1,) values()", Convert.ToInt32(jsdDlls.countRecordBussTeam(null)), this);
                //  int regidsterJ = DBHelper.ExecuteNonQuery(sql);
                //  if (regidsterJ == 1)
                //  {
                //      MessageBox.Show("新增成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //      if (new PowerMng().ShowDialog() == DialogResult.OK)
                //      {
                //          //刷新操作 
                //          new PowerMng().Refresh();
                //      }
                //      //this.txtJsdId.Text = (Convert.ToInt32(this.txtJsdId.Text.Trim())+1).ToString();
                //      this.Close();
                //  }
                //  else
                //  {
                //      MessageBox.Show("新增失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //  } 
                #endregion

            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BindAllGrant()
        {
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_menu where parent_id = '0' ", null);
            this.tvRight.Nodes.Clear();
            this.dicBool.Clear();
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                TreeNode treeNode = new TreeNode(dataRow["name"].ToString());
                treeNode.Tag = dataRow["menu_id"];
                this.tvRight.Nodes.Add(treeNode);
                this.dicBool.Add(treeNode.Tag.ToString(), false);
                this.AddChildNode(treeNode);
            }
            this.tvRight.ExpandAll();
            this.tvRight.CheckBoxes = true;
        }

        private void AddChildNode(TreeNode pNode)
        {
            string str = pNode.Tag.ToString();
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_menu where parent_id = " + str, null);
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                TreeNode treeNode = new TreeNode(dataRow["name"].ToString());
                treeNode.Tag = dataRow["menu_id"];
                pNode.Nodes.Add(treeNode);
                this.dicBool.Add(treeNode.Tag.ToString(), false);
                this.AddChildNode(treeNode);
            }
        }

        /// <summary>
        /// 选中后
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvRight_AfterCheck(object sender, TreeViewEventArgs e)
        {
            TreeNode node = e.Node;
            this.dicBool[node.Tag.ToString()] = !this.dicBool[node.Tag.ToString()];
            if (node.Checked)
            {
                if (node.Parent != null && !node.Parent.Checked)
                {
                    node.Parent.Checked = true;
                    return;
                }
            }
            else if (!e.Node.Checked)
            {
                foreach (TreeNode treeNode in node.Nodes)
                {
                    if (treeNode.Checked)
                    {
                        treeNode.Checked = false;
                    }
                }
            }
        }

        private void UpdateGrnat(TreeNode node)
        {
            if (this.dicBool[node.Tag.ToString()])
            {
                if (node.Checked)
                {
                    DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select isnull(max(id),0) as maxid from tb_role_menu", null);
                    int num = Convert.ToInt32(dataSet.Tables[0].Rows[0][0].ToString()) + 1;
                    string cmdText = "insert into tb_role_menu(id, role_id, menu_id) values( @Id, @roleId, @menuId)";
                    SqlParameter[] commandParameters = new SqlParameter[]
					{
						new SqlParameter("@Id", num),
						new SqlParameter("@roleId", this.roleId),
						new SqlParameter("@menuId", node.Tag.ToString())
					};
                    DBHelper.ExecuteNonQuery( cmdText, commandParameters);
                    return;
                }
                MessageBox.Show("要删除： " + node.Tag.ToString());
            }
        }

        private void NodeIsChang(TreeNode pNode)
        {
            foreach (TreeNode treeNode in pNode.Nodes)
            {
                this.UpdateGrnat(treeNode);
                this.NodeIsChang(treeNode);
            }
        }
    }
}
