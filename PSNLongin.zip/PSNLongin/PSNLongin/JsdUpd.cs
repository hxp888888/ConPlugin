﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class JsdUpd : Form
    {
        public JsdUpd()
        {
            InitializeComponent();
        }

        JurisdictionDAO jsdDao = new JurisdictionDAO();

        /// <summary>
        /// 加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JsdUpd_Load(object sender, EventArgs e)
        {
            Jurisdiction jsdDate = jsdDao.Queryuser(PowerMng.roleVaule);
            this.txtJsdId.Text = PowerMng.roleVaule;
            this.txtName.Text = jsdDate.roleName;

        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 角色修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpd_Click(object sender, EventArgs e)
        {
            //获取用户数据绑定到 "TextBox" 中
            Jurisdiction user = jsdDao.Queryuser(PowerMng.roleVaule);

            //用户对象
            Jurisdiction userTable = new Jurisdiction();

            //用户集合判断用户账号是否相同
            List<Jurisdiction> userList = jsdDao.QueryuserList(PowerMng.roleVaule);


            //是否有重复的账号
            Boolean userAccount = false;
            userTable.roleId = Convert.ToInt32(this.txtJsdId.Text.Trim());
            userTable.roleName = this.txtName.Text.Trim();
           

            if (txtName.Text == "" )
            {
                MessageBox.Show("请全部信息填写完整！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (this.txtName.Text.Equals(PowerMng.RName))
                {
                    int Count = jsdDao.UpdateUserTable(userTable);

                    if (Count == 1)
                    {
                        MessageBox.Show("修改成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (new PowerMng().ShowDialog() == DialogResult.OK)
                        {
                            //刷新操作 
                            new PowerMng().Refresh();
                        }
                        this.Close();

                    }
                    else
                    {
                        MessageBox.Show("修改失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    foreach (var item in userList)
                    {
                        userAccount = false;
                        if (item.roleName.Equals(this.txtName.Text))
                        {
                            userAccount = true;
                            break;
                        }
                    }
                    if (userAccount)
                    {
                        MessageBox.Show("该角色已经存在请重新输入！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                    int Count = jsdDao.UpdateUserTable(userTable);

                    if (Count == 1)
                    {
                        MessageBox.Show("修改成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (new PowerMng().ShowDialog() == DialogResult.OK)
                        {
                            //刷新操作 
                            new PowerMng().Refresh();
                        }
                        this.Close();

                    }
                    else
                    {
                        MessageBox.Show("修改失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    }
                }
            }
        }
    }
}
