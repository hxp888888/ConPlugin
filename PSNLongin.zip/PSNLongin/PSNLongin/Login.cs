﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Login_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCanel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //账号
        public static string account_;
        //账号
        public static string account_Name;
        //public static bool yesNo=false;
        /// <summary>
        /// 调用登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, EventArgs e)
        {


            string user = txtLogin.Text;//用户名
            string pwd = txtPassword.Text;//密码
            string login = LoginDAO.Sign(user, pwd);
            string loginName = LoginDAO.getName(user, pwd);
            TimeSpan tsp = new TimeSpan();
            if (login != null && !login.Equals(""))
            {
                string lastDateS = UserDAO.GetLoginTime(Convert.ToInt32(login));
                DateTime lastDate = Convert.ToDateTime(lastDateS);
                DateTime newDate = DateTime.Now;
                tsp = newDate - lastDate;
            }
            if (user == "" || pwd == "")
            {
                MessageBox.Show("请输入用户或密码！！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (tsp.Days >= 30)//从注册时间算起超30天就要重置密码
            {

                losePwd frmpwd = new losePwd();
                account_ = login;
                frmpwd.ShowDialog();
            }
            else
            {
                if (login != null && !login.Equals(""))
                {
                   // UserDAO.UpdLoginDate(Convert.ToInt32(login));
                    Login lo = new Login();
                    CompsQuery fr = new CompsQuery();
                     ShowData sd = new ShowData();
                    account_ = login;
                     //yesNo = true;
                    account_Name = loginName;
                    sd.ShowDialog();
                    fr.ShowDialog(this);
                    lo.Close();
                    
                }
                else
                {
                    MessageBox.Show("用户名或密码错误，请重新输入！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

    }
}
