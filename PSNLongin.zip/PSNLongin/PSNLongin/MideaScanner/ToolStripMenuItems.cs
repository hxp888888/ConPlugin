﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin.MideaScanner
{
   public class ToolStripMenuItems : ToolStripMenuItem
    {

        public string OpenFromName;

        public string openType;

        public ToolStripMenuItems()
        {
        }

        public ToolStripMenuItems(object name, object tag, object openFromName, object openType)
        {
            this.Text = name.ToString();
            base.Tag = tag;
            this.OpenFromName = openFromName.ToString();
            this.openType = openType.ToString();
        }
    }
}
