﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.MideaScanner
{
    public class publicVar
    {
        public static string PortName = "";

        public static string BaudRate = "115200";

        public static string currentUser = "";

        public static string Conn = "server=158.118.76.230;database=panasonic; uid=mro ;pwd=Mr2018 ;Max Pool Size =512; Min Pool Size=0; Connection Lifetime = 300;packet size=1000;";
        //public static readonly string Conn = "server=.;database=panasonic; uid=sa ;pwd=sa@2019 ;Max Pool Size =512; Min Pool Size=0; Connection Lifetime = 300;packet size=1000;";

    }
}
