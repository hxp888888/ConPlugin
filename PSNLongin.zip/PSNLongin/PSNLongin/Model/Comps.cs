﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.Model
{
   public class Comps
    {
        //用户ID
        public int userId { get; set; }

        //用户账号
        public string code { get; set; }

        //密码
        public string password { get; set; }

        //用户名
        public string name { get; set; }

        //性别
        public string sex { get; set; }

        //用户创建日期
        public DateTime createTime { get; set; }
    }
}
