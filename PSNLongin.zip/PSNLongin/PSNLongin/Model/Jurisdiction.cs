﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DAO
{
   public class Jurisdiction
    {
       //角色ID
       public int roleId { get; set; }

       //角色
       public string roleName { get; set; }

       //权限
       public string JsdName { get; set; }

    }
}
