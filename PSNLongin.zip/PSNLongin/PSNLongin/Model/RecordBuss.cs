﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DLL
{
    /// <summary>
    /// 需要显示属性
    /// </summary>
   public class RecordBuss
    {
       //用户ID
      public int userId { get; set; }
       //用户账号
      public string code { get; set; }
       //密码
      public string password { get; set; }

       //用户名
      public string name { get; set; }
       //所属班组
      public string sName { get; set; }
       //班组Id
      public int sId { get; set; }
       //联系人
      public string contacts { get; set; }
       //联系电话
      public string phone { get; set; }

       //角色ID
      public int RId { get; set; }

       //角色名
      public string Rname { get; set; }

       //权限
      public string Jname { get; set; }

      //权限ID
      public int JId{ get; set; }

       //行
      public int rownumber { get; set; }

       //性别
      public string sex { get; set; }

       //用户创建日期
      public DateTime createTime { get; set; }
    }
}
