﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PSNLongin.DAO
{
    /// <summary>
    /// 用户表
    /// </summary>
   public class UserTable
    {
       //用户ID
     public int userId { get; set; }

       //用户Code
      public string code { get; set; }
       //密码
      public string pwd { get; set; }
       //用户名
      public string name { get; set; }
       //性别
      public string sex { get; set; }
       //联系人
      public string contacts { get; set; }
       //联系电话
      public string phone { get; set; }
       //班次
      public int sbdTeam { get; set; }

       //创建日期
      public DateTime createTime { get; set; }

     

    }
}
