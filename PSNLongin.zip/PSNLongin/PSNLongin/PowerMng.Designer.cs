﻿namespace PSNLongin
{
    partial class PowerMng
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvJsdList = new System.Windows.Forms.DataGridView();
            this.jsdId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbToF = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contacts = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctmeunDel = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.jsdUpd = new System.Windows.Forms.ToolStripTextBox();
            this.jsdDel = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSelectJSD = new System.Windows.Forms.Button();
            this.lblNextpage = new System.Windows.Forms.LinkLabel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPreviouspage = new System.Windows.Forms.LinkLabel();
            this.lblPageCount = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPage = new System.Windows.Forms.Label();
            this.lblMosaic = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tlstrpResgin = new System.Windows.Forms.ToolStripMenuItem();
            this.tlstripDel = new System.Windows.Forms.ToolStripMenuItem();
            this.tstrpExit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tvRight = new System.Windows.Forms.TreeView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJsdList)).BeginInit();
            this.ctmeunDel.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvJsdList
            // 
            this.dgvJsdList.AllowUserToAddRows = false;
            this.dgvJsdList.AllowUserToDeleteRows = false;
            this.dgvJsdList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvJsdList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvJsdList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJsdList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.jsdId,
            this.Name,
            this.cmbToF,
            this.SName,
            this.contacts,
            this.phone});
            this.dgvJsdList.ContextMenuStrip = this.ctmeunDel;
            this.dgvJsdList.Location = new System.Drawing.Point(15, 87);
            this.dgvJsdList.Name = "dgvJsdList";
            this.dgvJsdList.RowTemplate.Height = 23;
            this.dgvJsdList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvJsdList.Size = new System.Drawing.Size(382, 234);
            this.dgvJsdList.TabIndex = 55;
            this.dgvJsdList.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvJsdList_CellMouseClick);
            // 
            // jsdId
            // 
            this.jsdId.DataPropertyName = "Rid";
            this.jsdId.HeaderText = "权限Id";
            this.jsdId.Name = "jsdId";
            // 
            // Name
            // 
            this.Name.DataPropertyName = "Rname";
            this.Name.HeaderText = "角色";
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            // 
            // cmbToF
            // 
            this.cmbToF.HeaderText = " ";
            this.cmbToF.Name = "cmbToF";
            this.cmbToF.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cmbToF.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.cmbToF.Visible = false;
            // 
            // SName
            // 
            this.SName.DataPropertyName = "Jname";
            this.SName.HeaderText = "权限";
            this.SName.Name = "SName";
            this.SName.ReadOnly = true;
            this.SName.Visible = false;
            // 
            // contacts
            // 
            this.contacts.DataPropertyName = "Contacts";
            this.contacts.HeaderText = "联系人";
            this.contacts.Name = "contacts";
            this.contacts.ReadOnly = true;
            this.contacts.Visible = false;
            // 
            // phone
            // 
            this.phone.DataPropertyName = "Phone";
            this.phone.HeaderText = "联系电话";
            this.phone.Name = "phone";
            this.phone.ReadOnly = true;
            this.phone.Visible = false;
            // 
            // ctmeunDel
            // 
            this.ctmeunDel.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jsdUpd,
            this.jsdDel});
            this.ctmeunDel.Name = "ctmeunDel";
            this.ctmeunDel.Size = new System.Drawing.Size(161, 51);
            this.ctmeunDel.Text = "删除";
            // 
            // jsdUpd
            // 
            this.jsdUpd.Name = "jsdUpd";
            this.jsdUpd.Size = new System.Drawing.Size(100, 23);
            this.jsdUpd.Text = "修改";
            this.jsdUpd.Click += new System.EventHandler(this.jsdUpd_Click);
            // 
            // jsdDel
            // 
            this.jsdDel.Name = "jsdDel";
            this.jsdDel.Size = new System.Drawing.Size(160, 22);
            this.jsdDel.Text = "删除";
            this.jsdDel.Click += new System.EventHandler(this.jsdDel_Click);
            // 
            // btnSelectJSD
            // 
            this.btnSelectJSD.Location = new System.Drawing.Point(234, 38);
            this.btnSelectJSD.Name = "btnSelectJSD";
            this.btnSelectJSD.Size = new System.Drawing.Size(75, 23);
            this.btnSelectJSD.TabIndex = 58;
            this.btnSelectJSD.Text = "查询";
            this.btnSelectJSD.UseVisualStyleBackColor = true;
            this.btnSelectJSD.Click += new System.EventHandler(this.btnSelectJSD_Click);
            // 
            // lblNextpage
            // 
            this.lblNextpage.AutoSize = true;
            this.lblNextpage.Location = new System.Drawing.Point(771, 334);
            this.lblNextpage.Name = "lblNextpage";
            this.lblNextpage.Size = new System.Drawing.Size(41, 12);
            this.lblNextpage.TabIndex = 62;
            this.lblNextpage.TabStop = true;
            this.lblNextpage.Text = "下一页";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(66, 40);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(132, 21);
            this.txtName.TabIndex = 57;
            // 
            // lblPreviouspage
            // 
            this.lblPreviouspage.AutoSize = true;
            this.lblPreviouspage.Location = new System.Drawing.Point(692, 334);
            this.lblPreviouspage.Name = "lblPreviouspage";
            this.lblPreviouspage.Size = new System.Drawing.Size(41, 12);
            this.lblPreviouspage.TabIndex = 63;
            this.lblPreviouspage.TabStop = true;
            this.lblPreviouspage.Text = "上一页";
            this.lblPreviouspage.Visible = false;
            // 
            // lblPageCount
            // 
            this.lblPageCount.Location = new System.Drawing.Point(104, 335);
            this.lblPageCount.Name = "lblPageCount";
            this.lblPageCount.Size = new System.Drawing.Size(19, 13);
            this.lblPageCount.TabIndex = 61;
            this.lblPageCount.Text = "5";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(13, 43);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 12);
            this.lblName.TabIndex = 56;
            this.lblName.Text = "角色名:";
            // 
            // lblPage
            // 
            this.lblPage.ForeColor = System.Drawing.Color.Black;
            this.lblPage.Location = new System.Drawing.Point(52, 334);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(18, 13);
            this.lblPage.TabIndex = 60;
            this.lblPage.Text = "1";
            // 
            // lblMosaic
            // 
            this.lblMosaic.Location = new System.Drawing.Point(13, 335);
            this.lblMosaic.Name = "lblMosaic";
            this.lblMosaic.Size = new System.Drawing.Size(177, 23);
            this.lblMosaic.TabIndex = 59;
            this.lblMosaic.Text = "当前第 1 页  共 5 页 100 条数据";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlstrpResgin,
            this.tlstripDel,
            this.tstrpExit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(840, 25);
            this.menuStrip1.TabIndex = 64;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tlstrpResgin
            // 
            this.tlstrpResgin.Name = "tlstrpResgin";
            this.tlstrpResgin.Size = new System.Drawing.Size(68, 21);
            this.tlstrpResgin.Text = "新增角色";
            this.tlstrpResgin.Click += new System.EventHandler(this.tlstrpResgin_Click);
            // 
            // tlstripDel
            // 
            this.tlstripDel.Name = "tlstripDel";
            this.tlstripDel.Size = new System.Drawing.Size(44, 21);
            this.tlstripDel.Text = "删除";
            this.tlstripDel.Visible = false;
            // 
            // tstrpExit
            // 
            this.tstrpExit.Name = "tstrpExit";
            this.tstrpExit.Size = new System.Drawing.Size(44, 21);
            this.tstrpExit.Text = "退出";
            this.tstrpExit.Click += new System.EventHandler(this.tstrpExit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tvRight);
            this.panel1.Location = new System.Drawing.Point(403, 87);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(417, 234);
            this.panel1.TabIndex = 65;
            // 
            // tvRight
            // 
            this.tvRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvRight.Location = new System.Drawing.Point(0, 0);
            this.tvRight.Name = "tvRight";
            this.tvRight.Size = new System.Drawing.Size(417, 234);
            this.tvRight.TabIndex = 0;
            // 
            // PowerMng
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 354);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvJsdList);
            this.Controls.Add(this.btnSelectJSD);
            this.Controls.Add(this.lblNextpage);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblPreviouspage);
            this.Controls.Add(this.lblPageCount);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblPage);
            this.Controls.Add(this.lblMosaic);
            this.Controls.Add(this.menuStrip1);
            this.MaximizeBox = false;
            //this.Name = "PowerMng";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "权限管理";
            this.Load += new System.EventHandler(this.PowerMng_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvJsdList)).EndInit();
            this.ctmeunDel.ResumeLayout(false);
            this.ctmeunDel.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvJsdList;
        private System.Windows.Forms.ContextMenuStrip ctmeunDel;
        private System.Windows.Forms.ToolStripTextBox jsdUpd;
        private System.Windows.Forms.ToolStripMenuItem jsdDel;
        private System.Windows.Forms.Button btnSelectJSD;
        private System.Windows.Forms.LinkLabel lblNextpage;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.LinkLabel lblPreviouspage;
        private System.Windows.Forms.Label lblPageCount;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label lblMosaic;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tlstrpResgin;
        private System.Windows.Forms.ToolStripMenuItem tlstripDel;
        private System.Windows.Forms.ToolStripMenuItem tstrpExit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TreeView tvRight;
        private System.Windows.Forms.DataGridViewTextBoxColumn jsdId;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cmbToF;
        private System.Windows.Forms.DataGridViewTextBoxColumn SName;
        private System.Windows.Forms.DataGridViewTextBoxColumn contacts;
        private System.Windows.Forms.DataGridViewTextBoxColumn phone;
    }
}