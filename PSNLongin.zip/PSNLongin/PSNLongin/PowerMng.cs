﻿using PSNLongin.DAO;
using PSNLongin.DLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class PowerMng : Form
    {
        public PowerMng()
        {
            InitializeComponent();
        }
        private DataTable dtSelectRole;

        private Dictionary<string, bool> dicBool = new Dictionary<string, bool>();

        private string selectRoleId = "";

        private string roleName = "";

        /// <summary>
        /// 显示页
        /// </summary>
        int u = 1;

        /// <summary>
        /// 是否是查询大于0为查询
        /// </summary>
        int PageNumber;

        /// <summary>
        /// 连接记录类
        /// </summary>
        jsdDLL record = new jsdDLL();

        /// <summary>
        /// 角色Id
        /// </summary>
        public static string roleVaule;
        public static string RName;

        /// <summary>
        /// 加载查询所有权限数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PowerMng_Load(object sender, EventArgs e)
        {
            Displaydevice(0, null);
            if (this.dgvJsdList.Rows.Count > 1)
            {
                DataGridViewRow dataGridViewRow = this.dgvJsdList.Rows[0];
                this.selectRoleId = dataGridViewRow.Cells[0].Value.ToString();
                if (this.selectRoleId == "")
                {
                    return;
                }
                this.setDefalut();
            }
            
        }

        /// <summary>
        /// 设置默认值
        /// </summary>
        private void setDefalut()
        {
            this.dtSelectRole = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_role_menu where role_id = " + this.selectRoleId, null).Tables[0];
            this.BindAllGrant();
            foreach (DataRow dataRow in this.dtSelectRole.Rows)
            {
                foreach (TreeNode treeNode in this.tvRight.Nodes)
                {
                    if (treeNode.Tag.ToString() == dataRow["menu_id"].ToString())
                    {
                        treeNode.Checked = true;
                        this.SlectChildNodes(treeNode);
                        this.dicBool[treeNode.Tag.ToString()] = false;
                    }
                }
            }
        }

        /// <summary>
        /// 选择的树状
        /// </summary>
        /// <param name="pNode"></param>
        private void SlectChildNodes(TreeNode pNode)
        {
            foreach (DataRow dataRow in this.dtSelectRole.Rows)
            {
                foreach (TreeNode treeNode in pNode.Nodes)
                {
                    if (treeNode.Tag.ToString() == dataRow["menu_id"].ToString())
                    {
                        treeNode.Checked = true;
                        this.SlectChildNodes(treeNode);
                    }
                }
            }
        }

        /// <summary>
        /// 加载根树状
        /// </summary>
        private void BindAllGrant()
        {
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_menu where parent_id = '0' ", null);
            this.tvRight.Nodes.Clear();
            this.dicBool.Clear();
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                TreeNode treeNode = new TreeNode(dataRow["name"].ToString());
                treeNode.Tag = dataRow["menu_id"];
                this.tvRight.Nodes.Add(treeNode);
                this.AddChildNode(treeNode);
            }
            this.tvRight.ExpandAll();
            this.tvRight.CheckBoxes = true;
        }

        /// <summary>
        /// 加载子树状
        /// </summary>
        /// <param name="pNode"></param>
        private void AddChildNode(TreeNode pNode)
        {
            string str = pNode.Tag.ToString();
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_menu where parent_id = " + str, null);
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                TreeNode treeNode = new TreeNode(dataRow["name"].ToString());
                treeNode.Tag = dataRow["menu_id"];
                pNode.Nodes.Add(treeNode);
                this.AddChildNode(treeNode);
            }
        }

        #region 加载角色所有数据
        /// <summary>
        /// 加载角色所有数据
        /// </summary>
        public void Displaydevice(int pageSize, string Name)
        {
            try
            {
                //是否自动创建 "DataGridView" 列
                this.dgvJsdList.AutoGenerateColumns = false;
                //从数据库得到的数据绑定到 "DataGridView" 上
                this.dgvJsdList.DataSource = record.getRecordBuss(Name);

                if (PageNumber > 0)
                {
                    //数据库查询多少条数据
                    double CountList = record.getRecordBussCountList(Name);
                    double P = CountList / 8;
                    int Page = Convert.ToInt32(CountList / 8);
                    if (P > Page)
                    {
                        this.lblPageCount.Text = (Page + 1).ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                    else
                    {
                        this.lblPageCount.Text = Page.ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + CountList.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }

                }
                else
                {
                    //数据库查询多少条数据
                    double Count = record.countRecordBuss(Login.account_);
                    double P = Count / 8;
                    int Page = Convert.ToInt32(Count / 8);
                    if (P > Page)
                    {
                        this.lblPageCount.Text = (Page + 1).ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + Count.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + " 页 " + Count.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                    else
                    {
                        this.lblPageCount.Text = Page.ToString();
                        if (u == 1)
                        {
                            this.lblPage.Text = "1";
                            this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + "  页 " + Count.ToString() + " 条数据";
                        }
                        this.lblPage.Text = u.ToString();
                        this.lblMosaic.Text = "当前第 " + this.lblPage.Text + " 页  共 " + this.lblPageCount.Text + "  页 " + Count.ToString() + " 条数据";

                        if (this.lblPage.Text.Equals(this.lblPageCount.Text))
                        {
                            this.lblNextpage.Visible = false;
                        }
                        else
                        {
                            this.lblNextpage.Visible = true;
                        }
                        if (this.lblPage.Text == "1")
                        {
                            this.lblPreviouspage.Visible = false;
                        }
                        if (this.lblPageCount.Text == "0")
                        {
                            this.lblPreviouspage.Visible = false;
                            this.lblNextpage.Visible = false;
                        }
                    }
                }



            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tstrpExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 模糊查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSelectJSD_Click(object sender, EventArgs e)
        {
            PageNumber = 1;

            u = 1;
            //设备名称
            string name = this.txtName.Text.Trim();
            this.lblNextpage.Visible = true;
            this.lblPreviouspage.Visible = false;

            //加载所有数据
            Displaydevice(0, name);
        }

        /// <summary>
        /// 新增权限
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tlstrpResgin_Click(object sender, EventArgs e)
        {
            JsdRegister jrs = new JsdRegister();
            this.DialogResult = DialogResult.OK;
            jrs.ShowDialog(this);
        }



        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void jsdDel_Click(object sender, EventArgs e)
        {
            DialogResult DLResult = MessageBox.Show("确定删除吗？", "温馨提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (DLResult == DialogResult.OK)
            {
                string cmdText = "delete from tb_role_menu where role_id = " +Convert.ToInt32( dgvJsdList.SelectedRows[0].Cells["jsdId"].Value);
                int delCount=  DBHelper.ExecuteNonQuery(cmdText);
                string cmdText2 = "delete from tb_role where role_id = " + Convert.ToInt32(dgvJsdList.SelectedRows[0].Cells["jsdId"].Value);
               int delCount1= DBHelper.ExecuteNonQuery(cmdText2);
               if (delCount1==1)
                {
                    //删除成功
                    MessageBox.Show("删除成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.dgvJsdList.DataSource = record.getRecordBuss(null);
                    //new PowerMng().Refresh();
                    //Displaydevice(0, null);
                }
                else
                {
                    //删除失败
                    MessageBox.Show("删除失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } 

                #region OLDdelete
                ////删除
                //string id = dgvJsdList.SelectedRows[0].Cells["jsdId"].Value.ToString();
                //int delCount = JurisdictionDAO.DeleteUser(id);
                //if (delCount == 1)
                //{
                //    //删除成功
                //    MessageBox.Show("删除成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    this.dgvJsdList.DataSource = record.getRecordBuss(null);
                //    //new PowerMng().Refresh();
                //    Displaydevice(0, null);
                //}
                //else
                //{
                //    //删除失败
                //    MessageBox.Show("删除失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //} 
                #endregion
                //this.datarefresh();
            }
            else
            {
                MessageBox.Show("用户取消操作！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        /// <summary>
        /// 刷新
        /// </summary>
        //public void datarefresh()
        //{
        //    this.dgvJsdList.DataSource = DBHelper.GetDataSet2(DBHelper.connectionString, "select role_id as 编号,role_name as 角色名称 from tb_role", null).Tables[0].DefaultView;
        //    this.setDefalut();
        //}

        /// <summary>
        /// 跳转修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void jsdUpd_Click(object sender, EventArgs e)
        {
            JsdUpd rs = new JsdUpd();
            this.DialogResult = DialogResult.OK;
            roleVaule = dgvJsdList.SelectedRows[0].Cells["jsdId"].Value.ToString();
            RName = dgvJsdList.SelectedRows[0].Cells["Name"].Value.ToString();
            rs.ShowDialog(this);
        }

        private void dgvJsdList_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            if (this.dgvJsdList.CurrentRow == null)
            {
                return;
            }
            DataGridViewRow currentRow = this.dgvJsdList.CurrentRow;
            this.selectRoleId =dgvJsdList.SelectedRows[0].Cells["jsdId"].Value.ToString();
            this.roleName = currentRow.Cells[1].Value.ToString();
            if (this.selectRoleId == "")
            {
                return;
            }
            this.setDefalut();
        }
    }
}
