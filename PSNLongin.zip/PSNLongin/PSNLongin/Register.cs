﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 加载事件
        /// 显示所有班组的数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Register_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(DBHelper.connectionString);
            SqlConnection conns = new SqlConnection(DBHelper.connectionString);

            this.cmbSex.SelectedIndex = 0;
            #region 加载角色数据


            string Rsql = "select * from tb_role";
            try
            {
                SqlCommand comm = new SqlCommand(Rsql, conn);
                conn.Open();
                SqlDataReader reader = comm.ExecuteReader();
                while (reader.Read())
                {
                    cmbRole.Items.Add(reader["ROLE_NAME"].ToString());
                }
                reader.Close();
                this.cmbRole.SelectedIndex = 0;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            #endregion

            #region 加载班组数据
            //加载班组数据

            //string Ssql = "select * from SteamTable";
            //try
            //{
            //    SqlCommand comms = new SqlCommand(Ssql, conn);
            //    conns.Open();
            //    SqlDataReader readers = comms.ExecuteReader();
            //    while (readers.Read())
            //    {
            //        cmbSbdTeam.Items.Add(readers["SName"].ToString());
            //    }
            //    readers.Close();
            //    this.cmbSbdTeam.SelectedIndex = 0;
            //}
            //catch (Exception ex)
            //{

            //    throw ex;
            //} 
            #endregion
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();

            string sdbTeam = this.cmbSbdTeam.Text;
            string roleN = this.cmbRole.Text;
            string password="";
            if (this.txtUseerId.Text.Equals("") || this.txtUseerId.Text.Equals("") || this.txtUseerId.Text.Equals("") || this.txtUseerId.Text.Equals("") || this.txtUseerId.Text.Equals(""))
            {
                MessageBox.Show("请全部信息填写完整！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                string userId = this.txtUseerId.Text;//账号
                string name = this.txtName.Text;//用户名
                string retxtpwd = @"^(\w).{5,100}$";
                if (!Regex.IsMatch(this.txtPwd.Text.Trim(), retxtpwd))
                {
                    //验证不通过
                    MessageBox.Show("密码必须至少包含6位字符,其中字符必须包含数字和大小写字母");
                    return;
                }
                else
                {
                     password = this.txtPwd.Text;//密码
                }


                //性别
                string sex = this.cmbSex.Text.Trim();

                // string teamSql = string.Format("select Sid from SteamTable where SName='{0}'", sdbTeam);//班次
                // string sdTeamId = DBHelper.ExecuteScalar(teamSql);//获取班次Id

                string roleSql = string.Format("select ROLE_ID from tb_role where ROLE_NAME='{0}'", roleN);//角色
                string roleId = DBHelper.ExecuteScalar(roleSql);//获取角色Id
                // int sdbTeamId=0;
                string contacts = this.txtConnect.Text;//联系人
                string phone = this.txtPhone.Text;//电话
                string sql = string.Format(@"insert into tb_user(user_no,user_name,password,role_id,sex,phone,phoneMaster,Logintim) values
                    ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}')", userId, name, password, roleId, sex, phone, contacts, Convert.ToDateTime(DateTime.Now).ToString("yyyy-MM-dd"));
                int regidsterJ = DBHelper.ExecuteNonQuery(sql);
                if (regidsterJ == 1)
                {
                    MessageBox.Show("注册成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (new Connect().ShowDialog() == DialogResult.OK)
                    {
                        //刷新操作 
                        new Connect().Refresh();
                    }
                    //new Connect().Refresh();
                    //new Connect().Displaydevice(0, null);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("注册失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }

        }




    }
}
