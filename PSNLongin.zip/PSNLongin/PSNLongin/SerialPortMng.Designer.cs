﻿namespace PSNLongin
{
    partial class SerialPortMng
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbPortName = new System.Windows.Forms.ComboBox();
            this.cmbBaudRate = new System.Windows.Forms.ComboBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.grpReceive = new System.Windows.Forms.GroupBox();
            this.lblAccpect = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ckbLines = new System.Windows.Forms.CheckBox();
            this.txtView = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ckbLine = new System.Windows.Forms.CheckBox();
            this.ckbHex = new System.Windows.Forms.CheckBox();
            this.lblSend = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.grpReceive.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "端口名称";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "波特率";
            // 
            // cmbPortName
            // 
            this.cmbPortName.FormattingEnabled = true;
            this.cmbPortName.Location = new System.Drawing.Point(93, 21);
            this.cmbPortName.Name = "cmbPortName";
            this.cmbPortName.Size = new System.Drawing.Size(121, 20);
            this.cmbPortName.TabIndex = 2;
            this.cmbPortName.SelectedIndexChanged += new System.EventHandler(this.cmbPortName_SelectedIndexChanged);
            // 
            // cmbBaudRate
            // 
            this.cmbBaudRate.FormattingEnabled = true;
            this.cmbBaudRate.Location = new System.Drawing.Point(311, 21);
            this.cmbBaudRate.Name = "cmbBaudRate";
            this.cmbBaudRate.Size = new System.Drawing.Size(121, 20);
            this.cmbBaudRate.TabIndex = 3;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(484, 19);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 4;
            this.btnOpen.Text = "打开";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(613, 19);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "重置";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // grpReceive
            // 
            this.grpReceive.Controls.Add(this.lblAccpect);
            this.grpReceive.Controls.Add(this.label3);
            this.grpReceive.Controls.Add(this.ckbLines);
            this.grpReceive.Controls.Add(this.txtView);
            this.grpReceive.Location = new System.Drawing.Point(12, 47);
            this.grpReceive.Name = "grpReceive";
            this.grpReceive.Size = new System.Drawing.Size(740, 215);
            this.grpReceive.TabIndex = 6;
            this.grpReceive.TabStop = false;
            this.grpReceive.Text = "数据接收";
            // 
            // lblAccpect
            // 
            this.lblAccpect.AutoSize = true;
            this.lblAccpect.Location = new System.Drawing.Point(635, 1);
            this.lblAccpect.Name = "lblAccpect";
            this.lblAccpect.Size = new System.Drawing.Size(11, 12);
            this.lblAccpect.TabIndex = 3;
            this.lblAccpect.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(599, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "接收:";
            // 
            // ckbLines
            // 
            this.ckbLines.AutoSize = true;
            this.ckbLines.Location = new System.Drawing.Point(299, 0);
            this.ckbLines.Name = "ckbLines";
            this.ckbLines.Size = new System.Drawing.Size(72, 16);
            this.ckbLines.TabIndex = 1;
            this.ckbLines.Text = "自动换行";
            this.ckbLines.UseVisualStyleBackColor = true;
            // 
            // txtView
            // 
            this.txtView.Location = new System.Drawing.Point(6, 20);
            this.txtView.Multiline = true;
            this.txtView.Name = "txtView";
            this.txtView.Size = new System.Drawing.Size(728, 189);
            this.txtView.TabIndex = 0;
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.sp_DataReceived);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ckbLine);
            this.groupBox1.Controls.Add(this.ckbHex);
            this.groupBox1.Controls.Add(this.lblSend);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnClose);
            this.groupBox1.Controls.Add(this.btnSend);
            this.groupBox1.Controls.Add(this.txtCode);
            this.groupBox1.Location = new System.Drawing.Point(15, 268);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(734, 77);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "数据发送";
            // 
            // ckbLine
            // 
            this.ckbLine.AutoSize = true;
            this.ckbLine.Location = new System.Drawing.Point(115, 0);
            this.ckbLine.Name = "ckbLine";
            this.ckbLine.Size = new System.Drawing.Size(72, 16);
            this.ckbLine.TabIndex = 10;
            this.ckbLine.Text = "New line";
            this.ckbLine.UseVisualStyleBackColor = true;
            // 
            // ckbHex
            // 
            this.ckbHex.AutoSize = true;
            this.ckbHex.Location = new System.Drawing.Point(67, 0);
            this.ckbHex.Name = "ckbHex";
            this.ckbHex.Size = new System.Drawing.Size(42, 16);
            this.ckbHex.TabIndex = 9;
            this.ckbHex.Text = "Hex";
            this.ckbHex.UseVisualStyleBackColor = true;
            // 
            // lblSend
            // 
            this.lblSend.AutoSize = true;
            this.lblSend.Location = new System.Drawing.Point(632, 0);
            this.lblSend.Name = "lblSend";
            this.lblSend.Size = new System.Drawing.Size(11, 12);
            this.lblSend.TabIndex = 8;
            this.lblSend.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(596, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "发送:";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(653, 35);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "退出";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(569, 35);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 5;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(18, 37);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(526, 21);
            this.txtCode.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SerialPortMng
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 356);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpReceive);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.cmbBaudRate);
            this.Controls.Add(this.cmbPortName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "SerialPortMng";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "串口测试";
            this.Load += new System.EventHandler(this.SerialPortMng_Load);
            this.grpReceive.ResumeLayout(false);
            this.grpReceive.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbPortName;
        private System.Windows.Forms.ComboBox cmbBaudRate;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox grpReceive;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtView;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.CheckBox ckbLines;
        private System.Windows.Forms.Label lblAccpect;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSend;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox ckbLine;
        private System.Windows.Forms.CheckBox ckbHex;
        private System.Windows.Forms.Timer timer1;
    }
}