﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThoughtWorks.QRCode.Codec;
using ThoughtWorks.QRCode.Codec.Data;

namespace PSNLongin
{
    public partial class SerialPortMng : Form
    {
        public SerialPortMng()
        {
            InitializeComponent();
        }
       public static SerialPort sp = new SerialPort();

        delegate void UpdateTextEventHandler(string text);  //委托，此为重点.
        UpdateTextEventHandler updateText;  //事件
        private long received_count;//接收bit位
        private long send_count;//发送bit位
       
       
        string[] portNames = SerialPort.GetPortNames();
        private byte[] portBuffer = new byte[1000];


        //判定打开串口字体
        Boolean lableLean = false;
        private SerialPort comm = new SerialPort();
        /// <summary>
        /// 加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SerialPortMng_Load(object sender, EventArgs e)
        {

           
            #region OLD
            AddParameters();
            //获取当前计算机串型端口名称数组.
            cmbPortName.Items.Clear();
            foreach (var item in portNames)
            {
                cmbPortName.Items.Add(item);
            }

            cmbPortName.SelectedIndex = 0;
            cmbBaudRate.SelectedIndex = 1;

            updateText += new UpdateTextEventHandler(UpdateTextBox);    //委托方法
            sp.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived); //处理串口对象的数据接收事件的方法. 
            #endregion

            //sp.Close();
        }
     


        /// <summary>
        /// 波特率（每秒传送字节数）
        /// </summary>
        private void cboBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            //获取或设置串口波特率
            // cboBaudRate.Items.Add(sp.BaudRate);
            sp.BaudRate = Convert.ToInt32(cmbBaudRate.Items[cmbBaudRate.SelectedIndex].ToString());

        }

        /// 数字和字节之间互转
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public static byte[] HexString2Bytes(String hexstr)
        {
            byte[] b = new byte[hexstr.Length / 2];
            int j = 0;
            for (int i = 0; i < b.Length; i++)
            {
                char c0 = hexstr[j++];
                char c1 = hexstr[j++];
                b[i] = (byte)(((c0) << 4) | (c1));
            }
            return b;
        }

       // string[] array;
        /// <summary>
        /// 接收到的数据
        /// </summary>
        private void sp_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            Thread.Sleep(100);
            SerialPort sp = (SerialPort)sender;
            int bytesToRead = sp.BytesToRead;
            byte[] buf = new byte[bytesToRead];
            //sp.Read(buf, 0, bytesToRead);
            this.received_count += (long)bytesToRead;
            
            this.txtView.Invoke(
                new MethodInvoker(
                    delegate
                    {
                        this.txtView.AppendText(sp.ReadExisting().Trim());
                        this.txtView.Text += " ";
                        //byte[] reciveText = HexString2Bytes(txtView.Text);
                        this.lblAccpect.Text = this.received_count.ToString();
                       

                    }
                                  )
                                );

        
            
        }

      

        private void AddEventHandlerForResponse()
        {
            for (int i = 0; i < this.portNames.Length; i++)
            {
                try
                {
                    if (this.portNames.ElementAt(i) == this.cmbPortName.Text.ToString())
                    {
                        if ((sp.IsOpen) && (sp.BytesToRead > 0))
                        {
                            sp.Read(this.portBuffer, 0, sp.BytesToRead);
                            sp.DataReceived += new SerialDataReceivedEventHandler(this.sp_DataReceived);
                        }

                    }
                }
                catch (System.IO.IOException eio)
                {
                    MessageBox.Show("串口异常：" + eio);
                }
            }
        }


        /// <summary>
        /// 获取数据
        /// </summary>
        private void UpdateTextBox(string text)
        {
            this.txtCode.Text = text;
            txtView.Text = txtCode.Text;
            txtCode.Text = "";
        }

        /// <summary>
        /// 添加波特率
        /// </summary>
        private void AddParameters()
        {
            this.cmbBaudRate.Items.AddRange(new object[] { "4800", "9600", "14400", "19200", "38400", "56000", "57600", "115200", "128000" });
        }

        /// <summary>
        /// 打开串口
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (lableLean == false)
            {
                //界面展示变化
                lableLean = true;
                btnOpen.Text = "关闭";


                if (!sp.IsOpen)
                {
                    sp.Open();  //打开一个新的串口连接.
                    //lblScan.Text = "采集中...";
                    sp.BaudRate = Convert.ToInt32(this.cmbBaudRate.Text);
                    this.cmbBaudRate.Enabled = false;
                    this.cmbPortName.Enabled = false;

                    txtCode.Focus();
                }
            }
            else
            {
                //界面展示变化
                lableLean = false;
                btnOpen.Text = "打开";


                this.cmbBaudRate.Enabled = true;
                this.cmbPortName.Enabled = true;
                //界面展示变化结束
                sp.Close();
            }

        }



        /// <summary>
        /// 发送值
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSend_Click(object sender, EventArgs e)
        {
            int num=0;
            if (!sp.IsOpen)
            {
                MessageBox.Show("还未打开串口!", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (txtCode.Text != "")
            {
                //生成二维码
                //QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
                //qrCodeEncoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC;
                //string data = this.txtCode.Text;
                //Image image = qrCodeEncoder.Encode(data);
                //this.picEncode.Image = image;

                if (this.ckbLines.Checked == true)
                {
                    txtView.AppendText("\n");
                }

                if (this.ckbHex.Checked)
                {
                    MatchCollection matchCollection = Regex.Matches(this.txtCode.Text, "(?i)[\\da-f]{2}");
                    List<byte> list = new List<byte>();
                    foreach (Match match in matchCollection)
                    {
                        list.Add(byte.Parse(match.Value));
                    }
                   sp.Write(list.ToArray(), 0, list.Count);
                    num = list.Count;
                }
                else if (this.ckbLine.Checked)
                {
                   sp.WriteLine(this.txtCode.Text);
                    num = this.txtCode.Text.Length + 2;
                }
                else
                {
                   sp.Write(this.txtCode.Text);
                    num = this.txtCode.Text.Length;
                }
                this.send_count += (long)num;
                this.lblSend.Text =  this.send_count.ToString();
                txtView.AppendText(txtCode.Text);
                txtCode.Focus();

            }
            else
            {
                MessageBox.Show(" 条码不能为空！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCode.Focus();
            }

        }

        /// <summary>
        /// 串口名称
        /// </summary>
        private void cmbPortName_SelectedIndexChanged(object sender, EventArgs e)
        {

            //       if (this.portNames.Length > 1)
            //{         
            //    for(int i = 0;i<this.portNames.Length;i++)
            //       {
            //                this.serialPorts.Add(new SerialPort(this.portNames[i]));
            //        }                
            // }
            //       this.cmbPortName.Items.AddRange(this.portNames);           
            //       this.cmbPortName.Items.AddRange(this.portNames); 

            sp.PortName = cmbPortName.Items[cmbPortName.SelectedIndex].ToString();
        }

        /// <summary>
        /// 重置，清空信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {
            this.txtView.Text = "";
            this.lblAccpect.Text = "0";
            this.lblSend.Text = "0";
            this.txtCode.Text = "";
           

      

        }

        /// <summary>
        /// 退出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            sp.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            AddEventHandlerForResponse();
        }


    }
}
