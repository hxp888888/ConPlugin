﻿using PSNLongin.DAO;
using PSNLongin.MideaScanner;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ThoughtWorks.QRCode.Codec;

namespace PSNLongin
{
    public partial class ShowData : Form
    {
        public ShowData()
        {
            InitializeComponent();

        }
        // SerialPortMng spm = new SerialPortMng();

        #region OLD
        public static SerialPort sp = new SerialPort();
        private long received_count;//接收bit位
        delegate void UpdateTextEventHandler(string text);  //委托，此为重点.
        UpdateTextEventHandler updateText;  //事件
        SerialPort comm = new SerialPort();
        string[] portNames = SerialPort.GetPortNames();
        private byte[] portBuffer = new byte[1000];
        private void ShowData_Load(object sender, EventArgs e)
        {
            sp.Encoding = System.Text.Encoding.GetEncoding("GB2312");
            //this.txtCode.Font = new Font(txtCode.Font.Name, 75);//应该是这样，手写请见谅

            // this.picEncode.Image = this.CreateImage("123456");
            #region 显示扫描值
            if (!sp.IsOpen)
            {
                for (int i = 0; i < portNames.Length; i++)
                {
                    sp.PortName = portNames[portNames.Length - 1];
                }

                sp.Open();  //打开一个新的串口连接.
                //lblScan.Text = "采集中...";
                //sp.BaudRate = 9600;
                this.cmbBaudRate.Enabled = false;
                this.cmbPortName.Enabled = false;

                txtCode.Focus();
            }



            updateText += new UpdateTextEventHandler(UpdateTextBox);    //委托方法
            //sp.Encoding = System.Text.Encoding.GetEncoding("GB2312");
            sp.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived); //处理串口对象的数据接收事件的方法. 

            #endregion

        }



        /// <summary>
        /// 根据窗体大小调整控件大小
        /// </summary>
        /// <param name="newX"></param>
        /// <param name="newY"></param>
        /// <param name="cons"></param>
        private void setControls(float newX, float newY, Control cons)
        {
            //遍历窗体中的控件，重新设置控件的值
            foreach (Control con in cons.Controls)
            {
                if (con is TextBox)
                {
                    string[] mytag = con.Tag.ToString().Split(new char[] { ':' });//获取控件的Tag属性值，并分割后存储字符串数组

                    float a = Convert.ToSingle(mytag[0]) * newX;//根据窗体缩放比例确定控件的值，宽度//89*300
                    con.Width = (int)(a);//宽度

                    a = Convert.ToSingle(mytag[1]) * newY;//根据窗体缩放比例确定控件的值，高度//12*300
                    con.Height = (int)(a);//高度

                    a = Convert.ToSingle(mytag[2]) * newX;//根据窗体缩放比例确定控件的值，左边距离//
                    con.Left = (int)(a);//左边距离

                    a = Convert.ToSingle(mytag[3]) * newY;//根据窗体缩放比例确定控件的值，上边缘距离
                    con.Top = (int)(a);//上边缘距离

                    Single currentSize = Convert.ToSingle(mytag[4]) * newY;//根据窗体缩放比例确定控件的值，字体大小
                    con.Font = new Font(con.Font.Name, currentSize, con.Font.Style, con.Font.Unit);//字体大小   
                }

            }
        }


        /// <summary>
        /// 获取控件的width、height、left、top、字体大小的值
        /// </summary>
        /// <param name="cons">要获取信息的控件</param>
        private void setTag(Control cons)
        {//遍历窗体中的控件
            foreach (Control con in cons.Controls)
            {
                con.Tag = con.Width + ":" + con.Height + ":" + con.Left + ":" + con.Top + ":" + con.Font.Size;
                //if (con.Controls.Count > 0)
                //{
                //    setTag(con);
                //}
            }
        }

        string[] array;
        //string data;
        /// <summary>
        /// 接收到的数据
        /// </summary>

        private void sp_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            //if (Login.yesNo)
            //{
            Thread.Sleep(100);
            SerialPort sp1 = (SerialPort)sender;
            sp1.Encoding = System.Text.Encoding.GetEncoding("GB2312");
            int bytesToRead = sp1.BytesToRead;
            byte[] buf = new byte[bytesToRead];

            sp1.Read(buf, 0, bytesToRead);
            this.received_count += (long)bytesToRead;
            string outstr = "";
            //string outstr1 = "";

            try
            {
                this.txtView.Invoke(
                                    new MethodInvoker(
                                        delegate
                                        {
                                            outstr = Encoding.UTF8.GetString(buf);
                                            array = outstr.Split(new char[]
                {
                    ','
                });

                                            if (array[array.Length - 1].Length >= 8 && array[array.Length - 1].Length <= 12)
                                            {
                                                this.txtCode.Text = array[0];
                                                this.txtLot.Text = array[1];
                                                this.txtCount.Text = array[2];
                                                this.txtNess.Text = array[array.Length - 1];
                                                //生成二维码
                                                this.picEncode.Image = this.CreateImage(outstr);
                                                this.insertData(array);
                                            }
                                            else
                                            {
                                                MessageBox.Show("请扫描正确的条形码哦！");
                                            }
                                            // MessageBox.Show(outstr);
                                        }));


            }
            catch (Exception ex)
            {

                throw ex;
            }



        }

        private Image CreateImage(string val)
        {
            var encoder = new QRCodeEncoder();
            String encoding = "Byte";
            if (encoding == "Byte")
            {
                encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.BYTE;
            }
            else if (encoding == "AlphaNumeric")
            {
                encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC;
            }
            else if (encoding == "Numeric")
            {
                encoder.QRCodeEncodeMode = QRCodeEncoder.ENCODE_MODE.NUMERIC;
            }
            try
            {
                int scale = Convert.ToInt16(4);
                encoder.QRCodeScale = scale;
            }
            catch (Exception ex)
            {
                MessageBox.Show("大小参数错误!");
                return null;
            }
            try
            {
                int version = Convert.ToInt16(7);
                encoder.QRCodeVersion = version;
            }
            catch (Exception ex)
            {
                MessageBox.Show("版本参数错误 !");
                return null;
            }

            string errorCorrect = "M";
            if (errorCorrect == "L")
                encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.L;
            else if (errorCorrect == "M")
                encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
            else if (errorCorrect == "Q")
                encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.Q;
            else if (errorCorrect == "H")
                encoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.H;

            String data = val;
            Image image = encoder.Encode(data);
            return image;
        }

        private void AddEventHandlerForResponse()
        {
            for (int i = 0; i < this.portNames.Length; i++)
            {
                try
                {
                    if (this.portNames.ElementAt(i) == this.cmbPortName.Text.ToString())
                    {
                        if ((sp.IsOpen) && (sp.BytesToRead > 0))
                        {
                            sp.Read(this.portBuffer, 0, sp.BytesToRead);
                            sp.DataReceived += new SerialDataReceivedEventHandler(this.sp_DataReceived);
                        }

                    }
                }
                catch (System.IO.IOException eio)
                {
                    MessageBox.Show("串口异常：" + eio);
                }
            }
        }




        private void codeShow_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("退出此界面后扫描数据将不再保存，确定退出吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {

                this.comm.Close();
                sp.Close();

                ShowData sh = new ShowData();
                //sh.Close();
                updateText -= new UpdateTextEventHandler(UpdateTextBox);    //委托方法
                sp.DataReceived -= new SerialDataReceivedEventHandler(sp_DataReceived); //处理串口对象的数据接收事件的方法. 
                return;
            }

            e.Cancel = true;
        }
        private void insertData(string[] astr)
        {
            string cmdText = "insert into tb_data(type,lot,amount,info1,info2,info3,info4,oper_no,oper_date,THICKNESS) values(@type,@lot,@amount,@info1,@info2,@info3,@info4,@operNo,@operDate,@THICKNESS)";
            SqlParameter[] commandParameters = new SqlParameter[]
            {
                new SqlParameter("@type", astr[0]),
                new SqlParameter("@lot", astr[1]),
                new SqlParameter("@amount", astr[2]),
                new SqlParameter("@info1", astr[3]),
                new SqlParameter("@info2", astr[4]),
                new SqlParameter("@info3",astr[astr.Length-3]),
                new SqlParameter("@info4", astr[astr.Length-2]), 
                new SqlParameter("@operNo", Login.account_Name),
                new SqlParameter("@operDate", DateTime.Now),
                new SqlParameter("@THICKNESS", astr[astr.Length-1])
            };
            DBHelper.ExecuteNonQuery(cmdText, commandParameters);
        }

        /// <summary>
        /// 获取数据
        /// </summary>
        private void UpdateTextBox(string text)
        {
            this.txtCode.Text = text;

        }
        #endregion

        private void txtCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 值更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCode_TextChanged(object sender, EventArgs e)
        {
            this.txtCode.Font = new Font(txtCode.Font.Name, 60);//应该是这样，手写请见谅
        }











    }
}
