﻿using PSNLongin.DAO;
using PSNLongin.DLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PSNLongin
{
    public partial class UpdUser : Form
    {
        public UpdUser()
        {
            InitializeComponent();
        }
        UserDAO usrDao = new UserDAO();
        Connect connect = new Connect();

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {

            //获取用户数据绑定到 "TextBox" 中
            UserTable user = usrDao.Queryuser(Connect.wangVaule);

            //用户对象
            UserTable userTable = new UserTable();

            //用户集合判断用户账号是否相同
            //List<UserTable> userList = usrDao.QueryuserList(Connect.wangVaule);


            //是否有重复的账号
            //Boolean userAccount = false;
            userTable.userId = Convert.ToInt32(this.txtId.Text.Trim());
            userTable.name = this.txtName.Text.Trim();
            userTable.code = this.txtUserIdUpd.Text.Trim();
            userTable.pwd = this.txtPwdUpd.Text.Trim();
            userTable.phone = this.txtPhoneUpd.Text.Trim();
            userTable.createTime = DateTime.Now;
            string retxtpwd = @"^(\w).{5,100}$";
            if (txtName.Text == "" || txtUserIdUpd.Text == "" || txtPwdUpd.Text == "" || txtPhoneUpd.Text == "")
            {
                MessageBox.Show("请全部信息填写完整！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (!Regex.IsMatch(userTable.pwd, retxtpwd))
            {
                MessageBox.Show("密码必须至少包含6位字符,其中字符必须包含数字和大小写字母");
            }
            else if (this.txtUserIdUpd.Text.Equals(Connect.wangVaule))
            {

                int Count = usrDao.UpdateUserTable(userTable);

                if (Count == 1)
                {
                    MessageBox.Show("修改成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (new Connect().ShowDialog() == DialogResult.OK)
                    {
                        //刷新操作 
                        new Connect().Refresh();
                    }
                    this.Close();

                }
                else
                {
                    MessageBox.Show("修改失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                int Count = usrDao.UpdateUserTable(userTable);

                if (Count == 1)
                {
                    MessageBox.Show("修改成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (new Connect().ShowDialog() == DialogResult.OK)
                    {
                        //刷新操作 
                        new Connect().Refresh();
                    }
                    this.Close();

                }
                else
                {
                    MessageBox.Show("修改失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }




        }

        /// <summary>
        /// 加载事件，把数据填充到修改界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdUser_Load(object sender, EventArgs e)
        {
            UserTable user = usrDao.Queryuser(Connect.wangVaule);
            this.txtId.Text = Connect.wangVaule;
            this.txtName.Text = user.name;
            this.txtUserIdUpd.Text = user.code;
            this.txtPwdUpd.Text = user.pwd;
            this.txtPhoneUpd.Text = user.phone;

        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
