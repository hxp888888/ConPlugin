﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class frmParam : Form
    {
        public frmParam()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmParam_Load(object sender, EventArgs e)
        {
            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select * from tb_dict ", null);
            foreach (DataRow dataRow in dataSet.Tables[0].Rows)
            {
                if (dataRow["dict_type"].ToString() == "FILE_ROOT")
                {
                    this.txtFileRoot.Text = dataRow["dict_value"].ToString();
                }
                if (dataRow["dict_type"].ToString() == "EXPORT_TIME1")
                {
                    this.txtTime1.Text = dataRow["dict_value"].ToString();
                }
                if (dataRow["dict_type"].ToString() == "EXPORT_TIME2")
                {
                    this.txtTime2.Text = dataRow["dict_value"].ToString();
                }
            }
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {

            DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, "select dict_value from tb_dict where dict_type = 'FILE_ROOT'");
            if (dataSet.Tables[0].Rows.Count == 0)
            {
                string cmdText = "insert into tb_dict(dict_type, dict_value, dict_desc) values(?dictType,?dictValue,?Desc)";
                SqlParameter[] commandParameters = new SqlParameter[]
				{
					new SqlParameter("dictType", "FILE_ROOT"),
					new SqlParameter("dictValue", this.txtFileRoot.Text.Trim()),
					new SqlParameter("Desc", "文件保存路径")
				};
                DBHelper.ExecuteNonQuery( cmdText, commandParameters);
            }
            else
            {
                string cmdText2 = "update tb_dict set dict_value = '" + this.txtFileRoot.Text.Trim() + "' where dict_type = 'FILE_ROOT'";
                DBHelper.ExecuteNonQuery( cmdText2);
            }
            DataSet dataSet2 = DBHelper.GetDataSet2(DBHelper.connectionString, "select dict_value from tb_dict where dict_type = 'EXPORT_TIME1'");
            if (dataSet2.Tables[0].Rows.Count == 0)
            {
                string cmdText3 = "insert into tb_dict(dict_type, dict_value, dict_desc) values(?dictType,?dictValue,?Desc)";
                SqlParameter[] commandParameters2 = new SqlParameter[]
				{
					new SqlParameter("dictType", "EXPORT_TIME1"),
					new SqlParameter("dictValue", this.txtTime1.Text.Trim()),
					new SqlParameter("Desc", "导出时间")
				};
                DBHelper.ExecuteNonQuery( cmdText3, commandParameters2);
            }
            else
            {
                string cmdText4 = "update tb_dict set dict_value = '" + this.txtTime1.Text.Trim() + "' where dict_type = 'EXPORT_TIME1'";
                DBHelper.ExecuteNonQuery( cmdText4);
            }
            DataSet dataSet3 = DBHelper.GetDataSet2(DBHelper.connectionString, "select dict_value from tb_dict where dict_type = 'EXPORT_TIME2'");
            if (dataSet3.Tables[0].Rows.Count == 0)
            {
                string cmdText5 = "insert into tb_dict(dict_type, dict_value, dict_desc) values(?dictType,?dictValue,?Desc)";
                SqlParameter[] commandParameters3 = new SqlParameter[]
				{
					new SqlParameter("dictType", "EXPORT_TIME2"),
					new SqlParameter("dictValue", this.txtTime2.Text.Trim()),
					new SqlParameter("Desc", "导出时间")
				};
                DBHelper.ExecuteNonQuery(cmdText5, commandParameters3);
            }
            else
            {
                string cmdText6 = "update tb_dict set dict_value = '" + this.txtTime2.Text.Trim() + "' where dict_type = 'EXPORT_TIME2'";
                DBHelper.ExecuteNonQuery(cmdText6);
            }
            MessageBox.Show("更新成功！");
            base.Close();
        }
    }
}
