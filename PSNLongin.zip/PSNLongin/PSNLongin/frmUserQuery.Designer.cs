﻿namespace PSNLongin
{
    partial class frmUserQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dvgQueryZH = new System.Windows.Forms.DataGridView();
            this.btnOutData = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.dtpEtime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpStime = new System.Windows.Forms.DateTimePicker();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.dvgQueryZH)).BeginInit();
            this.SuspendLayout();
            // 
            // dvgQueryZH
            // 
            this.dvgQueryZH.AllowUserToAddRows = false;
            this.dvgQueryZH.AllowUserToDeleteRows = false;
            this.dvgQueryZH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dvgQueryZH.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dvgQueryZH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgQueryZH.Location = new System.Drawing.Point(14, 38);
            this.dvgQueryZH.Name = "dvgQueryZH";
            this.dvgQueryZH.RowTemplate.Height = 23;
            this.dvgQueryZH.Size = new System.Drawing.Size(949, 230);
            this.dvgQueryZH.TabIndex = 19;
            this.dvgQueryZH.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dvgQueryZH_CellMouseClick);
            // 
            // btnOutData
            // 
            this.btnOutData.Location = new System.Drawing.Point(724, 9);
            this.btnOutData.Name = "btnOutData";
            this.btnOutData.Size = new System.Drawing.Size(75, 23);
            this.btnOutData.TabIndex = 18;
            this.btnOutData.Text = "导出";
            this.btnOutData.UseVisualStyleBackColor = true;
            this.btnOutData.Click += new System.EventHandler(this.btnOutData_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(614, 9);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 17;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // dtpEtime
            // 
            this.dtpEtime.CustomFormat = "yyyy年MM月dd日";
            this.dtpEtime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEtime.Location = new System.Drawing.Point(368, 8);
            this.dtpEtime.Name = "dtpEtime";
            this.dtpEtime.Size = new System.Drawing.Size(200, 21);
            this.dtpEtime.TabIndex = 16;
            this.dtpEtime.Value = new System.DateTime(2019, 6, 18, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "起始时间";
            // 
            // dtpStime
            // 
            this.dtpStime.CustomFormat = "yyyy年MM月dd日";
            this.dtpStime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStime.Location = new System.Drawing.Point(71, 8);
            this.dtpStime.Name = "dtpStime";
            this.dtpStime.Size = new System.Drawing.Size(200, 21);
            this.dtpStime.TabIndex = 14;
            this.dtpStime.Value = new System.DateTime(2019, 6, 18, 0, 0, 0, 0);
            // 
            // frmUserQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 283);
            this.Controls.Add(this.dvgQueryZH);
            this.Controls.Add(this.btnOutData);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.dtpEtime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpStime);
            this.Name = "frmUserQuery";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "普通查询";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmUserQuery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvgQueryZH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dvgQueryZH;
        private System.Windows.Forms.Button btnOutData;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.DateTimePicker dtpEtime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpStime;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}