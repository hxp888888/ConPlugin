﻿using Microsoft.CSharp.RuntimeBinder;
using PSNLongin.DAO;
using PSNLongin.DLL;
using PSNLongin.MideaScanner;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class frmUserQuery : Form
    {

        [CompilerGenerated]
        private static class o__SiteContainer0
        {
            public static CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>> p__Site1;
        }
        public frmUserQuery()
        {
            InitializeComponent();
        }
        private int selid;

        public string sqlsel = "";

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

        public void KillSpecialExcel(Microsoft.Office.Interop.Excel.Application m_objExcel)
        {
            try
            {
                if (m_objExcel != null)
                {
                    int processId;
                    frmUserQuery.GetWindowThreadProcessId(new IntPtr(m_objExcel.Hwnd), out processId);
                    Process.GetProcessById(processId).Kill();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void ToExcel(SaveFileDialog saveFileDialog)
        {
            // saveFileDialog = new SaveFileDialog();
            //Thread.Sleep(1000); 
            saveFileDialog.Filter = "Execl files (*.xls)|*.xls";
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = false;
            saveFileDialog.Title = "导出文件保存路径";
            string[] array = new string[]
			{
				"品番",
				"Lot",
				"数量",
                "Part NO.",
                "订单号",
                "打印者",
                "打印时间",
                "厚度",
                "操作员",
				"操作时间"
			};

            DialogResult result = saveFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                string cmdText = string.Concat(new string[]
				{
					"select type as 品番,lot as LOT,amount as 数量,info1 'Part NO.',info2 订单号,info3 打印者,info4 打印时间,THICKNESS 厚度,oper_no, CONVERT(datetime, oper_date,111)  from tb_data where oper_date >= '",
					Convert.ToDateTime( this.dtpStime.Text).ToString("yyyy-MM-dd").Substring(0,10),
					"' and oper_date <='",
					Convert.ToDateTime( this.dtpEtime.Text).ToString("yyyy-MM-dd").Substring(0,10)," 23:59:59'"

                   
				});
                DataSet dataSet = DBHelper.GetDataSet2(DBHelper.connectionString, cmdText);
                DataTable dataTable = dataSet.Tables[0];
                if (dataTable.Rows.Count == 0)
                {
                    return;
                }
                if (fileName.Length != 0)
                {
                    Missing value = Missing.Value;
                    Microsoft.Office.Interop.Excel.Application application = (Microsoft.Office.Interop.Excel.Application)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
                    application.Visible = false;
                    CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
                    Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
                    Microsoft.Office.Interop.Excel.Workbook workbook = application.Workbooks.Add(value);
                    if (frmUserQuery.o__SiteContainer0.p__Site1 == null)
                    {
                        frmUserQuery.o__SiteContainer0.p__Site1 = CallSite<Func<CallSite, object, Microsoft.Office.Interop.Excel.Worksheet>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(Microsoft.Office.Interop.Excel.Worksheet), typeof(frmUserQuery)));
                    }
                    Microsoft.Office.Interop.Excel.Worksheet worksheet = frmUserQuery.o__SiteContainer0.p__Site1.Target(frmUserQuery.o__SiteContainer0.p__Site1, workbook.Worksheets.Add(value, value, value, value));
                    worksheet.Name = "data";
                    //worksheet.AllocatedRange["A1:F8"].AutoFitColumns();
                    //worksheet.AllocatedRange["A1:F8"].AutoFitRows();
                    for (int i = 0; i < array.Length; i++)
                    {
                        worksheet.Cells[1, i + 1] = array[i];
                    }
                    Microsoft.Office.Interop.Excel.Range arg_1F8_0 = worksheet.get_Range("A2", value);
                    //Microsoft.Office.Interop.Excel.Range allColumn = worksheet.Rows;
                    //allColumn.AutoFit();
                    //((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Missing.Value]).RowHeight = 5;
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Missing.Value]).ColumnWidth = 25;
                    Microsoft.Office.Interop.Excel.Range range = null;
                    int count = dataTable.Rows.Count;
                    int j = 0;
                    int num = 1;
                    int count2 = dataTable.Columns.Count;
                    object[,] array2 = new object[num, count2];
                    try
                    {
                        int num2 = num;
                        while (j < count)
                        {
                            if (count - j < num)
                            {
                                num2 = count - j;
                            }
                            for (int k = 0; k < num2; k++)
                            {
                                for (int l = 0; l < count2; l++)
                                {
                                    array2[k, l] = dataTable.Rows[k + j][l].ToString();
                                }
                                System.Windows.Forms.Application.DoEvents();
                            }
                            range = worksheet.get_Range("A" + (j + 2).ToString(), ((char)(65 + count2 - 1)).ToString() + (j + num2 + 1).ToString());
                            range.Value2 = array2;
                            j += num2;
                        }
                        worksheet.SaveAs(fileName, value, value, value, value, value, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, value, value, value);
                        Marshal.ReleaseComObject(range);
                        this.KillSpecialExcel(application);
                        MessageBox.Show("导出数据成功！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                    Thread.CurrentThread.CurrentCulture = currentCulture;
                }
            }
        }

        /// <summary>
        /// 加载事件
        /// </summary>
        /// <param name="sender"></param>Value
        /// <param name="e"></param>
        private void frmUserQuery_Load(object sender, EventArgs e)
        {
            this.dvgQueryZH.DataSource = DBHelper.GetDataSet2(DBHelper.connectionString, "select id as 序号, type as 品番,lot as LOT,amount as 数量,INFO1 'Part NO.',INFO2 订单号,INFO3 打印者,INFO4 打印时间,THICKNESS 厚度,oper_no as 操作员,oper_date as 操作时间  from tb_data where 1=0", null).Tables[0].DefaultView;
            this.dtpStime.Value = DateTime.Now;
            this.dtpEtime.Value = DateTime.Now;
            //this.dvgQueryZH.Columns[0].Width = 100;
            //this.dvgQueryZH.Columns[1].Width = 200;
            //this.dvgQueryZH.Columns[2].Width = 150;
            //this.dvgQueryZH.Columns[3].Width = 150;
            //this.dvgQueryZH.Columns[4].Width = 150;
            //this.dvgQueryZH.Columns[5].Width = 200;
        }

        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOutData_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();


            this.ToExcel(saveFileDialog1);
        }

        private void dvgQueryZH_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (this.dvgQueryZH.CurrentRow == null)
            {
                return;
            }
            DataGridViewRow currentRow = this.dvgQueryZH.CurrentRow;
            if (currentRow.Cells[0].Value.ToString() != "")
            {
                this.selid = int.Parse(currentRow.Cells[0].Value.ToString());
            }
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnQuery_Click(object sender, EventArgs e)
        {
            this.sqlsel = string.Concat(new string[]
			{
				"select id as 序号,type as 品番,lot as LOT,amount as 数量,INFO1 'Part NO.',INFO2 订单号,INFO3 标签打印者,INFO4 标签打印时间,THICKNESS 厚度,oper_no as 操作员,oper_date as 操作时间 from tb_data where oper_date >= '",
				Convert.ToDateTime(this.dtpStime.Text).ToString("yyyy-MM-dd").Substring(0,10) ,
				"' and oper_date <='",
				Convert.ToDateTime(this.dtpEtime.Text).ToString("yyyy-MM-dd").Substring(0,10) ,
				" 23:59:59'"
			});
            this.dvgQueryZH.DataSource = DBHelper.GetDataSet2(DBHelper.connectionString, this.sqlsel, null).Tables[0].DefaultView;
            //this.dvgQueryZH.Columns[0].Width = 100;
            //this.dvgQueryZH.Columns[1].Width = 200;
            //this.dvgQueryZH.Columns[2].Width = 150;
            //this.dvgQueryZH.Columns[3].Width = 150;
            //this.dvgQueryZH.Columns[4].Width = 150;
            //this.dvgQueryZH.Columns[5].Width = 200;
        }
    }
}
