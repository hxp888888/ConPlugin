﻿using PSNLongin.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSNLongin
{
    public partial class losePwd : Form
    {
        public losePwd()
        {
            InitializeComponent();
        }
        UserDAO usrDao = new UserDAO();
        private void losePwd_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
          [STAThread]
        private void btnOK_Click(object sender, EventArgs e)
        {
            string pwd = this.txtPwd.Text.Trim();//密码
            string pwd2 = this.txtPwd2.Text.Trim();//确认密码
            string retxtpwd = @"^(\w).{5,100}$";
            //string retxtpwd1 = @"^(?=.*[a-zA-Z].*)(?=.*[0-9].*).{6,100}$";
            

            if (pwd == "")
            {
                MessageBox.Show("新密码与确认密码不能为空！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (!Regex.IsMatch(pwd, retxtpwd))
            {
                //验证不通过
                MessageBox.Show("密码必须至少包含6位字符,其中字符必须包含数字和大小写字母");
            }
            //else
            //{
            //    //验证通过

           //}

            else if (!pwd.Equals(pwd2))
            {
                MessageBox.Show("两次输入的密码不一致！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //开始修改
                //用户对象
                UserTable userTable = new UserTable();
                userTable.pwd = this.txtPwd.Text.Trim();
                userTable.userId = Convert.ToInt32(Login.account_);
                userTable.createTime = DateTime.Now;
                int Count = usrDao.UpdateUserPwd(userTable);

                if (Count == 1)
                {
                    MessageBox.Show("修改成功,请重新登录!", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                   // Application.Exit();
                    System.Windows.Forms.Application.Restart();
                    //this.Hide();

                }
                else
                {
                    MessageBox.Show("修改失败！", "温馨提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }

        private void txtPwd2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        static void ThreadMethod() { Thread.Sleep(1000); }
    }
}
