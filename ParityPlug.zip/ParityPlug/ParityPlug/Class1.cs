﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel;
using Kingdee.BOS;
using Kingdee.BOS.Util;
using Kingdee.BOS.Core;
using Kingdee.BOS.Core.DynamicForm;
using Kingdee.BOS.Core.DynamicForm.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.ServiceHelper;
using Kingdee.BOS.Core.Metadata.EntityElement;
using Kingdee.BOS.Orm.DataEntity;
using System.Data.SqlClient;
using Kingdee.BOS.Core.DynamicForm.PlugIn.ControlModel;
using Kingdee.BOS.Core.Metadata;
using Kingdee.BOS.Core.Bill;
using Kingdee.BOS.App.Data;
using Kingdee.BOS.Contracts;
using Kingdee.BOS.Core.Bill.PlugIn;
using Kingdee.BOS.Workflow.Interface;
using Kingdee.BOS.Core.Const;
using Kingdee.BOS.Core.Interaction;
using Kingdee.BOS.Resource;
using Kingdee.K3.SCM.Business;
using Kingdee.K3.SCM.ServiceHelper;

namespace ParityPlug
{
    public class Class1 : AbstractBillPlugIn
    {
        private bool isNotShowMessageS = false;//判断是否弹提示框
        /// <summary>
        /// 值更新操作
        /// </summary>
        /// <param name="e"></param>
        public override void DataChanged(Kingdee.BOS.Core.DynamicForm.PlugIn.Args.DataChangedEventArgs e)
        {
            base.DataChanged(e);
            if (e.Field.Key.Equals("F_KTT_BJPrice"))
            {

                #region 同一物料同一供应商价格保持一致
                Entity entityMX = this.View.BillBusinessInfo.GetEntity("F_KTT_Entity");
                DynamicObjectCollection mxEntity = entityMX.DynamicProperty.GetValue(this.Model.DataObject) as DynamicObjectCollection;
                double dqDate = Convert.ToDouble(this.Model.GetValue("F_KTT_BJPrice", e.Row));//当前单价
                DynamicObject pinFanErow = this.Model.GetValue("F_KTT_wlBase", e.Row) as DynamicObject;//当前品番
                DynamicObject gysErow = this.Model.GetValue("F_KTT_supBase", e.Row) as DynamicObject;//当前供应商
                for (int i = 0; i < mxEntity.Count; i++)
                {
                    DynamicObject pinFan = this.Model.GetValue("F_KTT_wlBase", i) as DynamicObject;//品番
                    DynamicObject gysId = this.Model.GetValue("F_KTT_supBase", i) as DynamicObject;//供应商
                    if (pinFan != null && pinFanErow != null && gysId != null && gysErow!=null)
                    {
                        //同一物料同一供应商赋值价格
                        if (pinFan["Id"].ToString().Equals(pinFanErow["Id"].ToString()) && gysId["Id"].ToString().Equals(gysErow["Id"].ToString()))
                        {
                            this.Model.SetValue("F_KTT_BJPrice", dqDate, i);
                            this.View.UpdateView("F_KTT_BJPrice", i);
                        }
                    }
                }
                #endregion
            }

            if (e.Field.Key.Equals("F_KTT_CheckBox"))
            {
                //|| this.Model.GetValue("FDocumentStatus").Equals("D")
                if (this.Model.GetValue("FDocumentStatus").Equals("A") || this.Model.GetValue("FDocumentStatus").Equals("D"))
                {
                    isNotShowMessageS = true;
                    this.View.InvokeFormOperation(FormOperationEnum.Save);
                }

            }

           
        }
        /// <summary>
        /// 保存前操作
        /// 同一供应商同一物料同一申请单号只能采纳一个
        /// </summary>
        /// <param name="e"></param>
        public override void BeforeSave(Kingdee.BOS.Core.Bill.PlugIn.Args.BeforeSaveEventArgs e)
        {
            base.BeforeSave(e);
            #region 同一供应商同一物料同一申请单号只能采纳一个
            //Entity entityMX = this.View.BillBusinessInfo.GetEntity("F_KTT_Entity");
            //DynamicObjectCollection mxEntity = entityMX.DynamicProperty.GetValue(this.Model.DataObject) as DynamicObjectCollection;



            //List<string> ids = new List<string>();//单号
            //List<long> gys = new List<long>();//供应商
            //List<long> wls = new List<long>();//物料
            //for (int i = 0; i < mxEntity.Count; i++)
            //{
            //    string numId = this.Model.GetValue("F_KTT_SQNumber", i).ToString();//采购申请单号
            //    DynamicObject gysId = this.Model.GetValue("F_KTT_supBase", i) as DynamicObject;//供应商
            //    DynamicObject wlId = this.Model.GetValue("F_KTT_wlBase", i) as DynamicObject;//物料
            //    if (numId.IsNullOrEmptyOrWhiteSpace()) continue;
            //    string id = Convert.ToString(numId);
            //    if (gysId.IsNullOrEmptyOrWhiteSpace()) continue;
            //    long id1 = Convert.ToInt64(gysId[0]);
            //    if (wlId.IsNullOrEmptyOrWhiteSpace()) continue;
            //    long id2 = Convert.ToInt64(wlId[0]);
            //    if (ids.Contains(id) == false)
            //    {
            //        ids.Add(id);
            //    }
            //    if (gys.Contains(id1) == false)
            //    {
            //        gys.Add(id1);
            //    }
            //    if (wls.Contains(id2) == false)
            //    {
            //        wls.Add(id2);
            //    }
            //}

            //int isNo = 0;
            //for (int j = 0; j < mxEntity.Count; j++)
            //{
            //    string numId1 = this.Model.GetValue("F_KTT_SQNumber", j).ToString();//采购申请单号
            //    DynamicObject gysId1 = this.Model.GetValue("F_KTT_supBase", j) as DynamicObject;//供应商
            //    DynamicObject wlId1 = this.Model.GetValue("F_KTT_wlBase", j) as DynamicObject;//物料
            //    for (int k = 0; k < ids.Count; k++)
            //    {
            //        if (numId1.Equals(ids[k]))
            //        {
            //            for (int u = 0; u < gys.Count; u++)
            //            {
            //                if (gysId1["Id"].Equals(gys[u]))
            //                {
            //                    for (int r = 0; r < wls.Count; r++)
            //                    {
            //                        if (wlId1["Id"].Equals(wls[r]))
            //                        {
            //                            if (this.Model.GetValue("F_KTT_CheckBox",j).ToString().Equals("True"))
            //                            {
            //                                isNo++;
            //                                //this.View.ShowErrMessage("同单同一供应商同一物料只允许勾选采纳一个！");
            //                                //e.Cancel=true;
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            //if (isNo>ids.Count)
            //{
            //    this.View.ShowErrMessage("同单同一供应商同一物料只允许勾选采纳一个！");
            //    e.Cancel = true;
            //}
            //if (ids.Count < 0)
            //{
            //    if (gys.Count<0)
            //    {
            //        if (wls.Count<0)
            //        {
            //            for (int i = 0; i < mxEntity.Count; i++)
            //            {

            //            }
            //        }
            //    }
            //}



            #endregion

        }


        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="e"></param>
        public override void BarItemClick(BarItemClickEventArgs e)
        {
            // e.Cancel = true;
            base.BarItemClick(e);
            if (e.BarItemKey.EqualsIgnoreCase("tbSubmit") || e.BarItemKey.EqualsIgnoreCase("tbSplitSubmit"))
            {
                isNotShowMessageS = false;
                string fid = this.View.Model.DataObject["Id"].ToString();
                //int CHECKBOXInt = 0;
                //提交时判断
                for (int i = 0; i < this.Model.GetEntryRowCount("F_KTT_Entity"); i++)
                {
                    string SQNUMBER = this.Model.GetValue("F_KTT_SQNUMBER", i).ToString();
                    string strSQL = @"SELECT count( F_KTT_CHECKBOX ) FROM KTT_t_Cust_Entry100016 WHERE FID=" + fid + " and  F_KTT_CHECKBOX=1 GROUP BY F_KTT_SQNUMBER,F_KTT_SUPBASE,F_KTT_WLBASE,F_KTT_CHECKBOX";
                    using (IDataReader dataReaderPerson = DBServiceHelper.ExecuteReader(base.Context, strSQL))
                    {
                        while (dataReaderPerson.Read())
                        {
                            if (Convert.ToInt32(dataReaderPerson[0]) > 1)//同单勾选了重复供应商物料数据
                            {
                                this.View.ShowErrMessage("同一申请单同一物料同一供应商只能采纳一行数据！");
                                e.Cancel = true;
                            }
                        }
                        dataReaderPerson.Close();
                    }
                }

            }


        }

        public override void AfterDoOperation(AfterDoOperationEventArgs e)
        {
            base.AfterDoOperation(e);
            if (isNotShowMessageS)
            {
                e.OperationResult.IsShowMessage = false;
            }

            isNotShowMessageS = false;

            //switch (e.Operation.Operation.ToUpper())
            //{
            //    case "TAKEREFERENCEPRICE":
            //        {
            //            new List<object>();
            //            List<long> list = new List<long>();
            //            List<long> list2 = new List<long>();
            //            List<long> list3 = new List<long>();
            //            List<long> list4 = new List<long>();
            //            using (TakeReferencePrice price = new TakeReferencePrice(base.View.Context))
            //            {
            //                long item = 0L;
            //                long num2 = 0L;
            //                DynamicObject obj2 = base.View.Model.DataObject;
            //                DynamicObject obj3 = base.View.Model.GetValue("FSettleCurrId") as DynamicObject;
            //                if (obj3 != null)
            //                {
            //                    item = Convert.ToInt64(obj3["Id"]);
            //                    list2.Add(item);
            //                }
            //                DynamicObject obj4 = base.View.Model.GetValue("FPurchaseOrgId") as DynamicObject;
            //                if (obj4 != null)
            //                {
            //                    num2 = Convert.ToInt64(obj4["Id"]);
            //                }
            //                string str = Convert.ToString(CommonServiceHelper.GetSystemProfile(base.Context, num2, "PUR_SystemParameter", "ReferencePriceSource", "1"));
            //                if (string.IsNullOrWhiteSpace(str) || (str == "1"))
            //                {
            //                    break;
            //                }
            //                list4.Add(num2);
            //                bool flag = Convert.ToBoolean(base.View.Model.GetValue("FIsIncludedTax"));
            //                DynamicObjectCollection objects = obj2["POOrderEntry"] as DynamicObjectCollection;
            //                foreach (DynamicObject obj6 in objects)
            //                {
            //                    list3.Add(Convert.ToInt64(obj6["AuxPropId_Id"]));
            //                    list.Add(Convert.ToInt64(obj6["MaterialId_Id"]));
            //                }
            //                DynamicObjectCollection objects2 = price.GetReferencePriceLists(base.View.Context, list, list2, list4, str);
            //                price.TakeReferencePriceEdit(this, objects2, objects, item, flag);
            //                return;
            //            }
            //        }


            //}


        }

        public override void BeforeDoOperation(Kingdee.BOS.Core.DynamicForm.PlugIn.Args.BeforeDoOperationEventArgs e)
        {
            base.BeforeDoOperation(e);
            //string str = string.Empty;
            //if (base.View.Model.GetEntryRowCount("FPOOrderEntry") <= 0)
            //{

            //    str = str + ResManager.LoadKDString("没有输入分录信息，不能取参考价！", "004011000014666", "5", new object[0]) + Environment.NewLine;
            //}
            //if (base.View.Model.GetValue("FPurchaseOrgId") == null)
            //{
            //    str = str + ResManager.LoadKDString("采购组织为空，不能取参考价！", "004011000014667", "5", new object[0]) + Environment.NewLine;
            //}
            //if (base.View.Model.GetValue("FSupplierId") == null)
            //{
            //    str = str + ResManager.LoadKDString("供应商为空，不能取参考价！", "004011000014668", "5", new object[0]) + Environment.NewLine;
            //}
            //if (base.View.Model.GetValue("FSettleCurrId") == null)
            //{
            //    str = str + ResManager.LoadKDString("结算币别为空，不能取参考价！", "004011000014669", "5", new object[0]) + Environment.NewLine;
            //}
            //if (str.Length > 0)
            //{
            //    base.View.ShowErrMessage(str, "", 0);
            //    e.Cancel = true;

            //}
        }


    }
}
