﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel;
using Kingdee.BOS;
using Kingdee.BOS.Util;
using Kingdee.BOS.Core;
using Kingdee.BOS.Core.DynamicForm;
using Kingdee.BOS.Core.DynamicForm.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.ServiceHelper;
using Kingdee.BOS.Core.Metadata.EntityElement;
using Kingdee.BOS.Orm.DataEntity;
using System.Data.SqlClient;
using Kingdee.BOS.Core.DynamicForm.PlugIn.ControlModel;
using Kingdee.BOS.Core.Metadata;
using Kingdee.BOS.Core.Bill;
using Kingdee.BOS.App.Data;
using Kingdee.BOS.Contracts;
using Kingdee.BOS.Core.Bill.PlugIn;
using Kingdee.BOS.Workflow.Interface;
using Kingdee.BOS.Core.Const;
using Kingdee.BOS.Core.Interaction;
using Kingdee.BOS.Resource;
using Kingdee.K3.SCM.Business;
using Kingdee.K3.SCM.ServiceHelper;


namespace ParityPlug
{
    public class GetPriceCG : AbstractBillPlugIn
    {
        public override void DataChanged(DataChangedEventArgs e)
        {
            base.DataChanged(e);
            if (e.Field.Key.EqualsIgnoreCase("FMaterialId"))
            {
                string strTips = string.Empty;
                if (base.View.Model.GetEntryRowCount("FPOOrderEntry") <= 0)
                {

                    strTips = strTips + ResManager.LoadKDString("没有输入分录信息，不能取参考价！", "004011000014666", "5", new object[0]) + Environment.NewLine;
                }
                if (base.View.Model.GetValue("FPurchaseOrgId") == null)
                {
                    strTips = strTips + ResManager.LoadKDString("采购组织为空，不能取参考价！", "004011000014667", "5", new object[0]) + Environment.NewLine;
                }
                if (base.View.Model.GetValue("FSupplierId") == null)
                {
                    strTips = strTips + ResManager.LoadKDString("供应商为空，不能取参考价！", "004011000014668", "5", new object[0]) + Environment.NewLine;
                }
                if (base.View.Model.GetValue("FSettleCurrId") == null)
                {
                    strTips = strTips + ResManager.LoadKDString("结算币别为空，不能取参考价！", "004011000014669", "5", new object[0]) + Environment.NewLine;
                }
                if (strTips.Length > 0)
                {
                    base.View.ShowErrMessage(strTips, "", 0);


                }
                else
                {



                    new List<object>();
                    List<long> list = new List<long>();
                    List<long> list2 = new List<long>();
                    List<long> list3 = new List<long>();
                    List<long> list4 = new List<long>();
                    using (TakeReferencePrice price = new TakeReferencePrice(base.View.Context))
                    {
                        long item = 0L;
                        long num2 = 0L;
                        DynamicObject obj2 = base.View.Model.DataObject;
                        DynamicObject obj3 = base.View.Model.GetValue("FSettleCurrId") as DynamicObject;
                        if (obj3 != null)
                        {
                            item = Convert.ToInt64(obj3["Id"]);
                            list2.Add(item);
                        }
                        DynamicObject obj4 = base.View.Model.GetValue("FPurchaseOrgId") as DynamicObject;
                        if (obj4 != null)
                        {
                            num2 = Convert.ToInt64(obj4["Id"]);
                        }
                        string str = Convert.ToString(CommonServiceHelper.GetSystemProfile(base.Context, num2, "PUR_SystemParameter", "ReferencePriceSource", "1"));
                        if (string.IsNullOrWhiteSpace(str) || (str == "1"))
                        {
                            return;
                        }
                        list4.Add(num2);
                        bool flag = Convert.ToBoolean(base.View.Model.GetValue("FIsIncludedTax"));
                        DynamicObjectCollection objects = obj2["POOrderEntry"] as DynamicObjectCollection;
                        foreach (DynamicObject obj6 in objects)
                        {
                            list3.Add(Convert.ToInt64(obj6["AuxPropId_Id"]));
                            list.Add(Convert.ToInt64(obj6["MaterialId_Id"]));
                        }
                        DynamicObjectCollection objects2 = price.GetReferencePriceLists(base.View.Context, list, list2, list4, str);
                        price.TakeReferencePriceEdit(this, objects2, objects, item, flag);
                        return;




                    }
                }
            }
        }
    }
}
