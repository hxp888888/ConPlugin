﻿using Kingdee.BOS.Orm.DataEntity;
using System.Data.SqlClient;
using Kingdee.BOS.Core.DynamicForm.PlugIn.ControlModel;
using Kingdee.BOS.Core.Metadata;
using Kingdee.BOS.Core.Bill;
using Kingdee.BOS.App.Data;
using Kingdee.BOS.Contracts;
using Kingdee.BOS.Core.Bill.PlugIn;
using Kingdee.BOS.Workflow.Interface;
using Kingdee.BOS.Core.Const;
using Kingdee.BOS.Core.Interaction;
using Kingdee.BOS.Resource;
using Kingdee.K3.SCM.Business;
using Kingdee.K3.SCM.ServiceHelper;
using Kingdee.BOS.Core.List.PlugIn;
using Kingdee.BOS.ServiceHelper;
using System.Data;
using System;

namespace ParityPlug
{
    public class ListJudge : AbstractListPlugIn
    {
        private bool isNotShowMessageS = false;//判断是否弹提示框
        public override void BarItemClick(Kingdee.BOS.Core.DynamicForm.PlugIn.Args.BarItemClickEventArgs e)
        {
            base.BarItemClick(e);
            if (e.BarItemKey.Equals("tbSubmit") || e.BarItemKey.Equals("tbSplitSubmit"))
            {
                isNotShowMessageS = false;
                //string fid = this.View.Model.DataObject["Id"].ToString();
                string listFid = this.ListView.CurrentSelectedRowInfo.PrimaryKeyValue;
                //int CHECKBOXInt = 0;
                //提交时判断
                //for (int i = 0; i < this.Model.GetEntryRowCount("F_KTT_Entity"); i++)
                //{
                //    string SQNUMBER = this.Model.GetValue("F_KTT_SQNUMBER", i).ToString();
                string strSQL = @"SELECT count( F_KTT_CHECKBOX ) FROM KTT_t_Cust_Entry100016 WHERE FID=" + listFid + " and  F_KTT_CHECKBOX=1 GROUP BY F_KTT_SQNUMBER,F_KTT_SUPBASE,F_KTT_WLBASE,F_KTT_CHECKBOX";
                    using (IDataReader dataReaderPerson = DBServiceHelper.ExecuteReader(base.Context, strSQL))
                    {
                        while (dataReaderPerson.Read())
                        {
                            if (Convert.ToInt32(dataReaderPerson[0]) > 1)//同单勾选了重复供应商物料数据
                            {
                                this.View.ShowErrMessage("同一申请单同一物料同一供应商只能采纳一行数据！");
                                e.Cancel = true;
                            }
                        }
                        dataReaderPerson.Close();
                    }
                //}

            }
        }

        public override void AfterDoOperation(Kingdee.BOS.Core.DynamicForm.PlugIn.Args.AfterDoOperationEventArgs e)
        {
            base.AfterDoOperation(e);
            base.AfterDoOperation(e);
            if (isNotShowMessageS)
            {
                e.OperationResult.IsShowMessage = false;
            }

            isNotShowMessageS = false;
        }

     

    }
}
